

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Arsenal                       42  14  3  4  70:27   11  5  5  48:34   118:61  +57   83
 2. Aston Villa                   42  16  2  3  60:29    7  6  8  32:38    92:67  +25   77
 3. Sheffield Wednesday           42  15  5  1  46:20    6  4 11  34:48    80:68  +12   72
 4. Newcastle United              42  15  2  4  44:24    7  3 11  27:39    71:63   +8   71
 5. West Bromwich Albion          42  16  1  4  50:23    4  8  9  33:47    83:70  +13   69
 6. Huddersfield Town             42  11  6  4  32:17    7  5  9  34:36    66:53  +13   65
 7. Portsmouth                    42  14  3  4  39:22    4  4 13  35:54    74:76   -2   61
 8. Sheffield United              42  14  3  4  50:30    3  6 12  24:50    74:80   -6   60
 9. Derby County                  42  11  8  2  49:25    4  6 11  27:44    76:69   +7   59
10. Leeds United                  42  10  6  5  39:24    5  8  8  20:38    59:62   -3   59
11. Everton                       42  13  6  2  54:24    3  3 15  27:50    81:74   +7   57
12. Sunderland                    42   8  7  6  33:31    7  3 11  30:49    63:80  -17   55
13. Birmingham City               42  13  3  5  40:23    1  8 12  17:34    57:57        53
14. Manchester City               42  12  3  6  47:30    4  2 15  21:41    68:71   -3   53
15. Liverpool                     42  10  6  5  53:33    4  5 12  26:51    79:84   -5   53
16. Blackburn Rovers              42  11  6  4  48:41    3  4 14  28:61    76:102 -26   52
17. Middlesbrough                 42   8  5  8  35:33    6  4 11  28:40    63:73  -10   51
18. Chelsea                       42   9  4  8  38:29    5  3 13  25:44    63:73  -10   49
19. Wolverhampton Wanderers       42  10  4  7  56:48    3  5 13  24:48    80:96  -16   48
20. Blackpool                     42  11  2  8  44:35    3  3 15  25:50    69:85  -16   47
21. Leicester City                42   9  9  3  43:25    2  4 15  32:64    75:89  -14   46
22. Bolton Wanderers              42  10  7  4  49:33    2  2 17  29:59    78:92  -14   45
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Stoke City                    42  13  3  5  40:15   12  3  6  38:24    78:39  +39   81
 2. Tottenham Hotspur             42  14  7  0  58:19    6  8  7  38:32    96:51  +45   75
 3. Fulham                        42  12  5  4  46:31    8  5  8  32:34    78:65  +13   70
 4. Bury                          42  13  7  1  55:23    7  2 12  29:36    84:59  +25   69
 5. Nottingham Forest             42   9  8  4  37:28    8  7  6  30:31    67:59   +8   66
 6. Swansea City                  42  17  0  4  36:12    2  4 15  14:42    50:54   -4   61
 7. Bradford Park Avenue          42  13  4  4  51:27    4  4 13  26:44    77:71   +6   59
 8. Millwall                      42  11  7  3  40:20    5  4 12  19:37    59:57   +2   59
 9. Southampton                   42  15  3  3  48:22    3  2 16  18:44    66:66        59
10. Preston North End             42  12  2  7  53:36    4  8  9  21:34    74:70   +4   58
11. Manchester United             42  11  5  5  40:24    4  8  9  31:44    71:68   +3   58
12. Plymouth Argyle               42  13  4  4  45:22    3  5 13  18:45    63:67   -4   57
13. Bradford City                 42  10  6  5  43:24    4  7 10  22:37    65:61   +4   55
14. Grimsby Town                  42   8 10  3  49:34    6  3 12  30:50    79:84   -5   55
15. Notts County                  42  10  4  7  41:31    5  6 10  26:47    67:78  -11   55
16. Oldham Athletic               42  10  4  7  38:31    5  4 12  29:49    67:80  -13   53
17. Port Vale                     42  12  3  6  49:27    2  7 12  17:52    66:79  -13   52
18. Lincoln City                  42  11  6  4  46:28    1  7 13  26:59    72:87  -15   49
19. West Ham United               42  12  6  3  56:31    1  3 17  19:62    75:93  -18   48
20. Burnley                       42   8  9  4  35:20    3  5 13  32:59    67:79  -12   47
21. Chesterfield                  42  10  5  6  36:25    2  5 14  25:59    61:84  -23   46
22. Charlton Athletic             42   9  3  9  35:35    3  4 14  25:56    60:91  -31   43
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Hull City                     42  18  3  0  69:14    8  4  9  31:31   100:45  +55   85
 2. Wrexham                       42  18  2  1  75:15    6  7  8  31:36   106:51  +55   81
 3. Stockport County              42  16  2  3  69:30    5 10  6  30:28    99:58  +41   75
 4. Chester                       42  15  4  2  57:25    7  4 10  37:41    94:66  +28   74
 5. Walsall                       42  16  4  1  53:15    3  6 12  22:43    75:58  +17   67
 6. Gateshead                     42  12  5  4  45:25    7  4 10  33:42    78:67  +11   66
 7. Barnsley                      42  14  3  4  60:31    5  5 11  32:49    92:80  +12   65
 8. Doncaster Rovers              42  13  8  0  52:26    4  6 11  25:53    77:79   -2   65
 9. Crewe Alexandra               42  16  3  2  57:16    4  0 17  23:68    80:84   -4   63
10. Barrow                        42  12  3  6  41:24    6  4 11  19:36    60:60        61
11. Tranmere Rovers               42  11  4  6  49:31    6  4 11  21:35    70:66   +4   59
12. Southport                     42  15  3  3  54:20    2  4 15  16:47    70:67   +3   58
13. Accrington Stanley            42  12  4  5  55:29    3  6 12  23:47    78:76   +2   55
14. Hartlepool United             42  15  3  3  56:29    1  4 16  31:87    87:116 -29   55
15. Halifax Town                  42  12  4  5  39:23    3  4 14  32:67    71:90  -19   53
16. Mansfield Town                42  13  4  4  57:22    1  3 17  27:78    84:100 -16   49
17. Rotherham United              42  14  3  4  42:21    0  3 18  18:63    60:84  -24   48
18. Rochdale                      42   9  4  8  32:33    4  3 14  26:47    58:80  -22   46
19. Carlisle United               42   8  7  6  34:25    5  0 16  17:50    51:75  -24   46
20. York City                     42  10  4  7  51:38    3  2 16  21:54    72:92  -20   45
21. New Brighton                  42   8  6  7  42:36    3  4 14  21:52    63:88  -25   43
22. Darlington                    42   9  6  6  42:32    1  2 18  24:77    66:109 -43   38
~~~

(Source: `3a-division3n.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Brentford                     42  15  4  2  45:19   11  6  4  45:30    90:49  +41   88
 2. Exeter City                   42  17  2  2  57:13    7  8  6  31:35    88:48  +40   82
 3. Norwich City                  42  16  3  2  49:17    6 10  5  39:38    88:55  +33   79
 4. Reading                       42  14  5  2  68:30    5  8  8  35:41   103:71  +32   70
 5. Crystal Palace                42  14  4  3  51:21    5  4 12  27:43    78:64  +14   65
 6. Coventry City                 42  16  1  4  75:24    3  5 13  31:53   106:77  +29   63
 7. Gillingham                    42  14  4  3  54:24    4  4 13  18:37    72:61  +11   62
 8. Northampton Town              42  16  5  0  54:11    2  3 16  22:55    76:66  +10   62
 9. Torquay United                42  12  7  2  51:26    4  5 12  21:41    72:67   +5   60
10. Watford                       42  11  8  2  37:22    5  4 12  29:41    66:63   +3   60
11. Bristol Rovers                42  13  5  3  38:22    2  9 10  23:34    61:56   +5   59
12. Brighton & Hove Albion        42  13  3  5  42:20    4  5 12  24:45    66:65   +1   59
13. Southend United               42  11  5  5  39:27    4  6 11  26:55    65:82  -17   56
14. Luton Town                    42  12  8  1  60:32    1  5 15  18:46    78:78        52
15. Queens Park Rangers           42   9  8  4  48:32    4  3 14  24:55    72:87  -15   50
16. Bristol City                  42  11  5  5  59:37    1  8 12  24:53    83:90   -7   49
17. Aldershot                     42  11  6  4  37:21    2  4 15  24:51    61:72  -11   49
18. AFC Bournemouth               42  10  7  4  44:27    2  5 14  16:54    60:81  -21   48
19. Cardiff City                  42  12  4  5  48:30    0  3 18  21:69    69:99  -30   43
20. Newport County                42   9  4  8  42:42    2  3 16  19:63    61:105 -44   40
21. Swindon Town                  42   7  9  5  36:29    2  2 17  24:76    60:105 -45   38
22. Leyton Orient                 42   7  8  6  39:35    1  5 15  20:58    59:93  -34   37
~~~

(Source: `3b-division3s.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

