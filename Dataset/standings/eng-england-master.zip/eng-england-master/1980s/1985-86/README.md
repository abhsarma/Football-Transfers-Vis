

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Liverpool                     42  16  4  1  58:14   10  6  5  31:23    89:37  +52   88
 2. Everton                       42  16  3  2  54:18   10  5  6  33:23    87:41  +46   86
 3. West Ham United               42  17  2  2  48:16    9  4  8  26:24    74:40  +34   84
 4. Manchester United             42  12  5  4  35:12   10  5  6  35:24    70:36  +34   76
 5. Sheffield Wednesday           42  13  6  2  36:23    8  4  9  27:31    63:54   +9   73
 6. Chelsea                       42  12  4  5  32:27    8  7  6  25:29    57:56   +1   71
 7. Arsenal                       42  13  5  3  29:15    7  4 10  20:32    49:47   +2   69
 8. Nottingham Forest             42  11  5  5  38:25    8  6  7  31:28    69:53  +16   68
 9. Luton Town                    42  12  6  3  37:15    6  6  9  24:29    61:44  +17   66
10. Tottenham Hotspur             42  12  2  7  47:25    7  6  8  27:27    74:52  +22   65
11. Newcastle United              42  12  5  4  46:31    5  7  9  21:41    67:72   -5   63
12. Watford                       42  11  6  4  40:22    5  5 11  29:40    69:62   +7   59
13. Queens Park Rangers           42  12  3  6  33:20    3  4 14  20:44    53:64  -11   52
14. Southampton                   42  10  6  5  32:18    2  4 15  19:44    51:62  -11   46
15. Manchester City               42   7  7  7  25:26    4  5 12  18:31    43:57  -14   45
16. Aston Villa                   42   7  6  8  27:28    3  8 10  24:39    51:67  -16   44
17. Coventry City                 42   6  5 10  31:35    5  5 11  17:36    48:71  -23   43
18. Oxford United                 42   7  7  7  34:27    3  5 13  28:53    62:80  -18   42
19. Leicester City                42   7  8  6  35:35    3  4 14  19:41    54:76  -22   42
20. Ipswich Town                  42   8  5  8  20:24    3  3 15  12:31    32:55  -23   41
21. Birmingham City               42   5  2 14  13:25    3  3 15  17:48    30:73  -43   29
22. West Bromwich Albion          42   3  8 10  21:36    1  4 16  14:53    35:89  -54   24
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Norwich City                  42  16  4  1  51:15    9  5  7  33:22    84:37  +47   84
 2. Charlton Athletic             42  14  5  2  44:15    8  6  7  34:30    78:45  +33   77
 3. Wimbledon                     42  13  6  2  38:16    8  7  6  20:21    58:37  +21   76
 4. Portsmouth                    42  13  4  4  43:17    9  3  9  26:24    69:41  +28   73
 5. Crystal Palace                42  12  3  6  29:22    7  6  8  28:30    57:52   +5   66
 6. Hull City                     42  11  7  3  39:19    6  6  9  26:36    65:55  +10   64
 7. Sheffield United              42  10  7  4  36:24    7  4 10  28:39    64:63   +1   62
 8. Oldham Athletic               42  13  4  4  40:28    4  5 12  22:33    62:61   +1   60
 9. Millwall                      42  12  3  6  39:24    5  5 11  25:41    64:65   -1   59
10. Stoke City                    42   8 11  2  29:16    6  4 11  19:34    48:50   -2   57
11. Brighton & Hove Albion        42  10  5  6  42:30    6  3 12  22:34    64:64        56
12. Barnsley                      42   9  6  6  29:26    5  8  8  18:24    47:50   -3   56
13. Bradford City                 42  14  1  6  36:24    2  5 14  15:39    51:63  -12   54
14. Leeds United                  42   9  7  5  30:22    6  1 14  26:50    56:72  -16   53
15. Grimsby Town                  42  11  4  6  35:24    3  6 12  23:38    58:62   -4   52
16. Huddersfield Town             42  10  6  5  30:23    4  4 13  21:44    51:67  -16   52
17. Shrewsbury Town               42  11  5  5  29:20    3  4 14  23:44    52:64  -12   51
18. Sunderland                    42  10  5  6  33:29    3  6 12  14:32    47:61  -14   50
19. Blackburn Rovers              42  10  4  7  30:20    2  9 10  23:42    53:62   -9   49
20. Carlisle United               42  10  2  9  30:28    3  5 13  17:43    47:71  -24   46
21. Middlesbrough                 42   8  6  7  26:23    4  3 14  18:30    44:53   -9   45
22. Fulham                        42   8  3 10  29:32    2  3 16  16:37    45:69  -24   36
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Reading                       46  16  3  4  39:22   13  4  6  28:29    67:51  +16   94
 2. Plymouth Argyle               46  17  3  3  56:20    9  6  8  32:33    88:53  +35   87
 3. Derby County                  46  13  7  3  45:20   10  8  5  35:21    80:41  +39   84
 4. Wigan Athletic                46  17  4  2  54:17    6 10  7  28:31    82:48  +34   83
 5. Gillingham                    46  14  5  4  48:17    8  8  7  33:37    81:54  +27   79
 6. Walsall                       46  15  7  1  59:23    7  2 14  31:41    90:64  +26   75
 7. York City                     46  16  4  3  49:17    4  7 12  28:41    77:58  +19   71
 8. Notts County                  46  12  6  5  42:26    7  8  8  29:34    71:60  +11   71
 9. Bristol City                  46  14  5  4  43:19    4  9 10  26:41    69:60   +9   68
10. Brentford                     46   8  8  7  29:29   10  4  9  29:32    58:61   -3   66
11. Doncaster Rovers              46   7 10  6  20:21    9  6  8  25:31    45:52   -7   64
12. Blackpool                     46  11  6  6  38:19    6  6 11  28:36    66:55  +11   63
13. Darlington                    46  10  7  6  39:33    5  6 12  22:45    61:78  -17   58
14. Rotherham United              46  13  5  5  44:18    2  7 14  17:41    61:59   +2   57
15. AFC Bournemouth               46   9  6  8  41:31    6  3 14  24:41    65:72   -7   54
16. Bristol Rovers                46   9  8  6  27:21    5  4 14  24:54    51:75  -24   54
17. Chesterfield                  46  10  6  7  41:30    3  8 12  20:34    61:64   -3   53
18. Bolton Wanderers              46  10  4  9  35:30    5  4 14  19:38    54:68  -14   53
19. Newport County                46   7  8  8  35:33    4 10  9  17:32    52:65  -13   51
20. Bury                          46  11  7  5  46:26    1  6 16  17:41    63:67   -4   49
21. Lincoln City                  46   7  9  7  33:34    3  7 13  22:43    55:77  -22   46
22. Cardiff City                  46   7  5 11  22:29    5  4 14  31:54    53:83  -30   45
23. Wolverhampton Wanderers       46   6  6 11  29:47    5  4 14  28:51    57:98  -41   43
24. Swansea City                  46   9  6  8  27:27    2  4 17  16:60    43:87  -44   43
~~~

(Source: `3-division3.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Swindon Town                  46  20  2  1  52:19   12  4  7  30:24    82:43  +39  102
 2. Chester                       46  15  5  3  44:16    8 10  5  39:34    83:50  +33   84
 3. Mansfield Town                46  13  8  2  43:17   10  4  9  31:30    74:47  +27   81
 4. Port Vale                     46  13  9  1  42:11    8  7  8  25:26    67:37  +30   79
 5. Leyton Orient                 46  11  6  6  39:21    9  6  8  40:43    79:64  +15   72
 6. Colchester United             46  12  6  5  51:22    7  7  9  37:41    88:63  +25   70
 7. Hartlepool United             46  15  6  2  41:20    5  4 14  27:47    68:67   +1   70
 8. Northampton Town              46   9  7  7  44:29    9  3 11  35:29    79:58  +21   64
 9. Southend United               46  13  4  6  43:27    5  6 12  26:40    69:67   +2   64
10. Hereford United               46  15  6  2  55:30    3  4 16  19:43    74:73   +1   64
11. Stockport County              46   9  9  5  35:28    8  4 11  28:43    63:71   -8   64
12. Crewe Alexandra               46  10  6  7  35:26    8  3 12  19:35    54:61   -7   63
13. Wrexham                       46  11  5  7  34:24    6  4 13  34:56    68:80  -12   60
14. Burnley                       46  11  3  9  35:30    5  8 10  25:35    60:65   -5   59
15. Scunthorpe United             46  11  7  5  33:23    4  7 12  17:32    50:55   -5   59
16. Aldershot                     46  12  5  6  45:25    5  2 16  21:49    66:74   -8   58
17. Peterborough United           46   9 11  3  31:19    4  6 13  21:45    52:64  -12   56
18. Rochdale                      46  12  7  4  41:29    2  6 15  16:48    57:77  -20   55
19. Tranmere Rovers               46   9  1 13  46:41    6  8  9  28:32    74:73   +1   54
20. Halifax Town                  46  10  8  5  35:27    4  4 15  25:44    60:71  -11   54
21. Exeter City                   46  10  4  9  26:25    3 11  9  21:34    47:59  -12   54
22. Cambridge United              46  12  2  9  45:38    3  7 13  20:42    65:80  -15   54
23. Preston North End             46   7  4 12  32:41    4  6 13  22:48    54:89  -35   43
24. Torquay United                46   8  5 10  29:32    1  5 17  14:56    43:88  -45   37
~~~

(Source: `4-division4.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

