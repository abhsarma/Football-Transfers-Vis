

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Liverpool                     38  13  5  1  38:15   10  5  4  40:22    78:37  +41   79
 2. Aston Villa                   38  13  3  3  36:20    8  4  7  21:18    57:38  +19   70
 3. Tottenham Hotspur             38  12  1  6  35:24    7  5  7  24:23    59:47  +12   63
 4. Arsenal                       38  14  3  2  38:11    4  5 10  16:27    54:38  +16   62
 5. Chelsea                       38   8  7  4  31:24    8  5  6  27:26    58:50   +8   60
 6. Everton                       38  14  3  2  40:16    3  5 11  17:30    57:46  +11   59
 7. Southampton                   38  10  5  4  40:27    5  5  9  31:36    71:63   +8   55
 8. Wimbledon                     38   5  8  6  22:23    8  8  3  25:17    47:40   +7   55
 9. Nottingham Forest             38   9  4  6  31:21    6  5  8  24:26    55:47   +8   54
10. Norwich City                  38   7 10  2  24:14    6  4  9  20:28    44:42   +2   53
11. Queens Park Rangers           38   9  4  6  27:22    4  7  8  18:22    45:44   +1   50
12. Coventry City                 38  11  2  6  24:25    3  5 11  15:34    39:59  -20   49
13. Manchester United             38   8  6  5  26:14    5  3 11  20:33    46:47   -1   48
14. Manchester City               38   9  4  6  26:21    3  8  8  17:31    43:52   -9   48
15. Crystal Palace                38   8  7  4  27:23    5  2 12  15:43    42:66  -24   48
16. Derby County                  38   9  1  9  29:21    4  6  9  14:19    43:40   +3   46
17. Luton Town                    38   8  8  3  24:18    2  5 12  19:39    43:57  -14   43
18. Sheffield Wednesday           38   8  6  5  21:17    3  4 12  14:34    35:51  -16   43
19. Charlton Athletic             38   4  6  9  18:25    3  3 13  13:32    31:57  -26   30
20. Millwall                      38   4  6  9  23:25    1  5 13  16:40    39:65  -26   26
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Leeds United                  46  16  6  1  46:18    8  7  8  33:34    79:52  +27   85
 2. Sheffield United              46  14  5  4  43:27   10  8  5  35:31    78:58  +20   85
 3. Newcastle United              46  17  4  2  51:26    5 10  8  29:29    80:55  +25   80
 4. Swindon Town                  46  12  6  5  49:29    8  8  7  30:30    79:59  +20   74
 5. Blackburn Rovers              46  10  9  4  43:30    9  8  6  31:29    74:59  +15   74
 6. Sunderland                    46  10  8  5  41:32   10  6  7  29:32    70:64   +6   74
 7. West Ham United               46  14  5  4  50:22    6  7 10  30:35    80:57  +23   72
 8. Oldham Athletic               46  15  7  1  50:23    4  7 12  20:34    70:57  +13   71
 9. Ipswich Town                  46  13  7  3  38:22    6  5 12  29:44    67:66   +1   69
10. Wolverhampton Wanderers       46  12  5  6  37:20    6  8  9  30:40    67:60   +7   67
11. Port Vale                     46  11  9  3  37:20    4  7 12  25:37    62:57   +5   61
12. Portsmouth                    46   9  8  6  40:34    6  8  9  22:31    62:65   -3   61
13. Leicester City                46  10  8  5  34:29    5  6 12  33:50    67:79  -12   59
14. Hull City                     46   7  8  8  27:31    7  8  8  31:34    58:65   -7   58
15. Watford                       46  11  6  6  41:28    3  9 11  17:32    58:60   -2   57
16. Plymouth Argyle               46   9  8  6  30:23    5  5 13  28:40    58:63   -5   55
17. Oxford United                 46   8  7  8  35:31    7  2 14  22:35    57:66   -9   54
18. Brighton & Hove Albion        46  10  6  7  28:27    5  3 15  28:45    56:72  -16   54
19. Barnsley                      46   7  9  7  22:23    6  6 11  27:48    49:71  -22   54
20. West Bromwich Albion          46   6  8  9  35:37    6  7 10  32:34    67:71   -4   51
21. Middlesbrough                 46  10  3 10  33:29    3  8 12  19:34    52:63  -11   50
22. AFC Bournemouth               46   8  6  9  30:31    4  6 13  27:45    57:76  -19   48
23. Bradford City                 46   9  6  8  26:24    0  8 15  18:44    44:68  -24   41
24. Stoke City                    46   4 11  8  20:24    2  8 13  15:39    35:63  -28   37
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Bristol Rovers                46  15  8  0  43:14   11  7  5  28:21    71:35  +36   93
 2. Bristol City                  46  15  5  3  40:16   12  5  6  36:24    76:40  +36   91
 3. Notts County                  46  17  4  2  40:18    8  8  7  33:35    73:53  +20   87
 4. Tranmere Rovers               46  15  5  3  54:22    8  6  9  32:27    86:49  +37   80
 5. Bury                          46  11  7  5  35:19   10  4  9  35:30    70:49  +21   74
 6. Bolton Wanderers              46  12  7  4  32:19    6  8  9  27:29    59:48  +11   69
 7. Birmingham City               46  10  7  6  33:19    8  5 10  27:40    60:59   +1   66
 8. Huddersfield Town             46  11  5  7  30:23    6  9  8  31:39    61:62   -1   65
 9. Rotherham United              46  12  6  5  48:28    5  7 11  23:34    71:62   +9   64
10. Reading                       46  10  9  4  33:21    5 10  8  24:32    57:53   +4   64
11. Shrewsbury Town               46  10  9  4  38:24    6  6 11  21:30    59:54   +5   63
12. Crewe Alexandra               46  10  8  5  32:24    5  9  9  24:29    56:53   +3   62
13. Brentford                     46  11  4  8  41:31    7  3 13  25:35    66:66        61
14. Leyton Orient                 46   9  6  8  28:24    7  4 12  24:32    52:56   -4   58
15. Mansfield Town                46  13  2  8  34:25    3  5 15  16:40    50:65  -15   55
16. Chester                       46  11  7  5  30:23    2  8 13  13:32    43:55  -12   54
17. Swansea City                  46  10  6  7  25:27    4  6 13  20:36    45:63  -18   54
18. Wigan Athletic                46  10  6  7  29:22    3  8 12  19:42    48:64  -16   53
19. Preston North End             46  10  7  6  42:30    4  3 16  23:49    65:79  -14   52
20. Fulham                        46   8  8  7  33:27    4  7 12  22:39    55:66  -11   51
21. Cardiff City                  46   6  9  8  30:35    6  5 12  21:35    51:70  -19   50
22. Northampton Town              46   7  7  9  27:31    4  7 12  24:37    51:68  -17   47
23. Blackpool                     46   8  6  9  29:33    2 10 11  20:40    49:73  -24   46
24. Walsall                       46   6  8  9  23:30    3  6 14  17:42    40:72  -32   41
~~~

(Source: `3-division3.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Exeter City                   46  20  3  0  50:14    8  2 13  33:34    83:48  +35   89
 2. Grimsby Town                  46  14  4  5  41:20    8  9  6  29:27    70:47  +23   79
 3. Southend United               46  15  3  5  35:14    7  6 10  26:34    61:48  +13   75
 4. Stockport County              46  13  6  4  45:27    8  5 10  23:35    68:62   +6   74
 5. Maidstone United              46  14  4  5  49:21    8  3 12  28:40    77:61  +16   73
 6. Cambridge United              46  14  3  6  45:30    7  7  9  31:36    76:66  +10   73
 7. Chesterfield                  46  12  9  2  41:19    7  5 11  22:31    63:50  +13   71
 8. Carlisle United               46  15  4  4  38:20    6  4 13  23:40    61:60   +1   71
 9. Peterborough United           46  10  8  5  35:23    7  9  7  24:23    59:46  +13   68
10. Lincoln City                  46  11  6  6  30:27    7  8  8  18:21    48:48        68
11. Scunthorpe United             46   9  9  5  42:25    8  6  9  27:29    69:54  +15   66
12. Rochdale                      46  11  4  8  28:23    9  2 12  24:32    52:55   -3   66
13. York City                     46  10  5  8  29:24    6 11  6  26:29    55:53   +2   64
14. Gillingham                    46   9  8  6  28:21    8  3 12  18:27    46:48   -2   62
15. Torquay United                46  12  2  9  33:29    3 10 10  20:37    53:66  -13   57
16. Burnley                       46   6 10  7  19:18    8  4 11  26:37    45:55  -10   56
17. Hereford United               46   7  4 12  31:32    8  6  9  25:30    56:62   -6   55
18. Scarborough                   46  10  5  8  35:28    5  5 13  25:45    60:73  -13   55
19. Hartlepool United             46  12  4  7  45:33    3  6 14  21:55    66:88  -22   55
20. Doncaster Rovers              46   7  7  9  29:29    7  2 14  24:31    53:60   -7   51
21. Wrexham                       46   8  8  7  28:28    5  4 14  23:39    51:67  -16   51
22. Aldershot                     46   8  7  8  28:26    4  7 12  22:43    50:69  -19   50
23. Halifax Town                  46   5  9  9  31:30    7  4 12  26:36    57:66   -9   49
24. Colchester United             46   9  3 11  26:25    2  7 14  22:50    48:75  -27   43
~~~

(Source: `4-division4.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

