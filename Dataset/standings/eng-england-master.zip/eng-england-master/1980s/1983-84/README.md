

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Liverpool                     42  14  5  2  50:12    8  9  4  23:20    73:32  +41   80
 2. Southampton                   42  15  4  2  44:17    7  7  7  22:21    66:38  +28   77
 3. Nottingham Forest             42  14  4  3  47:17    8  4  9  29:28    76:45  +31   74
 4. Manchester United             42  14  3  4  43:18    6 11  4  28:23    71:41  +30   74
 5. Queens Park Rangers           42  14  4  3  37:12    8  3 10  30:25    67:37  +30   73
 6. Arsenal                       42  10  5  6  41:29    8  4  9  33:31    74:60  +14   63
 7. Everton                       42   9  9  3  21:12    7  5  9  23:30    44:42   +2   62
 8. Tottenham Hotspur             42  11  4  6  31:24    6  6  9  33:41    64:65   -1   61
 9. West Ham United               42  10  4  7  39:24    7  5  9  21:31    60:55   +5   60
10. Aston Villa                   42  14  3  4  34:22    3  6 12  25:39    59:61   -2   60
11. Watford                       42   9  7  5  36:31    7  2 12  32:46    68:77   -9   57
12. Ipswich Town                  42  11  4  6  34:23    4  4 13  21:34    55:57   -2   53
13. Sunderland                    42   8  9  4  26:18    5  4 12  16:35    42:53  -11   52
14. Norwich City                  42   9  8  4  34:20    3  7 11  14:29    48:49   -1   51
15. Leicester City                42  11  5  5  40:30    2  7 12  25:38    65:68   -3   51
16. Luton Town                    42   7  5  9  30:33    7  4 10  23:33    53:66  -13   51
17. West Bromwich Albion          42  10  4  7  30:25    4  5 12  18:37    48:62  -14   51
18. Stoke City                    42  11  4  6  30:23    2  7 12  14:40    44:63  -19   50
19. Coventry City                 42   8  5  8  33:33    5  6 10  24:44    57:77  -20   50
20. Birmingham City               42   7  7  7  19:18    5  5 11  20:32    39:50  -11   48
21. Notts County                  42   6  7  8  31:36    4  4 13  19:36    50:72  -22   41
22. Wolverhampton Wanderers       42   4  8  9  15:28    2  3 16  12:52    27:80  -53   29
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Chelsea                       42  15  4  2  55:17   10  9  2  35:23    90:40  +50   88
 2. Sheffield Wednesday           42  16  4  1  47:16   10  6  5  25:18    72:34  +38   88
 3. Newcastle United              42  16  2  3  51:18    8  6  7  34:35    85:53  +32   80
 4. Manchester City               42  13  3  5  43:21    7  7  7  23:27    66:48  +18   70
 5. Grimsby Town                  42  13  6  2  36:15    6  7  8  24:32    60:47  +13   70
 6. Blackburn Rovers              42   9 11  1  35:19    8  5  8  22:27    57:46  +11   67
 7. Carlisle United               42  10  9  2  29:13    6  7  8  19:28    48:41   +7   64
 8. Shrewsbury Town               42  13  5  3  34:18    4  5 12  15:35    49:53   -4   61
 9. Brighton & Hove Albion        42  11  6  4  42:17    6  3 12  27:43    69:60   +9   60
10. Leeds United                  42  13  4  4  33:16    3  8 10  22:40    55:56   -1   60
11. Fulham                        42   9  6  6  35:24    6  6  9  25:29    60:53   +7   57
12. Huddersfield Town             42   8  6  7  27:20    6  9  6  29:29    56:49   +7   57
13. Charlton Athletic             42  13  4  4  40:26    3  5 13  13:38    53:64  -11   57
14. Barnsley                      42   9  6  6  33:23    6  1 14  24:30    57:53   +4   52
15. Cardiff City                  42  11  3  7  32:27    4  3 14  21:39    53:66  -13   51
16. Portsmouth                    42   8  3 10  46:32    6  4 11  27:32    73:64   +9   49
17. Middlesbrough                 42   9  8  4  26:18    3  5 13  15:29    41:47   -6   49
18. Crystal Palace                42   8  5  8  18:18    4  6 11  24:34    42:52  -10   47
19. Oldham Athletic               42  10  6  5  33:27    3  2 16  14:46    47:73  -26   47
20. Derby County                  42   9  5  7  26:26    2  4 15  10:46    36:72  -36   42
21. Swansea City                  42   7  4 10  20:28    0  4 17  16:57    36:85  -49   29
22. Cambridge United              42   4  7 10  20:33    0  5 16   8:44    28:77  -49   24
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Oxford United                 46  17  5  1  58:22   11  6  6  33:28    91:50  +41   95
 2. Wimbledon                     46  15  5  3  58:35   11  4  8  39:41    97:76  +21   87
 3. Sheffield United              46  14  7  2  56:18   10  4  9  30:35    86:53  +33   83
 4. Hull City                     46  16  5  2  42:11    7  9  7  29:27    71:38  +33   83
 5. Bristol Rovers                46  16  5  2  47:21    6  8  9  21:33    68:54  +14   79
 6. Walsall                       46  14  4  5  44:22    8  5 10  24:39    68:61   +7   75
 7. Bradford City                 46  11  9  3  46:30    9  2 12  27:35    73:65   +8   71
 8. Gillingham                    46  13  4  6  50:29    7  6 10  24:40    74:69   +5   70
 9. Millwall                      46  16  4  3  42:18    2  9 12  29:47    71:65   +6   67
10. Bolton Wanderers              46  13  4  6  36:17    5  6 12  20:43    56:60   -4   64
11. Leyton Orient                 46  13  5  5  40:27    5  4 14  31:54    71:81  -10   63
12. Burnley                       46  12  5  6  52:25    4  9 10  24:36    76:61  +15   62
13. Newport County                46  11  9  3  35:27    5  5 13  23:48    58:75  -17   62
14. Lincoln City                  46  11  4  8  42:29    6  6 11  17:33    59:62   -3   61
15. Wigan Athletic                46  11  5  7  26:18    5  8 10  20:38    46:56  -10   61
16. Preston North End             46  12  5  6  42:27    3  6 14  24:39    66:66        56
17. AFC Bournemouth               46  11  5  7  38:27    5  2 16  25:46    63:73  -10   55
18. Rotherham United              46  10  5  8  29:17    5  4 14  28:47    57:64   -7   54
19. Plymouth Argyle               46  11  8  4  38:17    2  4 17  18:45    56:62   -6   51
20. Brentford                     46   8  9  6  41:30    3  7 13  28:49    69:79  -10   49
21. Scunthorpe United             46   9  9  5  40:31    0 10 13  14:42    54:73  -19   46
22. Southend United               46   8  9  6  34:24    2  5 16  21:52    55:76  -21   44
23. Port Vale                     46  10  4  9  33:29    1  6 16  18:54    51:83  -32   43
24. Exeter City                   46   4  8 11  27:39    2  7 14  23:45    50:84  -34   33
~~~

(Source: `3-division3.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. York City                     46  18  4  1  58:16   13  4  6  38:23    96:39  +57  101
 2. Doncaster Rovers              46  15  6  2  46:22    9  7  7  36:32    82:54  +28   85
 3. Reading                       46  17  6  0  51:14    5 10  8  33:42    84:56  +28   82
 4. Bristol City                  46  18  3  2  51:17    6  7 10  19:27    70:44  +26   82
 5. Aldershot                     46  14  6  3  49:29    8  3 12  27:40    76:69   +7   75
 6. Blackpool                     46  15  4  4  47:19    6  5 12  23:33    70:52  +18   72
 7. Peterborough United           46  15  5  3  52:16    3  9 11  20:32    72:48  +24   68
 8. Colchester United             46  14  7  2  45:14    3  9 11  24:39    69:53  +16   67
 9. Torquay United                46  13  7  3  32:18    5  6 12  27:46    59:64   -5   67
10. Tranmere Rovers               46  11  5  7  33:26    6 10  7  20:27    53:53        66
11. Hereford United               46  11  6  6  31:21    5  9  9  23:32    54:53   +1   63
12. Stockport County              46  12  5  6  34:25    5  6 12  26:39    60:64   -4   62
13. Chesterfield                  46  10 11  2  34:24    5  4 14  25:37    59:61   -2   60
14. Darlington                    46  13  4  6  31:19    4  4 15  18:31    49:50   -1   59
15. Bury                          46   9  7  7  34:32    6  7 10  27:32    61:64   -3   59
16. Crewe Alexandra               46  10  8  5  35:27    6  3 14  21:40    56:67  -11   59
17. Swindon Town                  46  11  7  5  34:23    4  6 13  24:33    58:56   +2   58
18. Northampton Town              46  10  8  5  32:32    3  6 14  21:46    53:78  -25   53
19. Mansfield Town                46   9  7  7  44:27    4  6 13  22:43    66:70   -4   52
20. Wrexham                       46   7  6 10  34:33    4  9 10  25:41    59:74  -15   48
21. Halifax Town                  46  11  6  6  36:25    1  6 16  19:64    55:89  -34   48
22. Rochdale                      46   8  9  6  35:31    3  4 16  17:49    52:80  -28   46
23. Hartlepool United             46   7  8  8  31:28    3  2 18  16:57    47:85  -38   40
24. Chester                       46   7  5 11  23:35    0  8 15  22:47    45:82  -37   34
~~~

(Source: `4-division4.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

