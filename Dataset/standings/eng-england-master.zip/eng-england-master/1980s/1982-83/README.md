

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Liverpool                     42  16  4  1  55:16    8  6  7  32:21    87:37  +50   82
 2. Watford                       42  16  2  3  49:20    6  3 12  25:37    74:57  +17   71
 3. Manchester United             42  14  7  0  39:10    5  6 10  17:28    56:38  +18   70
 4. Tottenham Hotspur             42  15  4  2  50:15    5  5 11  15:35    65:50  +15   69
 5. Nottingham Forest             42  12  5  4  34:18    8  4  9  28:32    62:50  +12   69
 6. Aston Villa                   42  17  2  2  47:15    4  3 14  15:35    62:50  +12   68
 7. Everton                       42  13  6  2  43:19    5  4 12  23:29    66:48  +18   64
 8. West Ham United               42  13  3  5  41:23    7  1 13  27:39    68:62   +6   64
 9. Ipswich Town                  42  11  3  7  39:23    4 10  7  25:27    64:50  +14   58
10. Arsenal                       42  11  6  4  36:19    5  4 12  22:37    58:56   +2   58
11. West Bromwich Albion          42  11  5  5  35:20    4  7 10  16:29    51:49   +2   57
12. Southampton                   42  11  5  5  36:22    4  7 10  18:36    54:58   -4   57
13. Stoke City                    42  13  4  4  34:21    3  5 13  19:43    53:64  -11   57
14. Norwich City                  42  10  6  5  30:18    4  6 11  22:40    52:58   -6   54
15. Notts County                  42  12  4  5  37:25    3  3 15  18:46    55:71  -16   52
16. Sunderland                    42   7 10  4  30:22    5  4 12  18:39    48:61  -13   50
17. Birmingham City               42   9  7  5  29:24    3  7 11  11:31    40:55  -15   50
18. Luton Town                    42   7  7  7  34:33    5  6 10  31:51    65:84  -19   49
19. Coventry City                 42  10  5  6  29:17    3  4 14  19:42    48:59  -11   48
20. Manchester City               42   9  5  7  26:23    4  3 14  21:47    47:70  -23   47
21. Swansea City                  42  10  4  7  32:29    0  7 14  19:40    51:69  -18   41
22. Brighton & Hove Albion        42   8  7  6  25:22    1  6 14  13:46    38:68  -30   40
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Queens Park Rangers           42  16  3  2  51:16   10  4  7  26:20    77:36  +41   85
 2. Wolverhampton Wanderers       42  14  5  2  42:16    6 10  5  26:28    68:44  +24   75
 3. Leicester City                42  11  4  6  36:15    9  6  6  36:29    72:44  +28   70
 4. Fulham                        42  13  5  3  36:20    7  4 10  28:27    64:47  +17   69
 5. Newcastle United              42  13  6  2  43:21    5  7  9  32:32    75:53  +22   67
 6. Sheffield Wednesday           42   9  8  4  33:23    7  7  7  27:24    60:47  +13   63
 7. Oldham Athletic               42   8 10  3  38:24    6  9  6  26:23    64:47  +17   61
 8. Leeds United                  42   7 11  3  28:22    6 10  5  23:24    51:46   +5   60
 9. Shrewsbury Town               42   8  9  4  20:15    7  5  9  28:33    48:48        59
10. Barnsley                      42   9  8  4  37:28    5  7  9  20:27    57:55   +2   57
11. Blackburn Rovers              42  11  7  3  38:21    4  5 12  20:37    58:58        57
12. Cambridge United              42  11  7  3  26:17    2  5 14  16:43    42:60  -18   51
13. Derby County                  42   7 10  4  27:24    3  9  9  22:34    49:58   -9   49
14. Carlisle United               42  10  6  5  44:28    2  6 13  24:42    68:70   -2   48
15. Crystal Palace                42  11  7  3  31:17    1  5 15  12:35    43:52   -9   48
16. Middlesbrough                 42   8  7  6  27:29    3  8 10  19:38    46:67  -21   48
17. Charlton Athletic             42  11  3  7  40:31    2  6 13  23:55    63:86  -23   48
18. Chelsea                       42   8  8  5  31:22    3  6 12  20:39    51:61  -10   47
19. Grimsby Town                  42   9  7  5  32:26    3  4 14  13:44    45:70  -25   47
20. Rotherham United              42   6  7  8  22:29    4  8  9  23:39    45:68  -23   45
21. Burnley                       42  10  4  7  38:24    2  4 15  18:42    56:66  -10   44
22. Bolton Wanderers              42  10  2  9  30:26    1  9 11  12:35    42:61  -19   44
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Portsmouth                    46  16  4  3  43:19   11  6  6  31:22    74:41  +33   91
 2. Cardiff City                  46  17  5  1  45:14    8  6  9  31:36    76:50  +26   86
 3. Huddersfield Town             46  15  8  0  56:18    8  5 10  28:31    84:49  +35   82
 4. Newport County                46  13  7  3  40:20   10  2 11  36:34    76:54  +22   78
 5. Oxford United                 46  12  9  2  41:23   10  3 10  30:30    71:53  +18   78
 6. Lincoln City                  46  17  1  5  55:22    6  6 11  22:29    77:51  +26   76
 7. Bristol Rovers                46  16  4  3  55:21    6  5 12  29:37    84:58  +26   75
 8. Plymouth Argyle               46  15  2  6  37:23    4  6 13  24:43    61:66   -5   65
 9. Brentford                     46  14  4  5  50:28    4  6 13  38:49    88:77  +11   64
10. Walsall                       46  14  5  4  38:19    3  8 12  26:44    64:63   +1   64
11. Sheffield United              46  16  3  4  44:20    3  4 16  18:44    62:64   -2   64
12. Bradford City                 46  11  7  5  41:27    5  6 12  27:42    68:69   -1   61
13. Gillingham                    46  12  4  7  37:29    4  9 10  21:30    58:59   -1   61
14. AFC Bournemouth               46  11  7  5  35:20    5  6 12  24:48    59:68   -9   61
15. Southend United               46  10  8  5  41:28    5  6 12  25:37    66:65   +1   59
16. Preston North End             46  11 10  2  35:17    4  3 16  25:52    60:69   -9   58
17. Millwall                      46  12  7  4  41:24    2  6 15  23:53    64:77  -13   55
18. Wigan Athletic                46  10  4  9  35:33    5  5 13  25:39    60:72  -12   54
19. Exeter City                   46  12  4  7  49:43    2  8 13  32:61    81:104 -23   54
20. Leyton Orient                 46  10  6  7  44:38    5  3 15  20:50    64:88  -24   54
21. Reading                       46  10  8  5  37:28    2  9 12  27:51    64:79  -15   53
22. Wrexham                       46  11  6  6  40:26    1  9 13  16:50    56:76  -20   51
23. Doncaster Rovers              46   6  8  9  38:44    3  3 17  19:53    57:97  -40   38
24. Chesterfield                  46   6  6 11  28:28    2  7 14  15:40    43:68  -25   37
~~~

(Source: `3-division3.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Wimbledon                     46  17  4  2  57:23   12  7  4  39:22    96:45  +51   98
 2. Hull City                     46  14  8  1  48:14   11  7  5  27:20    75:34  +41   90
 3. Port Vale                     46  15  4  4  37:16   11  6  6  30:18    67:34  +33   88
 4. Scunthorpe United             46  13  7  3  41:17   10  7  6  30:25    71:42  +29   83
 5. Bury                          46  15  4  4  43:20    8  8  7  31:26    74:46  +28   81
 6. Colchester United             46  17  5  1  51:19    7  4 12  24:36    75:55  +20   81
 7. York City                     46  18  4  1  59:19    4  9 10  29:39    88:58  +30   79
 8. Swindon Town                  46  14  3  6  45:27    5  8 10  16:27    61:54   +7   68
 9. Peterborough United           46  13  6  4  38:23    4  7 12  20:29    58:52   +6   64
10. Mansfield Town                46  11  6  6  32:26    5  7 11  29:44    61:70   -9   61
11. Halifax Town                  46   9  8  6  31:23    7  4 12  28:43    59:66   -7   60
12. Torquay United                46  12  3  8  38:30    5  4 14  18:35    56:65   -9   58
13. Chester                       46   8  6  9  28:24    7  5 11  27:36    55:60   -5   56
14. Bristol City                  46  10  8  5  32:25    3  9 11  27:45    59:70  -11   56
15. Northampton Town              46  10  8  5  43:29    4  4 15  22:46    65:75  -10   54
16. Stockport County              46  11  8  4  41:31    3  4 16  19:48    60:79  -19   54
17. Darlington                    46   8  5 10  27:30    5  8 10  34:41    61:71  -10   52
18. Blackpool                     46  10  8  5  32:23    3  4 16  23:51    55:74  -19   51
19. Aldershot                     46  11  5  7  40:35    1 10 12  21:47    61:82  -21   51
20. Tranmere Rovers               46   8  8  7  30:29    5  3 15  19:42    49:71  -22   50
21. Rochdale                      46  11  8  4  38:25    0  8 15  17:48    55:73  -18   49
22. Hartlepool United             46  11  5  7  30:24    2  4 17  16:52    46:76  -30   48
23. Crewe Alexandra               46   9  5  9  35:32    2  3 18  18:39    53:71  -18   41
24. Hereford United               46   8  6  9  19:23    3  2 18  23:56    42:79  -37   41
~~~

(Source: `4-division4.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

