

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Everton                       38   8  5  6  44:29   11  3  5  32:18    76:47  +29   65
 2. Oldham Athletic               38  11  5  3  46:25    6  6  7  24:31    70:56  +14   62
 3. Blackburn Rovers              38  11  4  4  51:27    7  3  9  32:34    83:61  +22   61
 4. Burnley                       38  12  1  6  38:18    6  6  7  23:29    61:47  +14   61
 5. Sunderland                    38  11  3  5  46:30    7  2 10  35:42    81:72   +9   59
 6. Manchester City               38   9  7  3  29:15    6  6  7  20:24    49:39  +10   58
 7. Sheffield United              38  11  5  3  28:13    4  8  7  21:28    49:41   +8   58
 8. Sheffield Wednesday           38  10  7  2  43:23    5  6  8  18:31    61:54   +7   58
 9. Bradford Park Avenue          38  11  4  4  40:20    6  3 10  29:45    69:65   +4   58
10. West Bromwich Albion          38  11  5  3  31:9     4  5 10  18:34    49:43   +6   55
11. Bradford City                 38  11  7  1  40:18    2  7 10  15:31    55:49   +6   53
12. Liverpool                     38  11  5  3  45:34    3  4 12  20:41    65:75  -10   51
13. Middlesbrough                 38  10  6  3  42:24    3  6 10  20:50    62:74  -12   51
14. Aston Villa                   38  10  5  4  39:32    3  6 10  23:40    62:72  -10   50
15. Newcastle United              38   8  4  7  29:23    3  6 10  17:25    46:48   -2   43
16. Bolton Wanderers              38   8  5  6  35:27    3  3 13  33:57    68:84  -16   41
17. Notts County                  38   8  7  4  28:18    1  6 12  13:39    41:57  -16   40
18. Manchester United             38   8  6  5  27:19    1  6 12  19:43    46:62  -16   39
19. Chelsea                       38   8  6  5  32:25    0  7 12  19:40    51:65  -14   37
20. Tottenham Hotspur             38   7  7  5  30:29    1  5 13  27:61    57:90  -33   36
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Derby County                  38  14  3  2  40:11    9  4  6  31:22    71:33  +38   76
 2. Preston North End             38  14  4  1  41:16    6  6  7  20:26    61:42  +19   70
 3. Barnsley                      38  16  2  1  31:10    6  1 12  20:41    51:51        69
 4. Wolverhampton Wanderers       38  12  4  3  47:13    7  3  9  30:39    77:52  +25   64
 5. Arsenal                       38  15  1  3  52:13    4  4 11  17:28    69:41  +28   62
 6. Hull City                     38  12  2  5  36:23    7  3  9  29:31    65:54  +11   62
 7. Birmingham City               38  13  3  3  44:13    4  6  9  18:26    62:39  +23   60
 8. Huddersfield Town             38  12  4  3  36:13    5  4 10  25:29    61:42  +19   59
 9. Leyton Orient                 38  12  5  2  36:17    4  4 11  14:31    50:48   +2   57
10. Blackpool                     38  11  3  5  40:22    6  2 11  18:35    58:57   +1   56
11. Bury                          38  11  5  3  39:19    4  3 12  22:37    61:56   +5   53
12. Bristol City                  38  11  2  6  38:19    4  5 10  24:37    62:56   +6   52
13. Fulham                        38  12  0  7  35:20    3  7  9  18:27    53:47   +6   52
14. Stockport County              38  12  4  3  33:19    3  3 13  21:41    54:60   -6   52
15. Leeds City                    38   9  3  7  40:25    5  1 13  25:39    65:64   +1   46
16. Lincoln City                  38   9  4  6  29:23    2  5 12  17:42    46:65  -19   42
17. Grimsby Town                  38  10  4  5  36:24    1  5 13  12:52    48:76  -28   42
18. Nottingham Forest             38   9  7  3  32:24    1  2 16  11:53    43:77  -34   39
19. Leicester City                38   6  4  9  31:41    4  0 15  16:47    47:88  -41   34
20. Glossop North End             38   5  5  9  21:33    1  1 17  10:54    31:87  -56   24
~~~

(Source: `2-division2.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

