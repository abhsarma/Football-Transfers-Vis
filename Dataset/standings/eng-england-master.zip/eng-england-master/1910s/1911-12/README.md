

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Blackburn Rovers              38  13  6  0  35:10    7  3  9  25:33    60:43  +17   69
 2. Everton                       38  13  5  1  29:12    7  1 11  17:30    46:42   +4   66
 3. Bolton Wanderers              38  14  2  3  35:15    6  1 12  19:28    54:43  +11   63
 4. Newcastle United              38  10  4  5  37:25    8  4  7  27:25    64:50  +14   62
 5. Aston Villa                   38  12  2  5  48:22    5  5  9  28:41    76:63  +13   58
 6. Sheffield Wednesday           38  11  3  5  44:17    5  6  8  25:32    69:49  +20   57
 7. Middlesbrough                 38  11  6  2  35:17    5  2 12  21:28    56:45  +11   56
 8. West Bromwich Albion          38  10  6  3  23:15    5  3 11  20:32    43:47   -4   54
 9. Sunderland                    38  10  6  3  37:14    4  5 10  21:37    58:51   +7   53
10. Arsenal                       38  12  3  4  38:19    3  5 11  17:40    55:59   -4   53
11. Bradford City                 38  12  3  4  31:15    3  5 11  15:35    46:50   -4   53
12. Tottenham Hotspur             38  10  4  5  35:20    4  5 10  18:33    53:53        51
13. Manchester United             38   9  5  5  29:19    4  6  9  16:41    45:60  -15   50
14. Sheffield United              38  10  4  5  47:29    3  6 10  16:27    63:56   +7   49
15. Notts County                  38   9  4  6  26:20    5  3 11  20:43    46:63  -17   49
16. Manchester City               38  10  5  4  39:20    3  4 12  17:38    56:58   -2   48
17. Liverpool                     38   8  4  7  27:23    4  6  9  22:32    49:55   -6   46
18. Oldham Athletic               38  10  3  6  32:19    2  7 10  14:35    46:54   -8   46
19. Preston North End             38   8  4  7  26:25    5  3 11  14:32    40:57  -17   46
20. Bury                          38   6  5  8  23:25    0  4 15   9:34    32:59  -27   27
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Chelsea                       38  15  2  2  36:13    9  4  6  28:21    64:34  +30   78
 2. Derby County                  38  15  2  2  55:13    8  6  5  19:15    74:28  +46   77
 3. Burnley                       38  14  5  0  50:14    8  3  8  27:27    77:41  +36   74
 4. Leyton Orient                 38  16  0  3  44:14    5  3 11  17:30    61:44  +17   66
 5. Hull City                     38  12  3  4  36:13    5  5  9  18:38    54:51   +3   59
 6. Wolverhampton Wanderers       38  12  3  4  41:10    4  7  8  16:23    57:33  +24   58
 7. Barnsley                      38  10  5  4  28:19    5  7  7  17:23    45:42   +3   57
 8. Fulham                        38  10  3  6  42:24    6  4  9  24:34    66:58   +8   55
 9. Grimsby Town                  38   9  6  4  24:18    6  3 10  24:37    48:55   -7   54
10. Leicester City                38  11  4  4  34:18    4  3 12  15:48    49:66  -17   52
11. Bradford Park Avenue          38  10  5  4  30:16    3  4 12  14:29    44:45   -1   48
12. Birmingham City               38  11  3  5  44:29    3  3 13  11:30    55:59   -4   48
13. Bristol City                  38  11  4  4  27:17    3  2 14  14:43    41:60  -19   48
14. Blackpool                     38  12  4  3  24:12    1  4 14   8:40    32:52  -20   47
15. Nottingham Forest             38   9  3  7  26:18    4  4 11  20:30    46:48   -2   46
16. Huddersfield Town             38   8  5  6  30:22    5  1 13  20:42    50:64  -14   45
17. Stockport County              38   8  5  6  31:22    3  6 10  16:32    47:54   -7   44
18. Leeds City                    38   7  6  6  21:22    3  2 14  29:56    50:78  -28   38
19. Glossop North End             38   6  8  5  33:23    2  4 13   9:33    42:56  -14   36
20. Gainsborough Trinity          38   4  6  9  17:22    1  7 11  13:42    30:64  -34   28
~~~

(Source: `2-division2.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

