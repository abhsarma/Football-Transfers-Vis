

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Manchester United             38  14  4  1  47:18    8  4  7  25:22    72:40  +32   74
 2. Aston Villa                   38  15  3  1  50:18    7  4  8  19:23    69:41  +28   73
 3. Bradford City                 38  13  1  5  33:16    7  4  8  18:26    51:42   +9   65
 4. Everton                       38  12  3  4  34:17    7  4  8  16:19    50:36  +14   64
 5. Sunderland                    38  10  6  3  44:22    5  9  5  23:26    67:48  +19   60
 6. Sheffield Wednesday           38  10  5  4  24:15    7  3  9  23:33    47:48   -1   59
 7. Oldham Athletic               38  13  4  2  30:12    3  5 11  14:29    44:41   +3   57
 8. Newcastle United              38   8  7  4  37:18    7  3  9  24:25    61:43  +18   55
 9. Sheffield United              38   8  3  8  27:21    7  5  7  22:22    49:43   +6   53
10. Liverpool                     38  11  3  5  38:19    4  4 11  15:34    53:53        52
11. Notts County                  38   9  6  4  21:16    5  4 10  16:29    37:45   -8   52
12. Arsenal                       38   9  6  4  24:14    4  6  9  17:35    41:49   -8   51
13. Blackburn Rovers              38  12  2  5  40:14    1  9  9  22:40    62:54   +8   50
14. Preston North End             38   8  5  6  25:19    4  6  9  15:30    40:49   -9   47
15. Tottenham Hotspur             38  10  5  4  40:23    3  1 15  12:40    52:63  -11   45
16. Middlesbrough                 38   9  5  5  31:21    2  5 12  18:42    49:63  -14   43
17. Manchester City               38   7  5  7  26:26    2  8  9  17:32    43:58  -15   40
18. Bristol City                  38   8  4  7  23:21    3  1 15  20:45    43:66  -23   38
19. Bury                          38   8  9  2  27:18    1  2 16  16:53    43:71  -28   38
20. Nottingham Forest             38   5  4 10  28:31    4  3 12  27:44    55:75  -20   34
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. West Bromwich Albion          38  14  2  3  40:18    8  7  4  27:23    67:41  +26   75
 2. Bolton Wanderers              38  17  2  0  53:12    4  7  8  16:28    69:40  +29   72
 3. Chelsea                       38  17  2  0  48:7     3  7  9  23:28    71:35  +36   69
 4. Leyton Orient                 38  14  4  1  28:7     5  3 11  16:28    44:35   +9   64
 5. Derby County                  38  11  5  3  48:24    6  3 10  25:28    73:52  +21   59
 6. Hull City                     38   8 10  1  38:21    6  6  7  17:18    55:39  +16   58
 7. Blackpool                     38  10  5  4  29:15    6  5  8  20:23    49:38  +11   58
 8. Burnley                       38   9  9  1  31:18    4  6  9  14:27    45:45        54
 9. Wolverhampton Wanderers       38  10  5  4  26:16    5  3 11  25:36    51:52   -1   53
10. Fulham                        38  12  3  4  35:15    3  4 12  17:33    52:48   +4   52
11. Leeds City                    38  11  4  4  35:18    4  3 12  23:38    58:56   +2   52
12. Bradford Park Avenue          38  12  4  3  44:18    2  5 12   9:37    53:55   -2   51
13. Huddersfield Town             38  10  4  5  35:21    3  4 12  22:37    57:58   -1   47
14. Leicester City                38  12  3  4  37:19    2  2 15  15:43    52:62  -10   47
15. Glossop North End             38  11  4  4  36:21    2  4 13  12:41    48:62  -14   47
16. Birmingham City               38  10  4  5  23:18    2  4 13  19:46    42:64  -22   44
17. Stockport County              38  10  4  5  27:26    1  4 14  20:53    47:79  -32   41
18. Gainsborough Trinity          38   9  5  5  26:16    0  6 13  11:39    37:55  -18   38
19. Barnsley                      38   5  7  7  36:26    2  7 10  16:36    52:62  -10   35
20. Lincoln City                  38   5  7  7  16:23    2  3 14  12:49    28:72  -44   31
~~~

(Source: `2-division2.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

