

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Leeds United                  42  18  3  0  41:9     9 10  2  25:17    66:26  +40   94
 2. Liverpool                     42  16  4  1  36:10    9  7  5  27:14    63:24  +39   86
 3. Everton                       42  14  5  2  43:10    7 10  4  34:26    77:36  +41   78
 4. Arsenal                       42  12  6  3  31:12   10  6  5  25:15    56:27  +29   78
 5. Chelsea                       42  11  7  3  40:24    9  3  9  33:29    73:53  +20   70
 6. Southampton                   42  13  5  3  41:21    3  8 10  16:27    57:48   +9   61
 7. Tottenham Hotspur             42  10  8  3  39:22    4  9  8  22:29    61:51  +10   59
 8. Newcastle United              42  12  7  2  40:20    3  7 11  21:35    61:55   +6   59
 9. West Bromwich Albion          42  11  7  3  43:26    5  4 12  21:41    64:67   -3   59
10. West Ham United               42  10  8  3  47:22    3 10  8  19:28    66:50  +16   57
11. Manchester United             42  13  5  3  38:18    2  7 12  19:35    57:53   +4   57
12. Ipswich Town                  42  10  4  7  32:26    5  7  9  27:34    59:60   -1   56
13. Manchester City               42  13  6  2  49:20    2  4 15  15:35    64:55   +9   55
14. Burnley                       42  11  6  4  36:25    4  3 14  19:57    55:82  -27   54
15. Sheffield Wednesday           42   7  9  5  27:26    3  7 11  14:28    41:54  -13   46
16. Wolverhampton Wanderers       42   7 10  4  26:22    3  5 13  15:36    41:58  -17   45
17. Sunderland                    42  10  6  5  28:18    1  6 14  15:49    43:67  -24   45
18. Nottingham Forest             42   6  6  9  17:22    4  7 10  28:35    45:57  -12   43
19. Stoke City                    42   9  7  5  24:24    0  8 13  16:39    40:63  -23   42
20. Coventry City                 42   8  6  7  32:22    2  5 14  14:42    46:64  -18   41
21. Leicester City                42   8  8  5  27:24    1  4 16  12:44    39:68  -29   39
22. Queens Park Rangers           42   4  7 10  20:33    0  3 18  19:62    39:95  -56   22
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Derby County                  42  16  4  1  43:16   10  7  4  22:16    65:32  +33   89
 2. Crystal Palace                42  14  4  3  45:24    8  8  5  25:23    70:47  +23   78
 3. Charlton Athletic             42  11  8  2  39:21    7  6  8  22:31    61:52   +9   68
 4. Middlesbrough                 42  13  7  1  36:13    6  4 11  22:36    58:49   +9   68
 5. Cardiff City                  42  13  3  5  38:19    7  4 10  29:35    67:54  +13   67
 6. Huddersfield Town             42  13  6  2  37:14    4  6 11  16:32    53:46   +7   63
 7. Birmingham City               42  13  3  5  52:24    5  5 11  21:35    73:59  +14   62
 8. Millwall                      42  10  5  6  33:23    7  4 10  24:26    57:49   +8   60
 9. Sheffield United              42  14  4  3  41:15    2  7 12  20:35    61:50  +11   59
10. Carlisle United               42  10  5  6  25:17    6  5 10  21:32    46:49   -3   58
11. Blackpool                     42   9  8  4  33:20    5  7  9  18:21    51:41  +10   57
12. Hull City                     42  10  7  4  38:20    3  9  9  21:32    59:52   +7   55
13. Norwich City                  42   7  6  8  24:25    8  4  9  29:31    53:56   -3   55
14. Preston North End             42   8  8  5  23:19    4  7 10  15:25    38:44   -6   51
15. Portsmouth                    42  11  5  5  39:22    1  9 11  19:36    58:58        50
16. Blackburn Rovers              42   9  6  6  30:24    4  5 12  22:39    52:63  -11   50
17. Aston Villa                   42  10  8  3  22:11    2  6 13  15:37    37:48  -11   50
18. Bolton Wanderers              42   8  7  6  29:26    4  7 10  26:41    55:67  -12   50
19. Bristol City                  42   9  9  3  30:15    2  7 12  16:38    46:53   -7   49
20. Oxford United                 42   8  5  8  21:23    4  4 13  13:32    34:55  -21   45
21. Bury                          42   8  4  9  35:33    3  4 14  16:47    51:80  -29   41
22. Fulham                        42   6  7  8  20:28    1  4 16  20:53    40:81  -41   32
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Watford                       46  16  5  2  35:7    11  5  7  39:27    74:34  +40   91
 2. Swindon Town                  46  18  4  1  38:7     9  6  8  33:28    71:35  +36   91
 3. Luton Town                    46  20  3  0  57:14    5  8 10  17:24    74:38  +36   86
 4. AFC Bournemouth               46  16  2  5  41:17    5  7 11  19:28    60:45  +15   72
 5. Tranmere Rovers               46  12  3  8  36:31    7  7  9  34:37    70:68   +2   67
 6. Torquay United                46  13  4  6  35:18    5  8 10  19:28    54:46   +8   66
 7. Plymouth Argyle               46  10  8  5  34:25    7  7  9  19:24    53:49   +4   66
 8. Southport                     46  14  8  1  52:20    3  5 15  19:44    71:64   +7   64
 9. Stockport County              46  14  5  4  49:25    2  9 12  18:43    67:68   -1   62
10. Barnsley                      46  13  6  4  37:21    3  8 12  21:42    58:63   -5   62
11. Brighton & Hove Albion        46  12  7  4  49:21    4  6 13  23:44    72:65   +7   61
12. Rotherham United              46  12  6  5  40:21    4  7 12  16:29    56:50   +6   61
13. Mansfield Town                46  14  5  4  37:18    2  6 15  21:44    58:62   -4   59
14. Bristol Rovers                46  12  6  5  41:27    4  5 14  22:44    63:71   -8   59
15. Shrewsbury Town               46  11  8  4  28:17    5  3 15  23:50    51:67  -16   59
16. Barrow                        46  11  6  6  30:23    6  2 15  26:52    56:75  -19   59
17. Walsall                       46  10  9  4  34:18    4  7 12  16:30    50:48   +2   58
18. Reading                       46  13  3  7  41:25    2 10 11  26:41    67:66   +1   58
19. Leyton Orient                 46  10  8  5  31:19    4  6 13  20:39    51:58   -7   56
20. Northampton Town              46   9  8  6  36:30    5  4 14  17:31    53:61   -8   54
21. Gillingham                    46  10 10  3  35:20    3  5 15  19:43    54:63   -9   54
22. Hartlepool United             46   6 12  5  25:29    4  7 12  15:41    40:70  -30   49
23. Crewe Alexandra               46  11  4  8  40:31    2  5 16  12:45    52:76  -24   48
24. Oldham Athletic               46   9  6  8  33:27    4  3 16  17:56    50:83  -33   48
~~~

(Source: `3-division3.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Doncaster Rovers              46  13  8  2  42:16    8  9  6  23:22    65:38  +27   80
 2. Halifax Town                  46  15  5  3  36:18    5 12  6  17:19    53:37  +16   77
 3. Rochdale                      46  14  7  2  47:11    4 13  6  21:24    68:35  +33   74
 4. Bradford City                 46  11 10  2  36:18    7 10  6  29:28    65:46  +19   74
 5. Colchester United             46  12  8  3  31:17    8  4 11  26:36    57:53   +4   72
 6. Southend United               46  15  3  5  51:21    4 10  9  27:40    78:61  +17   70
 7. Darlington                    46  11  6  6  40:26    6 12  5  22:19    62:45  +17   69
 8. Wrexham                       46  13  7  3  41:22    5  7 11  20:30    61:52   +9   68
 9. Swansea City                  46  11  8  4  35:20    8  3 12  23:34    58:54   +4   68
10. Lincoln City                  46  13  6  4  38:19    4 11  8  16:33    54:52   +2   68
11. Brentford                     46  12  7  4  40:24    6  5 12  24:41    64:65   -1   66
12. Aldershot                     46  13  3  7  42:23    6  4 13  24:43    66:66        64
13. Scunthorpe United             46  10  5  8  28:22    8  3 12  33:38    61:60   +1   62
14. Port Vale                     46  12  8  3  33:15    4  6 13  13:31    46:46        62
15. Workington                    46   8 11  4  24:17    7  6 10  16:26    40:43   -3   62
16. Chester                       46  12  4  7  43:24    4  9 10  33:42    76:66  +10   61
17. Exeter City                   46  11  8  4  45:24    5  3 15  21:41    66:65   +1   59
18. Peterborough United           46   8  9  6  32:23    5  7 11  28:34    60:57   +3   55
19. Chesterfield                  46   7  7  9  24:22    6  8  9  19:28    43:50   -7   54
20. Notts County                  46  10  8  5  33:22    2 10 11  15:35    48:57   -9   54
21. York City                     46  12  8  3  36:25    2  3 18  17:50    53:75  -22   53
22. Newport County                46   9  9  5  31:26    2  5 16  18:48    49:74  -25   47
23. Grimsby Town                  46   5  7 11  25:31    4  8 11  22:38    47:69  -22   42
24. Bradford Park Avenue          46   5  8 10  19:34    0  2 21  13:72    32:106 -74   25
~~~

(Source: `4-division4.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

