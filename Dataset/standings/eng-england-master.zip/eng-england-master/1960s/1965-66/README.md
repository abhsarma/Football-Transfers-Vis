

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Liverpool                     42  17  2  2  52:15    9  7  5  27:19    79:34  +45   87
 2. Burnley                       42  15  3  3  45:20    9  4  8  34:27    79:47  +32   79
 3. Leeds United                  42  14  4  3  49:15    9  5  7  30:23    79:38  +41   78
 4. Chelsea                       42  11  4  6  30:21   11  3  7  35:32    65:53  +12   73
 5. Leicester City                42  12  4  5  40:28    9  3  9  40:37    80:65  +15   70
 6. Manchester United             42  12  8  1  50:20    6  7  8  34:39    84:59  +25   69
 7. West Bromwich Albion          42  11  6  4  58:34    8  6  7  33:35    91:69  +22   69
 8. Tottenham Hotspur             42  11  6  4  55:37    5  6 10  20:29    75:66   +9   60
 9. Sheffield United              42  11  6  4  37:25    5  5 11  19:34    56:59   -3   59
10. Stoke City                    42  12  6  3  42:22    3  6 12  23:42    65:64   +1   57
11. Everton                       42  12  6  3  39:19    3  5 13  17:43    56:62   -6   56
12. West Ham United               42  12  5  4  46:33    3  4 14  24:50    70:83  -13   54
13. Blackpool                     42   9  5  7  36:29    5  4 12  19:36    55:65  -10   51
14. Aston Villa                   42  10  3  8  39:34    5  3 13  30:46    69:80  -11   51
15. Newcastle United              42  10  5  6  26:20    4  4 13  24:43    50:63  -13   51
16. Sheffield Wednesday           42  11  6  4  35:18    3  2 16  21:48    56:66  -10   50
17. Nottingham Forest             42  11  3  7  31:26    3  5 13  25:46    56:72  -16   50
18. Sunderland                    42  13  2  6  36:28    1  6 14  15:44    51:72  -21   50
19. Arsenal                       42   8  8  5  36:31    4  5 12  26:44    62:75  -13   49
20. Fulham                        42   9  4  8  34:37    5  3 13  33:48    67:85  -18   49
21. Northampton Town              42   8  6  7  31:32    2  7 12  24:60    55:92  -37   43
22. Blackburn Rovers              42   6  1 14  30:36    2  3 16  27:52    57:88  -31   28
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Manchester City               42  14  7  0  40:13    8  8  5  36:30    76:43  +33   81
 2. Southampton                   42  13  4  4  51:25    9  6  6  34:31    85:56  +29   76
 3. Coventry City                 42  14  5  2  54:31    6  8  7  19:22    73:53  +20   73
 4. Wolverhampton Wanderers       42  15  4  2  52:18    5  6 10  35:43    87:61  +26   70
 5. Huddersfield Town             42  12  7  2  35:12    7  6  8  27:24    62:36  +26   70
 6. Bristol City                  42   9 10  2  27:15    8  7  6  36:33    63:48  +15   68
 7. Rotherham United              42  12  6  3  48:29    4  8  9  27:45    75:74   +1   62
 8. Derby County                  42  13  2  6  48:31    3  9  9  23:37    71:68   +3   59
 9. Bolton Wanderers              42  12  2  7  43:25    4  7 10  19:34    62:59   +3   57
10. Birmingham City               42  10  6  5  41:29    6  3 12  29:46    70:75   -5   57
11. Carlisle United               42  16  2  3  43:19    1  3 17  17:44    60:63   -3   56
12. Portsmouth                    42  13  4  4  47:26    3  4 14  26:52    73:78   -5   56
13. Crystal Palace                42  11  7  3  29:16    3  6 12  18:36    47:52   -5   55
14. Ipswich Town                  42  12  6  3  38:23    3  3 15  20:43    58:66   -8   54
15. Norwich City                  42   8  7  6  33:27    4  8  9  19:25    52:52        51
16. Charlton Athletic             42  10  6  5  39:29    2  8 11  22:41    61:70   -9   50
17. Plymouth Argyle               42   7  8  6  37:26    5  5 11  17:37    54:63   -9   49
18. Bury                          42  12  5  4  45:25    2  2 17  17:51    62:76  -14   49
19. Preston North End             42   7 10  4  37:23    4  5 12  25:47    62:70   -8   48
20. Cardiff City                  42  10  3  8  37:35    2  7 12  34:56    71:91  -20   46
21. Middlesbrough                 42   8  8  5  36:28    2  5 14  22:58    58:86  -28   43
22. Leyton Orient                 42   3  9  9  19:36    2  4 15  19:44    38:80  -42   28
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Hull City                     46  19  2  2  64:24   12  5  6  45:38   109:62  +47  100
 2. Millwall                      46  19  4  0  47:13    8  7  8  29:30    76:43  +33   92
 3. Queens Park Rangers           46  16  3  4  62:29    8  6  9  33:36    95:65  +30   81
 4. Scunthorpe United             46   9  8  6  44:34   12  3  8  36:33    80:67  +13   74
 5. Gillingham                    46  14  4  5  33:19    8  4 11  29:35    62:54   +8   74
 6. Workington                    46  13  6  4  38:18    6  8  9  29:39    67:57  +10   71
 7. Swindon Town                  46  11  8  4  43:18    8  5 10  31:30    74:48  +26   70
 8. Walsall                       46  13  7  3  48:21    7  3 13  29:43    77:64  +13   70
 9. Reading                       46  13  5  5  36:19    6  8  9  34:44    70:63   +7   70
10. Shrewsbury Town               46  13  7  3  48:22    6  4 13  25:42    73:64   +9   68
11. Oxford United                 46  11  3  9  38:33    8  5 10  32:41    70:74   -4   65
12. Grimsby Town                  46  15  6  2  47:25    2  7 14  21:37    68:62   +6   64
13. Watford                       46  12  4  7  33:19    5  9  9  22:32    55:51   +4   64
14. Peterborough United           46  13  6  4  50:26    4  6 13  30:40    80:66  +14   63
15. Brighton & Hove Albion        46  13  4  6  48:28    3  7 13  19:37    67:65   +2   59
16. Bristol Rovers                46  11 10  2  38:15    3  4 16  26:49    64:64        56
17. Swansea City                  46  14  4  5  61:37    1  7 15  20:59    81:96  -15   56
18. Mansfield Town                46  10  5  8  31:36    5  3 15  28:53    59:89  -30   53
19. Southend United               46  15  1  7  43:28    1  3 19  11:55    54:83  -29   52
20. AFC Bournemouth               46   9  8  6  24:19    4  4 15  14:37    38:56  -18   51
21. Oldham Athletic               46   8  7  8  34:33    4  6 13  21:48    55:81  -26   49
22. Exeter City                   46   9  6  8  36:28    3  5 15  17:51    53:79  -26   47
23. Brentford                     46   9  4 10  34:30    1  8 14  14:39    48:69  -21   42
24. York City                     46   5  7 11  30:44    4  2 17  23:62    53:106 -53   36
~~~

(Source: `3-division3.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Darlington                    46  16  3  4  41:17    9  6  8  31:36    72:53  +19   84
 2. Doncaster Rovers              46  15  6  2  49:21    9  5  9  36:33    85:54  +31   83
 3. Torquay United                46  17  2  4  43:20    7  8  8  29:29    72:49  +23   82
 4. Tranmere Rovers               46  15  1  7  56:32    9  7  7  37:34    93:66  +27   80
 5. Luton Town                    46  19  2  2  65:27    5  6 12  25:43    90:70  +20   80
 6. Colchester United             46  13  7  3  45:21   10  3 10  25:26    70:47  +23   79
 7. Chester                       46  15  5  3  52:27    5  7 11  27:43    79:70   +9   72
 8. Notts County                  46   9  8  6  32:25   10  4  9  29:28    61:53   +8   69
 9. Bradford Park Avenue          46  14  2  7  59:31    7  3 13  43:61   102:92  +10   68
10. Newport County                46  14  6  3  46:24    4  6 13  29:51    75:75        66
11. Southport                     46  15  6  2  47:20    3  6 14  21:49    68:69   -1   66
12. Barrow                        46  12  8  3  48:31    4  7 12  24:45    72:76   -4   63
13. Stockport County              46  12  4  7  42:29    6  2 15  29:41    71:70   +1   60
14. Crewe Alexandra               46  12  4  7  42:23    4  5 14  19:40    61:63   -2   57
15. Halifax Town                  46  11  6  6  46:31    4  5 14  21:44    67:75   -8   56
16. Hartlepool United             46  13  4  6  44:22    3  4 16  19:53    63:75  -12   56
17. Barnsley                      46  11  6  6  43:24    4  4 15  31:54    74:78   -4   55
18. Aldershot                     46  12  6  5  47:27    3  4 16  28:57    75:84   -9   55
19. Port Vale                     46  12  7  4  38:18    3  2 18  10:41    48:59  -11   54
20. Rochdale                      46  12  1 10  46:27    4  4 15  25:60    71:87  -16   53
21. Chesterfield                  46   8  9  6  37:35    5  4 14  25:43    62:78  -16   52
22. Lincoln City                  46   9  7  7  37:29    4  4 15  20:53    57:82  -25   50
23. Bradford City                 46  10  5  8  37:34    2  8 13  26:60    63:94  -31   49
24. Wrexham                       46  10  4  9  43:43    3  5 15  29:61    72:104 -32   48
~~~

(Source: `4-division4.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

