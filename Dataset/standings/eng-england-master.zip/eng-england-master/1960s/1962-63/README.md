

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Everton                       42  14  7  0  48:17   11  4  6  36:25    84:42  +42   86
 2. Tottenham Hotspur             42  14  6  1  72:28    9  3  9  39:34   111:62  +49   78
 3. Burnley                       42  14  4  3  41:17    8  6  7  37:40    78:57  +21   76
 4. Leicester City                42  14  6  1  53:23    6  6  9  26:30    79:53  +26   72
 5. Wolverhampton Wanderers       42  11  6  4  51:25    9  4  8  42:40    93:65  +28   70
 6. Sheffield Wednesday           42  10  5  6  38:26    9  5  7  39:37    77:63  +14   67
 7. Arsenal                       42  11  4  6  44:33    7  6  8  42:44    86:77   +9   64
 8. Liverpool                     42  13  3  5  45:22    4  7 10  26:37    71:59  +12   61
 9. Nottingham Forest             42  12  4  5  39:28    5  6 10  28:41    67:69   -2   61
10. Sheffield United              42  11  7  3  33:20    5  5 11  25:40    58:60   -2   60
11. Blackburn Rovers              42  11  4  6  55:34    4  8  9  24:37    79:71   +8   57
12. West Bromwich Albion          42  11  1  9  40:37    5  6 10  31:42    71:79   -8   55
13. West Ham United               42   8  6  7  39:34    6  6  9  34:35    73:69   +4   54
14. Aston Villa                   42  12  2  7  38:23    3  6 12  24:45    62:68   -6   53
15. Blackpool                     42   8  7  6  34:27    5  7  9  24:37    58:64   -6   53
16. Fulham                        42   8  6  7  28:30    6  4 11  22:41    50:71  -21   52
17. Bolton Wanderers              42  13  3  5  35:18    2  2 17  20:57    55:75  -20   50
18. Ipswich Town                  42   5  8  8  34:39    7  3 11  25:39    59:78  -19   47
19. Manchester United             42   6  6  9  36:38    6  4 11  31:43    67:81  -14   46
20. Birmingham City               42   6  8  7  40:40    4  5 12  23:50    63:90  -27   43
21. Manchester City               42   7  5  9  30:45    3  6 12  28:57    58:102 -44   41
22. Leyton Orient                 42   4  5 12  22:37    2  4 15  15:44    37:81  -44   27
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Chelsea                       42  15  3  3  54:16    9  1 11  27:26    81:42  +39   76
 2. Stoke City                    42  15  3  3  49:20    5 10  6  24:30    73:50  +23   73
 3. Sunderland                    42  14  5  2  46:13    6  7  8  38:42    84:55  +29   72
 4. Middlesbrough                 42  12  4  5  48:35    8  5  8  38:50    86:85   +1   69
 5. Leeds United                  42  15  2  4  55:19    4  8  9  24:34    79:53  +26   67
 6. Newcastle United              42  11  8  2  48:23    7  3 11  31:36    79:59  +20   65
 7. Huddersfield Town             42  11  6  4  34:21    6  8  7  29:29    63:50  +13   65
 8. Bury                          42  11  6  4  28:20    7  5  9  23:27    51:47   +4   65
 9. Cardiff City                  42  12  5  4  50:29    6  2 13  33:44    83:73  +10   61
10. Scunthorpe United             42  12  7  2  35:18    4  5 12  22:41    57:59   -2   60
11. Southampton                   42  15  3  3  52:23    2  5 14  20:44    72:67   +5   59
12. Norwich City                  42  11  6  4  53:33    6  2 13  27:46    80:79   +1   59
13. Plymouth Argyle               42  13  4  4  48:24    2  8 11  28:49    76:73   +3   57
14. Rotherham United              42  11  3  7  34:30    6  3 12  33:44    67:74   -7   57
15. Swansea City                  42  13  5  3  33:17    2  4 15  18:55    51:72  -21   54
16. Preston North End             42  11  6  4  43:30    2  5 14  16:44    59:74  -15   50
17. Portsmouth                    42   9  5  7  33:27    4  6 11  30:52    63:79  -16   50
18. Derby County                  42  10  5  6  40:29    2  7 12  21:43    61:72  -11   48
19. Grimsby Town                  42   8  6  7  34:26    3  7 11  21:40    55:66  -11   46
20. Charlton Athletic             42   8  4  9  33:38    5  1 15  29:56    62:94  -32   44
21. Walsall                       42   7  7  7  33:37    4  2 15  20:52    53:89  -36   42
22. Luton Town                    42  10  4  7  45:40    1  3 17  16:44    61:84  -23   40
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Northampton Town              46  16  6  1  64:19   10  4  9  45:41   109:60  +49   88
 2. Swindon Town                  46  18  2  3  60:22    4 12  7  27:34    87:56  +31   80
 3. Port Vale                     46  16  4  3  47:25    7  4 12  25:33    72:58  +14   77
 4. Peterborough United           46  11  5  7  48:33    9  6  8  45:42    93:75  +18   71
 5. Coventry City                 46  14  6  3  54:28    4 11  8  29:41    83:69  +14   71
 6. AFC Bournemouth               46  11 12  0  39:16    7  4 12  24:30    63:46  +17   70
 7. Notts County                  46  15  3  5  46:29    4 10  9  27:45    73:74   -1   70
 8. Wrexham                       46  14  6  3  54:27    6  3 14  30:56    84:83   +1   69
 9. Southend United               46  11  7  5  38:24    8  5 10  37:53    75:77   -2   69
10. Hull City                     46  12  6  5  40:22    7  4 12  34:47    74:69   +5   67
11. Colchester United             46  11  6  6  41:35    7  5 11  32:58    73:93  -20   65
12. Crystal Palace                46  10  7  6  38:22    7  6 10  30:36    68:58  +10   64
13. Queens Park Rangers           46   9  6  8  44:36    8  5 10  41:40    85:76   +9   62
14. Bristol City                  46  10  9  4  54:38    6  4 13  46:54   100:92   +8   61
15. Shrewsbury Town               46  13  4  6  57:41    3  8 12  26:40    83:81   +2   60
16. Watford                       46  12  3  8  55:40    5  5 13  27:45    82:85   -3   59
17. Millwall                      46  11  6  6  50:32    4  7 12  32:55    82:87   -5   58
18. Reading                       46  13  4  6  51:30    3  4 16  23:48    74:78   -4   56
19. Barnsley                      46  12  6  5  39:28    3  5 15  24:46    63:74  -11   56
20. Bristol Rovers                46  11  8  4  45:29    4  3 16  25:59    70:88  -18   56
21. Bradford Park Avenue          46  10  9  4  43:36    4  3 16  36:61    79:97  -18   54
22. Brighton & Hove Albion        46   7  6 10  28:38    5  6 12  30:46    58:84  -26   48
23. Carlisle United               46  12  4  7  41:37    1  5 17  20:52    61:89  -28   48
24. Halifax Town                  46   8  3 12  41:51    1  9 13  23:55    64:106 -42   39
~~~

(Source: `3-division3.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Brentford                     46  18  2  3  59:31    9  6  8  39:33    98:64  +34   89
 2. Oldham Athletic               46  18  4  1  65:23    6  7 10  30:37    95:60  +35   83
 3. Crewe Alexandra               46  15  4  4  50:21    9  7  7  36:37    86:58  +28   83
 4. Mansfield Town                46  16  4  3  61:20    8  5 10  47:49   108:69  +39   81
 5. Gillingham                    46  17  3  3  49:23    5 10  8  22:26    71:49  +22   79
 6. Torquay United                46  14  8  1  45:20    6  8  9  30:36    75:56  +19   76
 7. Rochdale                      46  16  6  1  48:21    4  5 14  19:38    67:59   +8   71
 8. Tranmere Rovers               46  15  3  5  57:25    5  7 11  24:42    81:67  +14   70
 9. Barrow                        46  14  7  2  52:26    5  5 13  30:54    82:80   +2   69
10. Workington                    46  13  4  6  42:20    4  9 10  34:48    76:68   +8   64
11. Darlington                    46  13  3  7  44:33    6  3 14  28:54    72:87  -15   63
12. Aldershot                     46   9  9  5  42:32    6  8  9  31:37    73:69   +4   62
13. York City                     46  12  6  5  42:25    4  5 14  25:37    67:62   +5   59
14. Southport                     46  11  9  3  47:35    4  5 14  25:71    72:106 -34   59
15. Exeter City                   46   9  6  8  27:32    7  4 12  30:45    57:77  -20   58
16. Doncaster Rovers              46   9 10  4  36:26    5  4 14  28:51    64:77  -13   56
17. Stockport County              46   9  7  7  34:29    6  4 13  22:41    56:70  -14   56
18. Chesterfield                  46   7 10  6  43:29    6  6 11  27:35    70:64   +6   55
19. Oxford United                 46  10 10  3  44:27    3  5 15  26:44    70:71   -1   54
20. Chester                       46  11  5  7  31:23    4  4 15  20:43    51:66  -15   54
21. Newport County                46  11  6  6  44:29    3  5 15  32:61    76:90  -14   53
22. Lincoln City                  46  11  1 11  48:46    2  8 13  20:43    68:89  -21   48
23. Bradford City                 46   8  5 10  37:40    3  5 15  27:53    64:93  -29   43
24. Hartlepool United             46   5  7 11  33:39    2  4 17  23:65    56:104 -48   32
~~~

(Source: `4-division4.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

