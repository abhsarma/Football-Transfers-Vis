

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Arsenal                       42  15  3  3  56:15    8 10  3  25:17    81:32  +49   82
 2. Burnley                       42  12  5  4  31:12    8  7  6  25:31    56:43  +13   72
 3. Manchester United             42  11  7  3  50:27    8  7  6  31:21    81:48  +33   71
 4. Derby County                  42  11  6  4  38:24    8  6  7  39:33    77:57  +20   69
 5. Preston North End             42  13  4  4  43:35    7  3 11  24:33    67:68   -1   67
 6. Wolverhampton Wanderers       42  12  4  5  45:29    7  5  9  38:41    83:70  +13   66
 7. Aston Villa                   42  13  5  3  42:22    6  4 11  23:35    65:57   +8   66
 8. Portsmouth                    42  13  5  3  44:17    6  2 13  24:33    68:50  +18   64
 9. Blackpool                     42  13  4  4  37:14    4  6 11  20:27    57:41  +16   61
10. Liverpool                     42   9  8  4  39:23    7  2 12  26:38    65:61   +4   58
11. Sheffield United              42  13  4  4  44:24    3  6 12  21:46    65:70   -5   58
12. Manchester City               42  13  3  5  37:22    2  9 10  15:25    52:47   +5   57
13. Charlton Athletic             42   8  4  9  33:29    9  2 10  24:37    57:66   -9   57
14. Everton                       42  10  2  9  30:26    7  4 10  22:40    52:66  -14   57
15. Bolton Wanderers              42  11  2  8  29:25    5  3 13  17:33    46:58  -12   53
16. Stoke City                    42   9  5  7  29:23    5  5 11  12:32    41:55  -14   52
17. Middlesbrough                 42   8  7  6  37:27    6  2 13  34:46    71:73   -2   51
18. Chelsea                       42  11  6  4  38:27    3  3 15  15:44    53:71  -18   51
19. Sunderland                    42  11  4  6  33:18    2  6 13  23:49    56:67  -11   49
20. Huddersfield Town             42   7  6  8  25:24    5  6 10  26:36    51:60   -9   48
21. Blackburn Rovers              42   8  5  8  35:30    3  5 13  19:42    54:72  -18   43
22. Grimsby Town                  42   5  5 11  20:35    3  1 17  25:76    45:111 -66   30
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Birmingham City               42  12  7  2  34:13   10  8  3  21:11    55:24  +31   81
 2. Newcastle United              42  18  1  2  46:13    6  7  8  26:28    72:41  +31   80
 3. Southampton                   42  15  3  3  53:23    6  7  8  18:30    71:53  +18   73
 4. Sheffield Wednesday           42  13  6  2  39:21    7  5  9  27:32    66:53  +13   71
 5. Cardiff City                  42  12  6  3  36:18    6  5 10  25:40    61:58   +3   65
 6. West Bromwich Albion          42  11  4  6  37:29    7  5  9  26:29    63:58   +5   63
 7. West Ham United               42  10  7  4  29:19    6  7  8  26:34    55:53   +2   62
 8. Tottenham Hotspur             42  10  6  5  36:24    5  8  8  20:19    56:43  +13   59
 9. Leicester City                42  10  5  6  36:29    6  6  9  24:28    60:57   +3   59
10. Bradford Park Avenue          42  11  3  7  45:30    5  5 11  23:42    68:72   -4   56
11. Coventry City                 42  10  5  6  33:16    4  8  9  26:36    59:52   +7   55
12. Fulham                        42   6  9  6  24:19    9  1 11  23:27    47:46   +1   55
13. Chesterfield                  42   8  4  9  32:26    8  3 10  22:29    54:55   -1   55
14. Barnsley                      42  10  5  6  31:22    5  5 11  31:42    62:64   -2   55
15. Luton Town                    42   8  8  5  31:25    6  4 11  25:34    56:59   -3   54
16. Brentford                     42  10  6  5  31:26    3  8 10  13:35    44:61  -17   53
17. Leeds United                  42  12  5  4  44:20    2  3 16  18:52    62:72  -10   50
18. Nottingham Forest             42  10  5  6  32:23    2  6 13  22:37    54:60   -6   47
19. Plymouth Argyle               42   8  9  4  27:22    1 11  9  13:36    40:58  -18   47
20. Bury                          42   6  8  7  27:28    3  8 10  31:40    58:68  -10   43
21. Doncaster Rovers              42   7  8  6  23:20    2  3 16  17:46    40:66  -26   38
22. Millwall                      42   7  7  7  27:28    2  4 15  17:46    44:74  -30   38
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Lincoln City                  42  14  3  4  47:18   12  5  4  34:22    81:40  +41   86
 2. Rotherham United              42  15  4  2  56:18   10  5  6  39:31    95:49  +46   84
 3. Wrexham                       42  14  3  4  49:23    7  5  9  25:31    74:54  +20   71
 4. Gateshead                     42  11  5  5  48:28    8  6  7  27:29    75:57  +18   68
 5. Accrington Stanley            42  13  1  7  36:24    7  5  9  26:35    62:59   +3   66
 6. Hull City                     42  12  5  4  38:21    6  6  9  21:27    59:48  +11   65
 7. Mansfield Town                42  11  4  6  37:24    6  7  8  20:27    57:51   +6   62
 8. Carlisle United               42  10  4  7  50:35    8  3 10  38:42    88:77  +11   61
 9. Barrow                        42   9  4  8  24:19    7  9  5  25:21    49:40   +9   61
10. Crewe Alexandra               42  12  4  5  41:24    6  3 12  20:39    61:63   -2   61
11. Rochdale                      42  12  4  5  32:23    3  7 11  16:49    48:72  -24   56
12. Bradford City                 42  10  4  7  38:27    5  6 10  27:39    65:66   -1   55
13. Oldham Athletic               42   6 10  5  25:25    8  3 10  38:39    63:64   -1   55
14. York City                     42   8  7  6  38:25    5  7  9  27:35    65:60   +5   53
15. Southport                     42  10  4  7  34:27    4  7 10  26:36    60:63   -3   53
16. Darlington                    42   7  8  6  30:31    6  5 10  24:39    54:70  -16   52
17. Tranmere Rovers               42  10  1 10  30:28    6  3 12  24:44    54:72  -18   52
18. Stockport County              42   9  6  6  42:28    4  6 11  21:39    63:67   -4   51
19. Hartlepool United             42  10  6  5  34:23    4  2 15  17:50    51:73  -22   50
20. Chester                       42  11  6  4  44:25    2  3 16  20:42    64:67   -3   48
21. Halifax Town                  42   4 10  7  25:27    3  3 15  18:49    43:76  -33   34
22. New Brighton                  42   5  6 10  20:28    3  3 15  18:53    38:81  -43   33
~~~

(Source: `3a-division3n.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Queens Park Rangers           42  16  3  2  44:17   10  6  5  30:20    74:37  +37   87
 2. AFC Bournemouth               42  13  5  3  42:13   11  4  6  34:22    76:35  +41   81
 3. Walsall                       42  13  5  3  37:12    8  4  9  33:28    70:40  +30   72
 4. Ipswich Town                  42  16  1  4  42:18    7  2 12  25:43    67:61   +6   72
 5. Swansea City                  42  14  6  1  48:14    4  6 11  22:38    70:52  +18   66
 6. Notts County                  42  12  4  5  44:27    7  4 10  24:32    68:59   +9   65
 7. Bristol City                  42  11  4  6  47:26    7  3 11  30:39    77:65  +12   61
 8. Port Vale                     42  14  4  3  48:18    2  7 12  15:36    63:54   +9   59
 9. Southend United               42  11  8  2  32:16    4  5 12  19:42    51:58   -7   58
10. Reading                       42  10  5  6  37:28    5  6 10  19:30    56:58   -2   56
11. Exeter City                   42  11  6  4  34:22    4  5 12  21:41    55:63   -8   56
12. Newport County                42   9  8  4  38:28    5  5 11  23:45    61:73  -12   55
13. Northampton Town              42  10  5  6  35:28    4  6 11  23:44    58:72  -14   53
14. Crystal Palace                42  12  5  4  32:14    1  8 12  17:35    49:49        52
15. Torquay United                42   8  6  7  42:28    4  7 10  23:33    65:61   +4   49
16. Leyton Orient                 42   8  5  8  31:32    5  5 11  20:41    51:73  -22   49
17. Watford                       42   6  6  9  31:37    7  4 10  25:44    56:81  -25   49
18. Bristol Rovers                42   7  3 11  39:34    6  5 10  32:41    71:75   -4   47
19. Norwich City                  42   8  3 10  33:34    5  5 11  28:42    61:76  -15   47
20. Swindon Town                  42   6 10  5  21:20    4  6 11  20:26    41:46   -5   46
21. Aldershot                     42   5 10  6  22:26    5  5 11  23:41    45:67  -22   45
22. Brighton & Hove Albion        42   8  4  9  26:31    3  8 10  17:42    43:73  -30   45
~~~

(Source: `3b-division3s.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

