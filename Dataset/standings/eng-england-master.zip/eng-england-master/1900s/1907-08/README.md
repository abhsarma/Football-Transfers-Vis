

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Manchester United             38  15  1  3  43:19    8  5  6  38:29    81:48  +33   75
 2. Sheffield Wednesday           38  14  0  5  50:25    5  4 10  23:39    73:64   +9   61
 3. Aston Villa                   38   9  6  4  47:24    8  3  8  30:35    77:59  +18   60
 4. Manchester City               38  12  5  2  36:19    4  6  9  26:35    62:54   +8   59
 5. Middlesbrough                 38  12  2  5  32:16    5  5  9  22:29    54:45   +9   58
 6. Newcastle United              38  11  4  4  41:24    4  8  7  24:30    65:54  +11   57
 7. Liverpool                     38  11  2  6  43:24    5  4 10  25:37    68:61   +7   54
 8. Bury                          38   8  7  4  29:22    6  4  9  29:39    58:61   -3   53
 9. Sunderland                    38  11  2  6  53:31    5  1 13  25:44    78:75   +3   51
10. Everton                       38  11  4  4  34:24    4  2 13  24:40    58:64   -6   51
11. Nottingham Forest             38  11  6  2  42:21    2  5 12  17:41    59:62   -3   50
12. Chelsea                       38   8  3  8  30:35    6  5  8  23:27    53:62   -9   50
13. Bristol City                  38   8  7  4  29:21    4  5 10  29:40    58:61   -3   48
14. Preston North End             38   9  7  3  33:18    3  5 11  14:35    47:53   -6   48
15. Blackburn Rovers              38  10  7  2  35:23    2  5 12  16:40    51:63  -12   48
16. Arsenal                       38   9  8  2  32:18    3  4 12  19:45    51:63  -12   48
17. Bolton Wanderers              38  10  3  6  35:26    4  2 13  17:32    52:58   -6   47
18. Sheffield United              38   8  6  5  27:22    4  5 10  25:36    52:58   -6   47
19. Notts County                  38   9  3  7  24:19    4  5 10  15:32    39:51  -12   47
20. Birmingham City               38   6  6  7  22:28    3  6 10  18:32    40:60  -20   39
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Bradford City                 38  15  2  2  58:16    9  4  6  32:26    90:42  +48   78
 2. Leicester City                38  14  2  3  41:20    7  8  4  31:27    72:47  +25   73
 3. Oldham Athletic               38  15  4  0  53:14    7  2 10  23:28    76:42  +34   72
 4. Fulham                        38  12  2  5  50:14   10  3  6  32:35    82:49  +33   71
 5. Derby County                  38  15  1  3  50:13    6  3 10  27:32    77:45  +32   67
 6. Hull City                     38  15  1  3  50:23    6  3 10  23:39    73:62  +11   67
 7. West Bromwich Albion          38  13  3  3  38:13    6  6  7  23:26    61:39  +22   66
 8. Burnley                       38  14  3  2  44:14    6  3 10  23:36    67:50  +17   66
 9. Stoke City                    38  11  5  3  43:13    5  0 14  14:39    57:52   +5   53
10. Wolverhampton Wanderers       38  11  4  4  34:11    4  3 12  16:34    50:45   +5   52
11. Gainsborough Trinity          38   9  4  6  31:28    5  3 11  16:43    47:71  -24   49
12. Leeds City                    38   9  6  4  33:18    3  2 14  20:47    53:65  -12   44
13. Stockport County              38   9  4  6  35:26    3  4 12  13:41    48:67  -19   44
14. Leyton Orient                 38  10  5  4  28:13    1  5 13  12:52    40:65  -25   43
15. Blackpool                     38  11  3  5  33:19    0  6 13  18:39    51:58   -7   42
16. Barnsley                      38   8  3  8  41:31    4  3 12  13:37    54:68  -14   42
17. Glossop North End             38   9  5  5  36:26    2  3 14  18:48    54:74  -20   41
18. Grimsby Town                  38   8  5  6  27:24    3  3 13  16:47    43:71  -28   41
19. Lincoln City                  38   7  2 10  27:28    2  1 16  19:55    46:83  -37   30
20. Chesterfield                  38   6  6  7  33:38    0  5 14  13:54    46:92  -46   29
~~~

(Source: `2-division2.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

