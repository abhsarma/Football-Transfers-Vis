

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Sheffield Wednesday           34  12  3  2  31:7     7  1  9  23:29    54:36  +18   61
 2. Aston Villa                   34  11  3  3  43:18    8  0  9  18:22    61:40  +21   60
 3. Sunderland                    34  10  5  2  27:11    6  4  7  24:25    51:36  +15   57
 4. Sheffield United              34  11  0  6  36:22    6  5  6  22:22    58:44  +14   56
 5. Liverpool                     34  11  3  3  48:21    6  1 10  20:28    68:49  +19   55
 6. Stoke City                    34  11  2  4  29:11    4  5  8  17:27    46:38   +8   52
 7. West Bromwich Albion          34  10  2  5  37:27    6  2  9  17:26    54:53   +1   52
 8. Bury                          34  14  1  2  41:14    2  2 13  13:29    54:43  +11   51
 9. Derby County                  34  13  2  2  34:11    3  1 13  16:36    50:47   +3   51
10. Nottingham Forest             34  10  3  4  33:22    4  4  9  16:25    49:47   +2   49
11. Wolverhampton Wanderers       34  12  2  3  34:17    2  3 12  14:40    48:57   -9   47
12. Middlesbrough                 34  10  3  4  27:16    4  1 12  14:34    41:50   -9   46
13. Newcastle United              34  12  1  4  31:11    2  3 12  10:40    41:51  -10   46
14. Everton                       34  10  2  5  28:18    3  4 10  17:29    45:47   -2   45
15. Notts County                  34   8  5  4  25:16    4  2 11  16:33    41:49   -8   43
16. Blackburn Rovers              34   9  2  6  27:24    3  3 11  17:39    44:63  -19   41
17. Grimsby Town                  34   6  5  6  28:22    2  4 11  15:40    43:62  -19   33
18. Bolton Wanderers              34   6  2  9  18:20    2  1 14  19:53    37:73  -36   27
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Manchester City               34  15  1  1  64:15   10  3  4  31:14    95:29  +66   79
 2. Birmingham City               34  17  0  0  57:11    7  3  7  17:25    74:36  +38   75
 3. Arsenal                       34  14  2  1  46:9     6  6  5  20:21    66:30  +36   68
 4. Bristol City                  34  12  3  2  43:18    5  5  7  16:20    59:38  +21   59
 5. Manchester United             34   9  4  4  32:15    6  4  7  21:23    53:38  +15   53
 6. Chesterfield                  34  11  4  2  43:10    3  5  9  24:30    67:40  +27   51
 7. Preston North End             34  10  5  2  39:12    3  5  9  17:28    56:40  +16   49
 8. Barnsley                      34   9  4  4  32:13    4  4  9  23:38    55:51   +4   47
 9. Port Vale                     34  11  5  1  36:16    2  3 12  21:46    57:62   -5   47
10. Lincoln City                  34   8  3  6  30:22    4  3 10  16:31    46:53   -7   42
11. Glossop North End             34   9  1  7  26:20    2  6  9  17:38    43:58  -15   40
12. Gainsborough Trinity          34   9  4  4  28:14    2  3 12  13:45    41:59  -18   40
13. Burton United                 34   9  4  4  26:20    2  3 12  13:39    39:59  -20   40
14. Leicester City                34   5  5  7  20:23    5  3  9  21:42    41:65  -24   38
15. Blackpool                     34   7  5  5  32:24    2  5 10  12:35    44:59  -15   37
16. Doncaster Rovers              34   8  5  4  27:17    1  2 14   8:55    35:72  -37   34
17. Stockport County              34   6  4  7  26:24    1  2 14  13:50    39:74  -35   27
18. Burnley                       34   6  7  4  25:25    0  1 16   5:52    30:77  -47   26
~~~

(Source: `2-division2.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

