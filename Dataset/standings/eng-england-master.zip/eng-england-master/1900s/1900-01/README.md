

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Liverpool                     34  12  2  3  36:13    7  5  5  23:22    59:35  +24   64
 2. Sunderland                    34  12  3  2  43:11    3 10  4  14:15    57:26  +31   58
 3. Notts County                  34  13  2  2  39:18    5  2 10  15:28    54:46   +8   58
 4. Nottingham Forest             34  10  4  3  32:14    6  3  8  21:22    53:36  +17   55
 5. Bury                          34  11  3  3  31:10    5  4  8  22:27    53:37  +16   55
 6. Everton                       34  10  4  3  37:17    6  1 10  18:25    55:42  +13   53
 7. Newcastle United              34  10  5  2  27:13    4  5  8  15:24    42:37   +5   52
 8. Sheffield Wednesday           34  13  2  2  38:16    0  8  9  14:26    52:42  +10   49
 9. Bolton Wanderers              34  10  5  2  21:12    3  2 12  18:43    39:55  -16   46
10. Blackburn Rovers              34   9  4  4  24:18    3  5  9  15:29    39:47   -8   45
11. Manchester City               34  12  3  2  32:16    1  3 13  16:42    48:58  -10   45
12. Derby County                  34  10  4  3  43:18    2  3 12  12:24    55:42  +13   43
13. Sheffield United              34   8  4  5  22:23    4  3 10  13:29    35:52  -17   43
14. Aston Villa                   34   8  5  4  32:18    2  5 10  13:33    45:51   -6   40
15. Wolverhampton Wanderers       34   6 10  1  21:15    3  3 11  18:40    39:55  -16   40
16. Stoke City                    34   8  3  6  23:15    3  2 12  23:42    46:57  -11   38
17. Preston North End             34   6  4  7  29:30    3  3 11  20:45    49:75  -26   34
18. West Bromwich Albion          34   4  4  9  21:27    3  4 10  14:35    35:62  -27   29
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Grimsby Town                  34  14  3  0  46:11    6  6  5  14:22    60:33  +27   69
 2. Birmingham City               34  14  2  1  41:8     5  8  4  16:16    57:24  +33   67
 3. Burnley                       34  15  2  0  39:6     5  2 10  14:23    53:29  +24   64
 4. New Brighton Tower            34  12  5  0  34:8     5  3  9  23:30    57:38  +19   59
 5. Glossop North End             34  11  2  4  34:9     4  6  7  17:24    51:33  +18   53
 6. Middlesbrough                 34  11  4  2  38:13    4  3 10  12:27    50:40  +10   52
 7. Arsenal                       34  13  3  1  30:11    2  3 12   9:24    39:35   +4   51
 8. Lincoln City                  34  12  3  2  39:11    1  4 12   4:28    43:39   +4   46
 9. Manchester United             34  11  3  3  31:9     3  1 13  11:29    42:38   +4   46
10. Port Vale                     34   8  6  3  28:14    3  5  9  17:33    45:47   -2   44
11. Leicester City                34   9  5  3  30:15    2  5 10   9:22    39:37   +2   43
12. Blackpool                     34   7  6  4  20:11    5  1 11  13:47    33:58  -25   43
13. Gainsborough Trinity          34   8  4  5  26:18    2  6  9  19:42    45:60  -15   40
14. Barnsley                      34   9  3  5  34:23    2  2 13  13:37    47:60  -13   38
15. Chesterfield                  34   6  5  6  25:22    3  5  9  21:36    46:58  -12   37
16. Stockport County              34   9  2  6  25:21    2  1 14  13:47    38:68  -30   36
17. Walsall                       34   7  7  3  29:23    0  6 11  11:33    40:56  -16   34
18. Burton Swifts                 34   7  3  7  16:21    1  1 15  18:45    34:66  -32   28
~~~

(Source: `2-division2.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

