

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Aston Villa                   38  17  2  0  62:19    6  5  8  22:23    84:42  +42   76
 2. Liverpool                     38  13  3  3  47:23    8  3  8  31:34    78:57  +21   69
 3. Newcastle United              38  11  3  5  33:22    8  4  7  37:34    70:56  +14   64
 4. Manchester United             38  14  2  3  41:20    5  5  9  28:41    69:61   +8   64
 5. Blackburn Rovers              38  13  6  0  47:17    5  3 11  26:38    73:55  +18   63
 6. Bradford City                 38  12  3  4  38:17    5  5  9  26:30    64:47  +17   59
 7. Sunderland                    38  12  3  4  40:18    6  2 11  26:33    66:51  +15   59
 8. Sheffield United              38  10  5  4  42:19    6  5  8  20:22    62:41  +21   58
 9. Everton                       38   8  6  5  30:28    8  2  9  21:28    51:56   -5   56
10. Notts County                  38  10  5  4  41:26    5  5  9  26:33    67:59   +8   55
11. Sheffield Wednesday           38  11  4  4  38:28    4  5 10  22:35    60:63   -3   54
12. Preston North End             38  14  2  3  36:13    1  3 15  16:45    52:58   -6   50
13. Bury                          38   8  3  8  35:30    4  6  9  27:36    62:66   -4   45
14. Bristol City                  38   9  5  5  28:18    3  3 13  17:42    45:60  -15   44
15. Nottingham Forest             38   4  7  8  19:34    7  4  8  35:38    54:72  -18   44
16. Tottenham Hotspur             38  10  6  3  35:23    1  4 14  18:46    53:69  -16   43
17. Middlesbrough                 38   8  4  7  34:36    3  5 11  22:37    56:73  -17   42
18. Arsenal                       38   6  5  8  17:19    5  4 10  20:48    37:67  -30   42
19. Chelsea                       38  10  4  5  32:24    1  3 15  15:46    47:70  -23   40
20. Bolton Wanderers              38   7  2 10  31:34    2  4 13  13:37    44:71  -27   33
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Manchester City               38  15  2  2  51:17    8  6  5  30:23    81:40  +41   77
 2. Oldham Athletic               38  15  2  2  47:9     8  5  6  32:30    79:39  +40   76
 3. Hull City                     38  13  4  2  52:19   10  3  6  28:27    80:46  +34   76
 4. Derby County                  38  15  2  2  46:15    7  7  5  26:32    72:47  +25   75
 5. Leicester City                38  15  2  2  60:20    5  2 12  19:38    79:58  +21   64
 6. Glossop North End             38  14  1  4  42:18    4  6  9  22:39    64:57   +7   61
 7. Wolverhampton Wanderers       38  14  3  2  51:22    3  3 13  13:41    64:63   +1   57
 8. Fulham                        38   9  7  3  28:13    5  6  8  23:30    51:43   +8   55
 9. Bradford Park Avenue          38  12  1  6  47:28    5  3 11  17:31    64:59   +5   55
10. Barnsley                      38  15  3  1  48:15    1  4 14  14:44    62:59   +3   55
11. West Bromwich Albion          38   8  5  6  30:23    8  0 11  28:33    58:56   +2   53
12. Blackpool                     38   7  7  5  24:18    7  1 11  26:34    50:52   -2   50
13. Burnley                       38  12  2  5  43:21    2  4 13  19:40    62:61   +1   48
14. Stockport County              38   9  6  4  37:20    4  2 13  13:27    50:47   +3   47
15. Leyton Orient                 38  10  4  5  26:15    2  2 15  11:45    37:60  -23   42
16. Lincoln City                  38   7  6  6  27:24    3  5 11  15:45    42:69  -27   41
17. Leeds City                    38   8  4  7  30:33    2  3 14  16:47    46:80  -34   37
18. Gainsborough Trinity          38   8  3  8  22:21    2  3 14  11:54    33:75  -42   36
19. Grimsby Town                  38   8  3  8  31:19    1  3 15  19:58    50:77  -27   33
20. Birmingham City               38   7  4  8  28:26    1  3 15  14:52    42:78  -36   31
~~~

(Source: `2-division2.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

