

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Manchester United             42  14  5  2  39:14   10  7  4  28:17    67:31  +36   84
 2. Aston Villa                   42  13  5  3  36:16    8  6  7  21:24    57:40  +17   74
 3. Norwich City                  42  13  6  2  31:19    8  3 10  30:46    61:65   -4   72
 4. Blackburn Rovers              42  13  4  4  38:18    7  7  7  30:28    68:46  +22   71
 5. Queens Park Rangers           42  11  5  5  41:32    6  7  8  22:23    63:55   +8   63
 6. Liverpool                     42  13  4  4  41:18    3  7 11  21:37    62:55   +7   59
 7. Sheffield Wednesday           42   9  8  4  34:26    6  6  9  21:25    55:51   +4   59
 8. Tottenham Hotspur             42  11  5  5  40:25    5  6 10  20:41    60:66   -6   59
 9. Manchester City               42   7  8  6  30:25    8  4  9  26:26    56:51   +5   57
10. Arsenal                       42   8  6  7  25:20    7  5  9  15:18    40:38   +2   56
11. Chelsea                       42   9  7  5  29:22    5  7  9  22:32    51:54   -3   56
12. Wimbledon                     42   9  4  8  32:23    5  8  8  24:32    56:55   +1   54
13. Everton                       42   7  6  8  26:27    8  2 11  27:28    53:55   -2   53
14. Sheffield United              42  10  6  5  33:19    4  4 13  21:34    54:53   +1   52
15. Coventry City                 42   7  4 10  29:28    6  9  6  23:29    52:57   -5   52
16. Ipswich Town                  42   8  9  4  29:22    4  7 10  21:33    50:55   -5   52
17. Leeds United                  42  12  8  1  40:17    0  7 14  17:45    57:62   -5   51
18. Southampton                   42  10  6  5  30:21    3  5 13  24:40    54:61   -7   50
19. Oldham Athletic               42  10  6  5  43:30    3  4 14  20:44    63:74  -11   49
20. Crystal Palace                42   6  9  6  27:25    5  7  9  21:36    48:61  -13   49
21. Middlesbrough                 42   8  5  8  33:27    3  6 12  21:48    54:75  -21   44
22. Nottingham Forest             42   6  4 11  17:25    4  6 11  24:37    41:62  -21   40
~~~

(Source: `1-premierleague.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Newcastle United              46  16  6  1  58:15   13  3  7  34:23    92:38  +54   96
 2. West Ham United               46  16  5  2  50:17   10  5  8  31:24    81:41  +40   88
 3. Portsmouth                    46  19  2  2  48:9     7  8  8  32:37    80:46  +34   88
 4. Tranmere Rovers               46  15  4  4  48:24    8  6  9  24:32    72:56  +16   79
 5. Swindon Town                  46  15  5  3  41:23    6  8  9  33:36    74:59  +15   76
 6. Leicester City                46  14  5  4  43:24    8  5 10  28:40    71:64   +7   76
 7. Millwall                      46  14  6  3  46:21    4 10  9  19:32    65:53  +12   70
 8. Derby County                  46  11  2 10  40:33    8  7  8  28:24    68:57  +11   66
 9. Grimsby Town                  46  12  6  5  33:25    7  1 15  25:32    58:57   +1   64
10. Peterborough United           46   7 11  5  30:26    9  3 11  25:37    55:63   -8   62
11. Charlton Athletic             46  10  8  5  28:19    6  5 12  21:27    49:46   +3   61
12. Wolverhampton Wanderers       46  11  6  6  37:26    5  7 11  20:30    57:56   +1   61
13. Barnsley                      46  12  4  7  29:19    5  5 13  27:41    56:60   -4   60
14. Oxford United                 46   8  7  8  29:21    6  7 10  24:35    53:56   -3   56
15. Bristol City                  46  10  7  6  29:25    4  7 12  20:42    49:67  -18   56
16. Watford                       46   8  7  8  27:30    6  6 11  30:41    57:71  -14   55
17. Southend United               46   9  8  6  33:22    4  5 14  21:42    54:64  -10   52
18. Notts County                  46  10  7  6  33:21    2  9 12  23:50    56:71  -15   52
19. Luton Town                    46   6 13  4  26:26    4  8 11  22:36    48:62  -14   51
20. Birmingham City               46  10  4  9  31:33    3  8 12  20:40    51:73  -22   51
21. Sunderland                    46   9  6  8  34:28    4  5 14  16:36    50:64  -14   50
22. Brentford                     46   7  6 10  28:30    6  4 13  24:41    52:71  -19   49
23. Cambridge United              46   8  6  9  29:32    3 10 10  19:37    48:69  -21   49
24. Bristol Rovers                46   6  6 11  30:42    4  5 14  25:45    55:87  -32   41
~~~

(Source: `2-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Stoke City                    46  17  4  2  41:13   10  8  5  32:21    73:34  +39   93
 2. Bolton Wanderers              46  18  2  3  48:14    9  7  7  32:27    80:41  +39   90
 3. Port Vale                     46  14  7  2  44:17   12  4  7  35:27    79:44  +35   89
 4. West Bromwich Albion          46  17  3  3  56:22    8  7  8  32:32    88:54  +34   85
 5. Swansea City                  46  12  7  4  38:17    8  6  9  27:30    65:47  +18   73
 6. Stockport County              46  11 11  1  47:18    8  4 11  34:39    81:57  +24   72
 7. Leyton Orient                 46  16  4  3  49:20    5  5 13  20:33    69:53  +16   72
 8. Reading                       46  14  4  5  44:20    4 11  8  22:31    66:51  +15   69
 9. Brighton & Hove Albion        46  13  4  6  36:24    7  5 11  27:35    63:59   +4   69
10. Bradford City                 46  12  5  6  36:24    6  9  8  33:43    69:67   +2   68
11. Fulham                        46   9  9  5  28:22    7  8  8  29:33    57:55   +2   65
12. Rotherham United              46   9  7  7  30:27    8  7  8  30:33    60:60        65
13. Burnley                       46  11  8  4  38:21    4  8 11  19:38    57:59   -2   61
14. Plymouth Argyle               46  11  6  6  38:28    5  6 12  21:36    59:64   -5   60
15. Huddersfield Town             46  10  6  7  30:22    7  3 13  24:39    54:61   -7   60
16. Hartlepool United             46   8  6  9  19:23    6  6 11  23:37    42:60  -18   54
17. AFC Bournemouth               46   7 10  6  28:24    5  7 11  17:28    45:52   -7   53
18. Blackpool                     46   9  9  5  40:30    3  6 14  23:45    63:75  -12   51
19. Exeter City                   46   5  8 10  26:30    6  9  8  28:39    54:69  -15   50
20. Hull City                     46   9  5  9  28:26    4  6 13  18:43    46:69  -23   50
21. Preston North End             46   8  5 10  41:47    5  3 15  24:47    65:94  -29   47
22. Mansfield Town                46   7  8  8  34:34    4  3 16  18:46    52:80  -28   44
23. Wigan Athletic                46   6  6 11  26:34    4  5 14  17:38    43:72  -29   41
24. Chester                       46   6  2 15  30:47    2  3 18  19:55    49:102 -53   29
~~~

(Source: `3-division2.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

