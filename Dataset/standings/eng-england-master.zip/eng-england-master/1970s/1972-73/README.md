

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Liverpool                     42  17  3  1  45:19    8  7  6  27:23    72:42  +30   85
 2. Arsenal                       42  14  5  2  31:14    9  6  6  26:29    57:43  +14   80
 3. Leeds United                  42  15  4  2  45:13    6  7  8  26:32    71:45  +26   74
 4. Wolverhampton Wanderers       42  13  3  5  43:23    5  8  8  23:31    66:54  +12   65
 5. Ipswich Town                  42  10  7  4  34:20    7  7  7  21:25    55:45  +10   65
 6. Derby County                  42  15  3  3  43:18    4  5 12  13:36    56:54   +2   65
 7. West Ham United               42  12  5  4  45:25    5  7  9  22:28    67:53  +14   63
 8. Tottenham Hotspur             42  10  5  6  33:23    6  8  7  25:25    58:48  +10   61
 9. Newcastle United              42  12  6  3  35:19    4  7 10  25:32    60:51   +9   61
10. Birmingham City               42  11  7  3  39:22    4  5 12  14:32    53:54   -1   57
11. Manchester City               42  12  4  5  36:20    3  7 11  21:40    57:60   -3   56
12. Sheffield United              42  11  4  6  28:18    4  6 11  23:41    51:59   -8   55
13. Chelsea                       42   9  6  6  30:22    4  8  9  19:29    49:51   -2   53
14. Stoke City                    42  11  8  2  38:17    3  2 16  23:39    61:56   +5   52
15. Southampton                   42   8 11  2  26:17    3  7 11  21:35    47:52   -5   51
16. Everton                       42   9  5  7  27:21    4  6 11  14:28    41:49   -8   50
17. Manchester United             42   9  7  5  24:19    3  6 12  20:41    44:60  -16   49
18. Coventry City                 42   9  5  7  27:24    4  4 13  13:31    40:55  -15   48
19. Leicester City                42   7  9  5  23:18    3  8 10  17:28    40:46   -6   47
20. Norwich City                  42   7  9  5  22:19    4  1 16  14:44    36:63  -27   43
21. Crystal Palace                42   7  7  7  25:21    2  5 14  16:37    41:58  -17   39
22. West Bromwich Albion          42   8  7  6  25:24    1  3 17  13:38    38:62  -24   37
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Burnley                       42  13  6  2  44:18   11  8  2  28:17    72:35  +37   86
 2. Queens Park Rangers           42  16  4  1  54:13    8  9  4  27:24    81:37  +44   85
 3. Aston Villa                   42  12  5  4  27:17    6  9  6  24:30    51:47   +4   68
 4. Oxford United                 42  14  2  5  36:18    5  5 11  16:25    52:43   +9   64
 5. Blackpool                     42  12  6  3  37:17    6  4 11  19:34    56:51   +5   64
 6. Middlesbrough                 42  12  6  3  29:15    5  7  9  17:28    46:43   +3   64
 7. Bristol City                  42  10  7  4  34:18    7  5  9  29:33    63:51  +12   63
 8. Sunderland                    42  12  6  3  35:17    5  6 10  24:32    59:49  +10   63
 9. Sheffield Wednesday           42  14  4  3  40:20    3  6 12  19:35    59:55   +4   61
10. Fulham                        42  11  6  4  32:16    5  6 10  26:33    58:49   +9   60
11. Millwall                      42  12  5  4  33:18    4  5 12  22:29    55:47   +8   58
12. Luton Town                    42   6  9  6  24:23    9  2 10  20:30    44:53   -9   56
13. Hull City                     42   9  7  5  39:22    5  5 11  25:37    64:59   +5   54
14. Nottingham Forest             42  12  5  4  32:18    2  7 12  15:34    47:52   -5   54
15. Leyton Orient                 42  11  6  4  33:18    1  6 14  16:35    49:53   -4   48
16. Portsmouth                    42   7  6  8  21:22    5  5 11  21:37    42:59  -17   47
17. Swindon Town                  42   8  9  4  28:23    2  7 12  18:37    46:60  -14   46
18. Carlisle United               42  10  5  6  40:24    1  7 13  10:28    50:52   -2   45
19. Preston North End             42   6  8  7  19:25    5  4 12  18:39    37:64  -27   45
20. Cardiff City                  42  11  4  6  32:21    0  7 14  11:37    43:58  -15   44
21. Huddersfield Town             42   7  9  5  21:20    1  8 12  15:36    36:56  -20   41
22. Brighton & Hove Albion        42   7  8  6  32:31    1  5 15  14:52    46:83  -37   37
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Bolton Wanderers              46  18  4  1  44:9     7  7  9  29:30    73:39  +34   86
 2. Notts County                  46  17  4  2  40:12    6  7 10  27:35    67:47  +20   80
 3. Blackburn Rovers              46  12  8  3  34:16    8  7  8  23:31    57:47  +10   75
 4. Port Vale                     46  15  6  2  41:21    6  5 12  15:48    56:69  -13   74
 5. Bristol Rovers                46  17  4  2  55:20    3  9 11  22:36    77:56  +21   73
 6. Oldham Athletic               46  12  7  4  40:18    7  9  7  32:36    72:54  +18   73
 7. Plymouth Argyle               46  14  3  6  43:26    6  7 10  31:40    74:66   +8   70
 8. Grimsby Town                  46  16  2  5  45:18    4  6 13  22:43    67:61   +6   68
 9. AFC Bournemouth               46  14  6  3  44:16    3 10 10  22:28    66:44  +22   67
10. Charlton Athletic             46  12  7  4  46:24    5  4 14  23:43    69:67   +2   62
11. Southend United               46  13  6  4  40:14    4  4 15  21:40    61:54   +7   61
12. Tranmere Rovers               46  12  8  3  38:17    3  8 12  18:35    56:52   +4   61
13. Walsall                       46  14  3  6  37:26    4  4 15  19:40    56:66  -10   61
14. Chesterfield                  46  13  4  6  37:22    4  5 14  20:39    57:61   -4   60
15. Wrexham                       46  11  9  3  39:23    3  8 12  16:31    55:54   +1   59
16. Rochdale                      46   8  8  7  22:26    6  9  8  26:28    48:54   -6   59
17. Shrewsbury Town               46  10 10  3  31:21    5  4 14  15:33    46:54   -8   59
18. Rotherham United              46  12  4  7  34:27    5  3 15  17:38    51:65  -14   58
19. York City                     46   8 10  5  24:14    5  5 13  18:32    42:46   -4   54
20. Halifax Town                  46   9  8  6  29:23    4  7 12  14:30    43:53  -10   54
21. Watford                       46  11  8  4  32:23    1  9 13  11:25    43:48   -5   53
22. Brentford                     46  12  5  6  33:18    3  2 18  18:51    51:69  -18   52
23. Swansea City                  46  11  5  7  37:29    3  4 16  14:44    51:73  -22   51
24. Scunthorpe United             46   8  7  8  18:25    2  3 18  15:47    33:72  -39   40
~~~

(Source: `3-division3.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Southport                     46  17  4  2  40:19    9  6  8  31:29    71:48  +23   88
 2. Hereford United               46  18  4  1  39:12    5  8 10  17:26    56:38  +18   81
 3. Aldershot                     46  14  6  3  33:14    8  6  9  27:24    60:38  +22   78
 4. Newport County                46  14  6  3  37:18    8  6  9  27:26    64:44  +20   78
 5. Cambridge United              46  15  6  2  40:23    5 11  7  27:34    67:57  +10   77
 6. Mansfield Town                46  15  7  1  52:17    5  7 11  26:34    78:51  +27   74
 7. Reading                       46  14  7  2  33:7     3 11  9  18:31    51:38  +13   69
 8. Exeter City                   46  13  8  2  40:18    5  6 12  17:33    57:51   +6   68
 9. Gillingham                    46  15  4  4  44:20    4  7 12  19:38    63:58   +5   68
10. Stockport County              46  14  7  2  38:18    4  5 14  15:35    53:53        66
11. Lincoln City                  46  12  7  4  38:27    4  9 10  26:30    64:57   +7   64
12. Workington                    46  15  7  1  44:20    2  5 16  15:41    59:61   -2   63
13. Bury                          46  11  7  5  37:19    3 11  9  21:32    58:51   +7   60
14. Bradford City                 46  12  6  5  42:25    4  5 14  19:40    61:65   -4   59
15. Barnsley                      46   9  8  6  32:24    5  8 10  26:36    58:60   -2   58
16. Chester                       46  11  6  6  40:19    3  9 11  21:33    61:52   +9   57
17. Doncaster Rovers              46  10  8  5  28:19    5  4 14  21:39    49:58   -9   57
18. Peterborough United           46  10  8  5  42:29    4  5 14  29:47    71:76   -5   55
19. Torquay United                46   8 10  5  23:17    4  7 12  21:30    44:47   -3   53
20. Hartlepool United             46   8 10  5  17:15    4  7 12  17:34    34:49  -15   53
21. Crewe Alexandra               46   7  8  8  18:23    2 10 11  20:38    38:61  -23   45
22. Colchester United             46   8  8  7  36:28    2  3 18  12:48    48:76  -28   41
23. Northampton Town              46   7  6 10  24:30    3  5 15  16:43    40:73  -33   41
24. Darlington                    46   5  9  9  28:41    2  6 15  14:44    42:85  -43   36
~~~

(Source: `4-division4.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

