

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Nottingham Forest             42  15  6  0  37:8    10  8  3  32:16    69:24  +45   89
 2. Liverpool                     42  15  4  2  37:11    9  5  7  28:23    65:34  +31   81
 3. Everton                       42  14  4  3  47:22    8  7  6  29:23    76:45  +31   77
 4. Arsenal                       42  14  5  2  38:12    7  5  9  22:25    60:37  +23   73
 5. Manchester City               42  14  4  3  46:21    6  8  7  28:30    74:51  +23   72
 6. West Bromwich Albion          42  13  5  3  35:18    5  9  7  27:35    62:53   +9   68
 7. Coventry City                 42  13  5  3  48:23    5  7  9  27:39    75:62  +13   66
 8. Aston Villa                   42  11  4  6  33:18    7  6  8  24:24    57:42  +15   64
 9. Leeds United                  42  12  4  5  39:21    6  6  9  24:32    63:53  +10   64
10. Manchester United             42   9  6  6  32:23    7  4 10  35:40    67:63   +4   58
11. Birmingham City               42   8  5  8  32:30    8  4  9  23:30    55:60   -5   57
12. Derby County                  42  10  7  4  37:24    4  6 11  17:35    54:59   -5   55
13. Middlesbrough                 42   8  8  5  25:19    4  7 10  17:35    42:54  -12   51
14. Norwich City                  42  10  8  3  28:20    1 10 10  24:46    52:66  -14   51
15. Wolverhampton Wanderers       42   7  8  6  30:27    5  4 12  21:37    51:64  -13   48
16. Chelsea                       42   7 11  3  28:20    4  3 14  18:49    46:69  -23   47
17. Bristol City                  42   9  6  6  37:26    2  7 12  12:27    49:53   -4   46
18. Ipswich Town                  42  10  5  6  32:24    1  8 12  15:37    47:61  -14   46
19. West Ham United               42   8  6  7  31:28    4  2 15  21:41    52:69  -17   44
20. Queens Park Rangers           42   8  8  5  27:26    1  7 13  20:38    47:64  -17   42
21. Newcastle United              42   4  6 11  26:37    2  4 15  16:41    42:78  -36   28
22. Leicester City                42   4  7 10  16:32    1  5 15  10:38    26:70  -44   27
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Bolton Wanderers              42  16  4  1  39:14    8  6  7  24:19    63:33  +30   82
 2. Southampton                   42  15  4  2  44:16    7  9  5  26:23    70:39  +31   79
 3. Brighton & Hove Albion        42  15  5  1  43:21    7  7  7  20:17    63:38  +25   78
 4. Tottenham Hotspur             42  13  7  1  50:19    7  9  5  33:30    83:49  +34   76
 5. Blackburn Rovers              42  12  4  5  33:16    4  9  8  23:44    56:60   -4   61
 6. Sunderland                    42  11  6  4  36:17    3 10  8  31:42    67:59   +8   58
 7. Stoke City                    42  13  5  3  38:16    3  5 13  15:33    53:49   +4   58
 8. Sheffield United              42  13  4  4  38:22    3  4 14  24:51    62:73  -11   56
 9. Fulham                        42   9  8  4  32:19    5  5 11  17:30    49:49        55
10. Oldham Athletic               42   9 10  2  32:20    4  6 11  22:38    54:58   -4   55
11. Burnley                       42  11  6  4  35:20    4  4 13  21:44    56:64   -8   55
12. Crystal Palace                42   9  7  5  31:20    4  8  9  19:27    50:47   +3   54
13. Luton Town                    42  11  4  6  35:20    3  6 12  19:32    54:52   +2   52
14. Charlton Athletic             42  11  6  4  38:27    2  6 13  17:41    55:68  -13   51
15. Bristol Rovers                42  10  7  4  40:26    3  5 13  21:51    61:77  -16   51
16. Cardiff City                  42  12  6  3  32:23    1  6 14  19:48    51:71  -20   51
17. Millwall                      42   8  8  5  23:20    4  6 11  26:37    49:57   -8   50
18. Blackpool                     42   7  8  6  35:25    5  5 11  24:35    59:60   -1   49
19. Notts County                  42  10  9  2  36:22    1  7 13  18:40    54:62   -8   49
20. Leyton Orient                 42   8 11  2  30:20    2  7 12  13:29    43:49   -6   48
21. Mansfield Town                42   6  6  9  30:34    4  5 12  19:35    49:69  -20   41
22. Hull City                     42   6  6  9  23:25    2  6 13  11:27    34:52  -18   36
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Wrexham                       46  14  8  1  48:19    9  7  7  30:26    78:45  +33   84
 2. Cambridge United              46  19  3  1  49:11    4  9 10  23:40    72:51  +21   81
 3. Preston North End             46  16  5  2  48:19    4 11  8  15:19    63:38  +25   76
 4. Peterborough United           46  15  7  1  32:11    5  9  9  15:22    47:33  +14   76
 5. Walsall                       46  12  8  3  35:17    6  9  8  26:33    61:50  +11   71
 6. Chester                       46  14  8  1  41:24    2 14  7  18:32    59:56   +3   70
 7. Chesterfield                  46  14  6  3  40:16    3  8 12  18:33    58:49   +9   65
 8. Gillingham                    46  11 10  2  36:21    4 10  9  31:39    67:60   +7   65
 9. Swindon Town                  46  12  7  4  40:22    4  9 10  27:38    67:60   +7   64
10. Colchester United             46  10 11  2  36:16    5  7 11  19:28    55:44  +11   63
11. Shrewsbury Town               46  11  7  5  42:23    5  8 10  21:34    63:57   +6   63
12. Tranmere Rovers               46  13  7  3  39:19    3  8 12  18:33    57:52   +5   63
13. Carlisle United               46  10  9  4  32:26    4 10  9  27:33    59:59        61
14. Sheffield Wednesday           46  13  7  3  28:14    2  9 12  22:38    50:52   -2   61
15. Lincoln City                  46  10  8  5  35:26    5  7 11  18:35    53:61   -8   60
16. Exeter City                   46  11  8  4  30:18    4  6 13  19:41    49:59  -10   59
17. Bury                          46   7 13  3  34:22    6  6 11  28:34    62:56   +6   58
18. Oxford United                 46  11 10  2  38:21    2  4 17  26:46    64:67   -3   53
19. Rotherham United              46  11  5  7  26:19    2  8 13  25:49    51:68  -17   52
20. Plymouth Argyle               46   7  8  8  33:28    4  9 10  28:40    61:68   -7   50
21. Bradford City                 46  11  6  6  40:29    1  4 18  16:57    56:86  -30   46
22. Port Vale                     46   7 11  5  28:23    1  9 13  18:44    46:67  -21   44
23. Hereford United               46   9  9  5  28:22    0  5 18   6:38    34:60  -26   41
24. Portsmouth                    46   4 11  8  31:38    3  6 14  10:37    41:75  -34   38
~~~

(Source: `3-division3.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Watford                       46  18  4  1  44:14   12  7  4  41:24    85:38  +47  101
 2. Southend United               46  15  5  3  46:18   10  5  8  20:21    66:39  +27   85
 3. Swansea City                  46  16  5  2  54:17    7  5 11  33:30    87:47  +40   79
 4. Brentford                     46  15  6  2  50:17    6  8  9  36:37    86:54  +32   77
 5. Grimsby Town                  46  14  6  3  30:15    7  5 11  27:36    57:51   +6   74
 6. Aldershot                     46  15  8  0  45:16    4  8 11  22:31    67:47  +20   73
 7. Barnsley                      46  15  4  4  44:20    3 10 10  17:29    61:49  +12   68
 8. Reading                       46  12  7  4  33:23    6  7 10  22:29    55:52   +3   68
 9. Northampton Town              46   9  8  6  32:30    8  5 10  31:38    63:68   -5   64
10. Torquay United                46  12  6  5  43:25    4  9 10  14:31    57:56   +1   63
11. Huddersfield Town             46  13  5  5  41:21    2 10 11  22:34    63:55   +8   60
12. Newport County                46  14  6  3  43:22    2  5 16  22:51    65:73   -8   59
13. Doncaster Rovers              46  11  8  4  37:26    3  9 11  15:39    52:65  -13   59
14. Crewe Alexandra               46  11  8  4  34:25    4  6 13  16:44    50:69  -19   59
15. Stockport County              46  14  4  5  41:19    2  6 15  15:37    56:56        58
16. Wimbledon                     46   8 11  4  39:26    6  5 12  27:41    66:67   -1   58
17. Scunthorpe United             46  12  6  5  31:14    2 10 11  19:41    50:55   -5   58
18. AFC Bournemouth               46  12  6  5  28:20    2  9 12  13:31    41:51  -10   57
19. Darlington                    46  10  8  5  31:22    4  5 14  21:37    52:59   -7   55
20. Hartlepool United             46  12  4  7  34:29    3  3 17  17:55    51:84  -33   52
21. Halifax Town                  46   7 10  6  28:23    3 11  9  24:39    52:62  -10   51
22. York City                     46   8  7  8  27:31    4  5 14  23:38    50:69  -19   48
23. Southport                     46   5 13  5  30:32    1  6 16  22:44    52:76  -24   37
24. Rochdale                      46   8  6  9  29:28    0  2 21  14:57    43:85  -42   32
~~~

(Source: `4-division4.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

