

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Liverpool                     42  14  5  2  41:21    9  9  3  25:10    66:31  +35   83
 2. Queens Park Rangers           42  17  4  0  42:13    7  7  7  25:20    67:33  +34   83
 3. Manchester United             42  16  4  1  40:13    7  6  8  28:29    68:42  +26   79
 4. Derby County                  42  15  3  3  45:30    6  8  7  30:28    75:58  +17   74
 5. Leeds United                  42  13  3  5  37:19    8  6  7  28:27    65:46  +19   72
 6. Ipswich Town                  42  11  6  4  36:23    5  8  8  18:25    54:48   +6   62
 7. Manchester City               42  14  5  2  46:18    2  6 13  18:28    64:46  +18   59
 8. Norwich City                  42  10  5  6  33:26    6  5 10  25:32    58:58        58
 9. Leicester City                42   9  9  3  29:24    4 10  7  19:27    48:51   -3   58
10. Tottenham Hotspur             42   6 10  5  33:32    8  5  8  30:31    63:63        57
11. Everton                       42  10  7  4  37:24    5  5 11  23:42    60:66   -6   57
12. Stoke City                    42   8  5  8  25:24    7  6  8  23:26    48:50   -2   56
13. Middlesbrough                 42   9  7  5  23:11    6  3 12  23:34    46:45   +1   55
14. Newcastle United              42  11  4  6  51:26    4  5 12  20:36    71:62   +9   54
15. Coventry City                 42   6  9  6  22:22    7  5  9  25:35    47:57  -10   53
16. Aston Villa                   42  11  8  2  32:17    0  9 12  19:42    51:59   -8   50
17. Arsenal                       42  11  4  6  33:19    2  6 13  14:34    47:53   -6   49
18. West Ham United               42  10  5  6  26:23    3  5 13  22:48    48:71  -23   49
19. Birmingham City               42  11  5  5  36:26    2  2 17  21:49    57:75  -18   46
20. Wolverhampton Wanderers       42   7  6  8  27:25    3  4 14  24:43    51:68  -17   40
21. Burnley                       42   6  6  9  23:26    3  4 14  20:40    43:66  -23   37
22. Sheffield United              42   4  7 10  19:32    2  3 16  14:50    33:82  -49   28
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Sunderland                    42  19  2  0  48:10    5  6 10  19:26    67:36  +31   80
 2. West Bromwich Albion          42  10  9  2  29:12   10  4  7  21:21    50:33  +17   73
 3. Bolton Wanderers              42  12  5  4  36:14    8  7  6  28:24    64:38  +26   72
 4. Bristol City                  42  11  7  3  34:14    8  8  5  25:21    59:35  +24   72
 5. Southampton                   42  18  2  1  49:16    3  5 13  17:34    66:50  +16   70
 6. Notts County                  42  11  6  4  33:13    8  5  8  27:28    60:41  +19   68
 7. Luton Town                    42  13  6  2  38:15    6  4 11  23:36    61:51  +10   67
 8. Nottingham Forest             42  13  1  7  34:18    4 11  6  21:22    55:40  +15   63
 9. Charlton Athletic             42  11  5  5  40:34    4  7 10  21:38    61:72  -11   57
10. Blackpool                     42   9  9  3  26:22    5  5 11  14:27    40:49   -9   56
11. Fulham                        42   9  8  4  27:14    4  6 11  18:33    45:47   -2   53
12. Leyton Orient                 42  10  6  5  21:12    3  8 10  16:27    37:39   -2   53
13. Hull City                     42   9  5  7  29:23    5  6 10  16:26    45:49   -4   53
14. Chelsea                       42   7  9  5  25:20    5  7  9  28:34    53:54   -1   52
15. Plymouth Argyle               42  13  4  4  36:20    0  8 13  12:34    48:54   -6   51
16. Oldham Athletic               42  11  8  2  37:24    2  4 15  20:44    57:68  -11   51
17. Blackburn Rovers              42   8  6  7  27:22    4  8  9  18:28    45:50   -5   50
18. Bristol Rovers                42   7  9  5  20:15    4  7 10  18:35    38:50  -12   49
19. Carlisle United               42   9  8  4  29:22    3  5 13  16:37    45:59  -14   49
20. Oxford United                 42   7  7  7  23:25    4  4 13  16:34    39:59  -20   44
21. York City                     42   8  3 10  28:34    2  5 14  11:37    39:71  -32   38
22. Portsmouth                    42   4  6 11  15:23    5  1 15  17:38    32:61  -29   34
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Hereford United               46  14  6  3  45:24   12  5  6  41:31    86:55  +31   89
 2. Cardiff City                  46  14  7  2  38:13    8  6  9  31:35    69:48  +21   79
 3. Millwall                      46  16  6  1  35:14    4 10  9  19:29    54:43  +11   76
 4. Brighton & Hove Albion        46  18  3  2  58:15    4  6 13  20:38    78:53  +25   75
 5. Wrexham                       46  13  6  4  38:21    7  6 10  28:34    66:55  +11   72
 6. Crystal Palace                46   7 12  4  30:20   11  5  7  31:26    61:46  +15   71
 7. Walsall                       46  11  8  4  43:22    7  6 10  31:39    74:61  +13   68
 8. Preston North End             46  15  4  4  45:23    4  6 13  17:34    62:57   +5   67
 9. Shrewsbury Town               46  14  2  7  36:25    5  8 10  25:34    61:59   +2   67
10. Mansfield Town                46   8 11  4  31:22    8  4 11  27:30    58:52   +6   63
11. Peterborough United           46  12  7  4  37:23    3 11  9  26:40    63:63        63
12. Port Vale                     46  10 10  3  33:21    5  6 12  22:33    55:54   +1   61
13. Chesterfield                  46  11  5  7  45:30    6  4 13  24:39    69:69        60
14. Bury                          46  11  7  5  33:16    3  9 11  18:30    51:46   +5   58
15. Rotherham United              46  11  6  6  35:22    4  6 13  19:43    54:65  -11   57
16. Chester                       46  13  7  3  34:19    2  5 16   9:43    43:62  -19   57
17. Swindon Town                  46  11  4  8  42:31    5  4 14  20:44    62:75  -13   56
18. Gillingham                    46  10  8  5  38:27    2 11 10  20:41    58:68  -10   55
19. Grimsby Town                  46  13  7  3  39:21    2  3 18  23:53    62:74  -12   55
20. Sheffield Wednesday           46  12  6  5  34:25    0 10 13  14:34    48:59  -11   52
21. Aldershot                     46  10  8  5  34:26    3  5 15  25:49    59:75  -16   52
22. Colchester United             46   9  6  8  25:27    3  8 12  16:38    41:65  -24   50
23. Southend United               46   9  7  7  40:31    3  6 14  25:44    65:75  -10   49
24. Halifax Town                  46   6  5 12  22:32    5  8 10  19:29    41:61  -20   46
~~~

(Source: `3-division3.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Lincoln City                  46  21  2  0  71:15   11  8  4  40:24   111:39  +72  106
 2. Northampton Town              46  18  5  0  62:20   11  5  7  25:20    87:40  +47   97
 3. Reading                       46  19  3  1  42:9     5  9  9  28:42    70:51  +19   84
 4. Tranmere Rovers               46  18  3  2  61:16    6  7 10  28:39    89:55  +34   82
 5. Huddersfield Town             46  11  6  6  28:17   10  8  5  28:24    56:41  +15   77
 6. AFC Bournemouth               46  15  5  3  39:16    5  7 11  18:32    57:48   +9   72
 7. Watford                       46  16  4  3  38:18    6  2 15  24:44    62:62        72
 8. Exeter City                   46  13  7  3  37:17    5  7 11  19:30    56:47   +9   68
 9. Doncaster Rovers              46  10  6  7  42:31    9  5  9  33:38    75:69   +6   68
10. Torquay United                46  12  6  5  31:24    6  8  9  24:39    55:63   -8   68
11. Swansea City                  46  14  8  1  51:21    2  7 14  15:36    66:57   +9   63
12. Barnsley                      46  12  8  3  34:16    2  8 13  18:32    52:48   +4   58
13. Hartlepool United             46  10  6  7  37:29    6  4 13  25:49    62:78  -16   58
14. Cambridge United              46   7 10  6  36:28    7  5 11  22:34    58:62   -4   57
15. Brentford                     46  12  7  4  37:18    2  6 15  19:42    56:60   -4   55
16. Crewe Alexandra               46  10  7  6  36:21    3  8 12  22:36    58:57   +1   54
17. Rochdale                      46   7 11  5  27:23    5  7 11  13:31    40:54  -14   54
18. Bradford City                 46   9  7  7  35:26    3 10 10  28:39    63:65   -2   53
19. Scunthorpe United             46  11  3  9  31:24    3  7 13  19:35    50:59   -9   52
20. Darlington                    46  11  7  5  30:14    3  3 17  18:43    48:57   -9   52
21. Stockport County              46   8  7  8  23:23    5  5 13  20:53    43:76  -33   51
22. Newport County                46   8  7  8  35:33    5  2 16  22:57    57:90  -33   48
23. Southport                     46   6  6 11  27:31    2  4 17  14:46    41:77  -36   34
24. Workington                    46   5  4 14  19:43    2  3 18  11:44    30:87  -57   28
~~~

(Source: `4-division4.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

