

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Liverpool                     42  19  2  0  51:4    11  6  4  34:12    85:16  +69   98
 2. West Bromwich Albion          42  13  5  3  38:15   11  6  4  34:20    72:35  +37   83
 3. Nottingham Forest             42  11 10  0  34:10   10  8  3  27:16    61:26  +35   81
 4. Ipswich Town                  42  11  4  6  34:21    9  5  7  29:28    63:49  +14   69
 5. Leeds United                  42  11  4  6  41:25    7 10  4  29:27    70:52  +18   68
 6. Everton                       42  12  7  2  32:17    5 10  6  20:23    52:40  +12   68
 7. Arsenal                       42  11  8  2  37:18    6  6  9  24:30    61:48  +13   65
 8. Aston Villa                   42   8  9  4  37:26    7  7  7  22:23    59:49  +10   61
 9. Manchester United             42   9  7  5  29:25    6  8  7  31:38    60:63   -3   60
10. Coventry City                 42  11  7  3  41:29    3  9  9  17:39    58:68  -10   58
11. Middlesbrough                 42  10  5  6  33:21    5  5 11  24:29    57:50   +7   55
12. Bristol City                  42  11  6  4  34:19    4  4 13  13:32    47:51   -4   55
13. Tottenham Hotspur             42   7  8  6  19:25    6  7  8  29:36    48:61  -13   54
14. Manchester City               42   9  5  7  34:28    4  8  9  24:28    58:56   +2   52
15. Southampton                   42   9 10  2  35:20    3  6 12  12:33    47:53   -6   52
16. Bolton Wanderers              42  10  5  6  36:28    2  6 13  18:47    54:75  -21   47
17. Wolverhampton Wanderers       42  10  4  7  26:26    3  4 14  18:42    44:68  -24   47
18. Norwich City                  42   7 10  4  29:19    0 13  8  22:38    51:57   -6   44
19. Derby County                  42   8  5  8  25:25    2  6 13  19:46    44:71  -27   41
20. Queens Park Rangers           42   4  9  8  24:33    2  4 15  21:40    45:73  -28   31
21. Birmingham City               42   5  9  7  24:25    1  1 19  13:39    37:64  -27   28
22. Chelsea                       42   3  5 13  23:42    2  5 14  21:50    44:92  -48   25
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Brighton & Hove Albion        42  16  3  2  44:11    7  7  7  28:28    72:39  +33   79
 2. Sunderland                    42  13  3  5  39:19    9  8  4  31:25    70:44  +26   77
 3. Stoke City                    42  11  7  3  35:15    9  9  3  23:16    58:31  +27   76
 4. Crystal Palace                42  12  7  2  30:11    7 12  2  21:13    51:24  +27   76
 5. West Ham United               42  12  7  2  46:15    6  7  8  24:24    70:39  +31   68
 6. Newcastle United              42  13  3  5  35:24    4  5 12  16:31    51:55   -4   59
 7. Notts County                  42   8 10  3  23:15    6  6  9  25:45    48:60  -12   58
 8. Cardiff City                  42  12  5  4  34:23    4  5 12  22:47    56:70  -14   58
 9. Leyton Orient                 42  11  5  5  32:18    4  5 12  19:33    51:51        55
10. Fulham                        42  10  7  4  35:19    3  8 10  15:28    50:47   +3   54
11. Preston North End             42   7 11  3  36:23    5  7  9  23:34    59:57   +2   54
12. Burnley                       42  11  6  4  31:22    3  6 12  20:40    51:62  -11   54
13. Cambridge United              42   7 10  4  22:15    5  6 10  22:37    44:52   -8   52
14. Oldham Athletic               42  10  7  4  36:23    3  6 12  16:38    52:61   -9   52
15. Bristol Rovers                42  10  6  5  34:23    4  4 13  14:37    48:60  -12   52
16. Wrexham                       42  10  6  5  31:16    2  8 11  14:26    45:42   +3   50
17. Luton Town                    42  11  5  5  46:24    2  5 14  14:33    60:57   +3   49
18. Leicester City                42   7  8  6  28:23    3  9  9  15:29    43:52   -9   47
19. Charlton Athletic             42   6  8  7  28:28    5  5 11  32:41    60:69   -9   46
20. Sheffield United              42   9  6  6  34:24    2  6 13  18:45    52:69  -17   45
21. Millwall                      42   7  4 10  22:29    4  6 11  20:32    42:61  -19   43
22. Blackburn Rovers              42   5  8  8  24:29    5  2 14  17:43    41:72  -31   40
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Watford                       46  15  5  3  47:22    9  7  7  36:30    83:52  +31   84
 2. Swansea City                  46  16  6  1  57:32    8  6  9  26:29    83:61  +22   84
 3. Swindon Town                  46  17  2  4  44:14    8  5 10  30:38    74:52  +22   82
 4. Shrewsbury Town               46  14  9  0  36:11    7 10  6  25:30    61:41  +20   82
 5. Gillingham                    46  15  7  1  39:15    6 10  7  26:27    65:42  +23   80
 6. Hull City                     46  12  9  2  36:14    7  2 14  30:47    66:61   +5   68
 7. Colchester United             46  13  9  1  35:19    4  8 11  25:36    60:55   +5   68
 8. Carlisle United               46  11 10  2  31:13    4 12  7  22:29    53:42  +11   67
 9. Exeter City                   46  14  6  3  38:18    3  9 11  23:38    61:56   +5   66
10. Brentford                     46  14  4  5  35:19    5  5 13  18:30    53:49   +4   66
11. Blackpool                     46  12  5  6  38:19    6  4 13  23:40    61:59   +2   63
12. Rotherham United              46  13  3  7  30:23    4  7 12  19:32    49:55   -6   61
13. Southend United               46  11  6  6  30:17    4  9 10  21:32    51:49   +2   60
14. Oxford United                 46  10  8  5  27:20    4 10  9  17:30    44:50   -6   60
15. Plymouth Argyle               46  11  9  3  40:27    4  5 14  27:41    67:68   -1   59
16. Sheffield Wednesday           46   9  8  6  30:22    4 11  8  23:31    53:53        58
17. Chester                       46  11  9  3  42:21    3  7 13  15:40    57:61   -4   58
18. Mansfield Town                46   7 11  5  30:24    5  8 10  21:28    51:52   -1   55
19. Bury                          46   6 11  6  35:32    5  9  9  24:33    59:65   -6   53
20. Chesterfield                  46  10  5  8  35:34    3  9 11  16:31    51:65  -14   53
21. Peterborough United           46   8  7  8  26:24    3  7 13  18:39    44:63  -19   47
22. Walsall                       46   7  6 10  34:32    3  6 14  22:39    56:71  -15   42
23. Tranmere Rovers               46   4 12  7  26:31    2  4 17  19:47    45:78  -33   34
24. Lincoln City                  46   5  7 11  26:38    2  4 17  15:50    41:88  -47   32
~~~

(Source: `3-division3.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Reading                       46  19  3  1  49:8     7 10  6  27:27    76:35  +41   91
 2. Grimsby Town                  46  15  5  3  51:23   11  4  8  31:26    82:49  +33   87
 3. Wimbledon                     46  18  3  2  50:20    7  8  8  28:26    78:46  +32   86
 4. Barnsley                      46  15  5  3  47:23    9  8  6  26:19    73:42  +31   85
 5. Aldershot                     46  16  5  2  38:14    4 12  7  25:33    63:47  +16   77
 6. Wigan Athletic                46  14  5  4  40:24    7  8  8  23:24    63:48  +15   76
 7. Newport County                46  12  5  6  39:28    9  5  9  27:27    66:55  +11   73
 8. Portsmouth                    46  13  7  3  35:12    7  5 11  27:36    62:48  +14   72
 9. Huddersfield Town             46  13  8  2  32:15    5  3 15  25:38    57:53   +4   65
10. York City                     46  11  6  6  33:24    7  5 11  18:31    51:55   -4   65
11. Torquay United                46  14  4  5  38:24    5  4 14  20:41    58:65   -7   65
12. Scunthorpe United             46  12  3  8  33:30    5  8 10  21:30    54:60   -6   62
13. Bradford City                 46  11  5  7  38:26    6  4 13  24:42    62:68   -6   60
14. Hereford United               46  12  8  3  35:18    3  5 15  18:35    53:53        58
15. Hartlepool United             46   7 12  4  35:28    6  6 11  22:38    57:66   -9   57
16. Port Vale                     46   8 10  5  29:28    6  4 13  28:42    57:70  -13   56
17. Stockport County              46  11  5  7  33:21    3  7 13  25:39    58:60   -2   54
18. Northampton Town              46  12  4  7  40:30    3  5 15  24:46    64:76  -12   54
19. Rochdale                      46  11  4  8  25:26    4  5 14  22:38    47:64  -17   54
20. AFC Bournemouth               46  11  6  6  34:19    3  5 15  13:29    47:48   -1   53
21. Doncaster Rovers              46   8  8  7  25:22    5  3 15  25:51    50:73  -23   50
22. Darlington                    46   8  8  7  25:21    3  7 13  24:45    49:66  -17   48
23. Halifax Town                  46   7  5 11  24:32    2  3 18  15:40    39:72  -33   35
24. Crewe Alexandra               46   3  7 13  24:41    3  7 13  19:49    43:90  -47   32
~~~

(Source: `4-division4.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

