

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Liverpool                     42  18  3  0  47:11    5  8  8  15:22    62:33  +29   80
 2. Manchester City               42  15  5  1  38:13    6  9  6  22:21    60:34  +26   77
 3. Ipswich Town                  42  15  4  2  41:11    7  4 10  25:28    66:39  +27   74
 4. Aston Villa                   42  17  3  1  55:17    5  4 12  21:33    76:50  +26   73
 5. Newcastle United              42  14  6  1  40:15    4  7 10  24:34    64:49  +15   67
 6. Manchester United             42  12  6  3  41:22    6  5 10  30:40    71:62   +9   65
 7. West Bromwich Albion          42  10  6  5  38:22    6  7  8  24:34    62:56   +6   61
 8. Arsenal                       42  11  6  4  37:20    5  5 11  27:39    64:59   +5   59
 9. Leeds United                  42   8  8  5  28:26    7  4 10  20:25    48:51   -3   57
10. Everton                       42   9  7  5  35:24    5  7  9  27:40    62:64   -2   56
11. Middlesbrough                 42  11  6  4  25:14    3  7 11  15:31    40:45   -5   55
12. Leicester City                42   8  9  4  30:28    4  9  8  17:32    47:60  -13   54
13. Birmingham City               42  10  6  5  38:25    3  6 12  25:36    63:61   +2   51
14. Queens Park Rangers           42  10  7  4  31:21    3  5 13  16:31    47:52   -5   51
15. Norwich City                  42  12  4  5  30:23    2  5 14  17:41    47:64  -17   51
16. West Ham United               42   9  6  6  28:23    2  8 11  18:42    46:65  -19   47
17. Derby County                  42   9  9  3  36:18    0 10 11  14:37    50:55   -5   46
18. Bristol City                  42   8  7  6  25:19    3  6 12  13:29    38:48  -10   46
19. Sunderland                    42   9  5  7  29:16    2  7 12  17:38    46:54   -8   45
20. Coventry City                 42   7  9  5  34:26    3  6 12  14:33    48:59  -11   45
21. Tottenham Hotspur             42   9  7  5  26:20    3  2 16  22:52    48:72  -24   45
22. Stoke City                    42   9  8  4  21:16    1  6 14   7:35    28:51  -23   44
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Wolverhampton Wanderers       42  15  3  3  48:21    7 10  4  36:24    84:45  +39   79
 2. Chelsea                       42  15  6  0  51:22    6  7  8  22:31    73:53  +20   76
 3. Nottingham Forest             42  14  3  4  53:22    7  7  7  24:21    77:43  +34   73
 4. Bolton Wanderers              42  15  2  4  46:21    5  9  7  29:33    75:54  +21   71
 5. Luton Town                    42  13  5  3  39:17    8  1 12  28:31    67:48  +19   69
 6. Blackpool                     42  11  7  3  29:17    6 10  5  29:25    58:42  +16   68
 7. Notts County                  42  11  5  5  29:20    8  5  8  36:40    65:60   +5   67
 8. Charlton Athletic             42  14  5  2  52:27    2 11  8  19:31    71:58  +13   64
 9. Southampton                   42  12  6  3  40:24    5  4 12  32:43    72:67   +5   61
10. Millwall                      42   9  6  6  31:22    6  7  8  26:31    57:53   +4   58
11. Sheffield United              42   9  8  4  32:25    5  4 12  22:38    54:63   -9   54
12. Blackburn Rovers              42  12  4  5  31:18    3  5 13  11:36    42:54  -12   54
13. Oldham Athletic               42  11  6  4  37:23    3  4 14  15:41    52:64  -12   52
14. Bristol Rovers                42   8  9  4  32:27    4  4 13  21:41    53:68  -15   49
15. Hull City                     42   9  8  4  31:17    1  9 11  14:36    45:53   -8   47
16. Carlisle United               42   7  7  7  31:33    5  4 12  26:37    57:70  -13   47
17. Burnley                       42   8  9  4  27:20    3  5 13  19:44    46:64  -18   47
18. Fulham                        42   9  7  5  39:25    2  6 13  15:36    54:61   -7   46
19. Cardiff City                  42   7  6  8  30:30    4  5 12  18:42    48:72  -24   44
20. Leyton Orient                 42   4  8  9  18:23    5  8  8  19:32    37:55  -18   43
21. Plymouth Argyle               42   5  9  7  27:25    3  7 11  19:40    46:65  -19   40
22. Hereford United               42   6  9  6  28:30    2  6 13  29:48    57:78  -21   39
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Mansfield Town                46  17  6  0  52:13   11  2 10  26:29    78:42  +36   92
 2. Brighton & Hove Albion        46  19  3  1  63:14    6  8  9  20:26    83:40  +43   86
 3. Crystal Palace                46  17  5  1  46:15    6  8  9  22:25    68:40  +28   82
 4. Wrexham                       46  15  6  2  47:22    9  4 10  33:32    80:54  +26   82
 5. Rotherham United              46  11  9  3  30:15   11  6  6  39:29    69:44  +25   81
 6. Bury                          46  15  2  6  41:21    8  6  9  23:38    64:59   +5   77
 7. Preston North End             46  15  4  4  48:21    6  8  9  16:22    64:43  +21   75
 8. Sheffield Wednesday           46  15  4  4  39:18    7  5 11  26:37    65:55  +10   75
 9. Lincoln City                  46  12  9  2  50:30    7  5 11  27:40    77:70   +7   71
10. Shrewsbury Town               46  13  7  3  40:21    5  4 14  25:38    65:59   +6   65
11. Chester                       46  14  3  6  28:20    4  5 14  20:38    48:58  -10   62
12. Swindon Town                  46  12  6  5  48:33    3  9 11  20:42    68:75   -7   60
13. Gillingham                    46  11  8  4  31:21    5  4 14  24:43    55:64   -9   60
14. Tranmere Rovers               46  10  7  6  31:23    3 10 10  20:30    51:53   -2   56
15. Walsall                       46   8  7  8  39:32    5  8 10  18:33    57:65   -8   54
16. Peterborough United           46  11  4  8  33:28    2 11 10  22:37    55:65  -10   54
17. Chesterfield                  46  10  6  7  30:20    4  4 15  26:44    56:64   -8   52
18. Oxford United                 46   9  8  6  34:29    3  7 13  21:36    55:65  -10   51
19. Port Vale                     46   9  7  7  29:28    2  9 12  18:43    47:71  -24   49
20. Reading                       46  10  5  8  29:24    3  4 16  20:49    49:73  -24   48
21. Northampton Town              46   9  4 10  33:29    4  4 15  27:46    60:75  -15   47
22. Portsmouth                    46   8  9  6  28:26    3  5 15  25:44    53:70  -17   47
23. Grimsby Town                  46  10  6  7  29:22    2  3 18  16:47    45:69  -24   45
24. York City                     46   7  8  8  25:34    3  4 16  25:55    50:89  -39   42
~~~

(Source: `3-division3.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Cambridge United              46  16  5  2  57:18   10  8  5  30:22    87:40  +47   91
 2. Exeter City                   46  17  5  1  40:13    8  7  8  30:33    70:46  +24   87
 3. Colchester United             46  19  2  2  51:14    6  7 10  26:29    77:43  +34   84
 4. Swansea City                  46  18  3  2  60:30    7  5 11  32:38    92:68  +24   83
 5. Bradford City                 46  16  7  0  51:18    7  6 10  27:33    78:51  +27   82
 6. Barnsley                      46  16  5  2  45:18    7  4 12  17:21    62:39  +23   78
 7. Doncaster Rovers              46  16  2  5  47:25    5  7 11  24:40    71:65   +6   72
 8. Watford                       46  15  7  1  46:13    3  8 12  21:37    67:50  +17   69
 9. Huddersfield Town             46  15  5  3  36:15    4  7 12  24:34    60:49  +11   69
10. Crewe Alexandra               46  16  6  1  36:15    3  5 15  11:45    47:60  -13   68
11. Darlington                    46  13  5  5  37:25    5  8 10  22:39    59:64   -5   67
12. Southend United               46  11  9  3  35:19    4 10  9  17:26    52:45   +7   64
13. AFC Bournemouth               46  13  8  2  39:13    2 10 11  15:31    54:44  +10   63
14. Brentford                     46  14  3  6  48:27    4  4 15  29:49    77:76   +1   61
15. Torquay United                46  12  5  6  33:22    5  4 14  26:45    59:67   -8   60
16. Aldershot                     46  10  8  5  29:19    6  3 14  20:40    49:59  -10   59
17. Stockport County              46  10 10  3  29:19    3  9 11  24:38    53:57   -4   58
18. Newport County                46  11  6  6  33:21    3  4 16   9:37    42:58  -16   52
19. Rochdale                      46   8  7  8  32:25    5  5 13  18:34    50:59   -9   51
20. Scunthorpe United             46  11  6  6  32:24    2  5 16  17:49    49:73  -24   50
21. Halifax Town                  46  11  6  6  36:18    0  8 15  11:40    47:58  -11   47
22. Hartlepool United             46   8  9  6  30:20    2  3 18  17:53    47:73  -26   42
23. Southport                     46   3 12  8  17:28    0  7 16  16:49    33:77  -44   28
24. Workington                    46   3  7 13  23:42    1  4 18  18:60    41:102 -61   23
~~~

(Source: `4-division4.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

