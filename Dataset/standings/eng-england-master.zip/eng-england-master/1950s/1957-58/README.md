

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Wolverhampton Wanderers       42  17  3  1  60:21   11  5  5  43:26   103:47  +56   92
 2. Preston North End             42  18  2  1  63:14    8  5  8  37:37   100:51  +49   85
 3. Tottenham Hotspur             42  13  4  4  58:33    8  5  8  35:44    93:77  +16   72
 4. Manchester City               42  14  4  3  58:33    8  1 12  46:67   104:100  +4   71
 5. West Bromwich Albion          42  14  4  3  59:29    4 10  7  33:41    92:70  +22   68
 6. Burnley                       42  16  2  3  52:21    5  3 13  28:53    80:74   +6   68
 7. Blackpool                     42  11  2  8  47:35    8  4  9  33:32    80:67  +13   63
 8. Luton Town                    42  13  3  5  45:22    6  3 12  24:41    69:63   +6   63
 9. Manchester United             42  10  4  7  45:31    6  7  8  40:44    85:75  +10   59
10. Nottingham Forest             42  10  4  7  41:27    6  6  9  28:36    69:63   +6   58
11. Chelsea                       42  10  5  6  47:34    5  7  9  36:45    83:79   +4   57
12. Arsenal                       42  10  4  7  48:39    6  3 12  25:46    73:85  -12   55
13. Aston Villa                   42  12  4  5  46:26    4  3 14  27:60    73:86  -13   55
14. Birmingham City               42   8  6  7  43:37    6  5 10  33:52    76:89  -13   53
15. Bolton Wanderers              42   9  5  7  38:35    5  5 11  27:52    65:87  -22   52
16. Leeds United                  42  10  6  5  33:23    4  3 14  18:40    51:63  -12   51
17. Everton                       42   5  9  7  34:35    8  2 11  31:40    65:75  -10   50
18. Leicester City                42  11  4  6  59:41    3  1 17  32:71    91:112 -21   47
19. Newcastle United              42   6  4 11  38:42    6  4 11  35:39    73:81   -8   44
20. Portsmouth                    42  10  6  5  45:34    2  2 17  28:54    73:88  -15   44
21. Sheffield Wednesday           42  12  2  7  45:40    0  5 16  24:52    69:92  -23   43
22. Sunderland                    42   7  7  7  32:33    3  5 13  22:64    54:97  -43   42
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. West Ham United               42  12  8  1  56:25   11  3  7  45:29   101:54  +47   80
 2. Charlton Athletic             42  15  3  3  65:33    9  4  8  42:36   107:69  +38   79
 3. Blackburn Rovers              42  13  7  1  50:18    9  5  7  43:39    93:57  +36   78
 4. Liverpool                     42  17  3  1  50:13    5  7  9  29:41    79:54  +25   76
 5. Sheffield United              42  12  5  4  38:22    9  5  7  37:28    75:50  +25   73
 6. Fulham                        42  13  5  3  53:24    7  7  7  44:35    97:59  +38   72
 7. Middlesbrough                 42  13  3  5  52:29    6  4 11  31:45    83:74   +9   64
 8. Stoke City                    42   9  4  8  49:36    9  2 10  26:37    75:73   +2   60
 9. Ipswich Town                  42  13  4  4  45:29    3  8 10  23:40    68:69   -1   60
10. Bristol Rovers                42  12  5  4  52:31    5  3 13  33:49    85:80   +5   59
11. Leyton Orient                 42  14  2  5  53:27    4  3 14  24:52    77:79   -2   59
12. Huddersfield Town             42   9  8  4  28:24    5  8  8  35:42    63:66   -3   58
13. Grimsby Town                  42  13  4  4  54:30    4  2 15  32:53    86:83   +3   57
14. Barnsley                      42  10  6  5  40:25    4  6 11  30:49    70:74   -4   54
15. Cardiff City                  42  10  5  6  44:31    4  4 13  19:46    63:77  -14   51
16. Derby County                  42  11  3  7  37:36    3  5 13  23:45    60:81  -21   50
17. Bristol City                  42   9  5  7  35:31    4  4 13  28:57    63:88  -25   48
18. Rotherham United              42   8  3 10  38:44    6  2 13  27:57    65:101 -36   47
19. Swansea City                  42   8  3 10  48:45    3  6 12  24:54    72:99  -27   42
20. Lincoln City                  42   6  6  9  33:35    5  3 13  22:47    55:82  -27   42
21. Notts County                  42   9  3  9  24:31    3  3 15  20:49    44:80  -36   42
22. Doncaster Rovers              42   7  5  9  34:40    1  6 14  22:48    56:88  -32   35
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Scunthorpe United             46  16  5  2  46:19   13  3  7  42:31    88:50  +38   95
 2. Accrington Stanley            46  16  4  3  53:28    9  5  9  30:33    83:61  +22   84
 3. Bury                          46  17  4  2  61:18    6  6 11  33:44    94:62  +32   79
 4. Bradford City                 46  13  7  3  42:19    8  8  7  31:30    73:49  +24   78
 5. Mansfield Town                46  16  3  4  68:42    6  5 12  32:50   100:92   +8   74
 6. Hull City                     46  15  6  2  49:20    4  9 10  29:47    78:67  +11   72
 7. Halifax Town                  46  15  5  3  52:20    5  6 12  31:49    83:69  +14   71
 8. Chesterfield                  46  12  8  3  39:28    6  7 10  32:41    71:69   +2   69
 9. Rochdale                      46  14  4  5  50:25    5  4 14  29:42    79:67  +12   65
10. Stockport County              46  15  4  4  54:28    3  7 13  20:39    74:67   +7   65
11. Tranmere Rovers               46  12  6  5  51:32    6  4 13  31:44    82:76   +6   64
12. Carlisle United               46  13  3  7  56:35    6  3 14  24:43    80:78   +2   63
13. Wrexham                       46  13  8  2  39:18    4  4 15  22:45    61:63   -2   63
14. York City                     46  11  8  4  40:26    6  4 13  28:50    68:76   -8   63
15. Hartlepool United             46  11  6  6  45:26    5  6 12  28:50    73:76   -3   60
16. Gateshead                     46  12  5  6  41:27    3 10 10  27:49    68:76   -8   60
17. Oldham Athletic               46  11  7  5  44:32    3 10 10  28:52    72:84  -12   59
18. Darlington                    46  15  3  5  53:25    2  4 17  25:64    78:89  -11   58
19. Workington                    46  11  6  6  46:33    3  7 13  26:48    72:81   -9   55
20. Barrow                        46   9  7  7  36:32    4  8 11  30:42    66:74   -8   54
21. Chester                       46   7 10  6  38:26    6  3 14  35:55    73:81   -8   52
22. Bradford Park Avenue          46   8  6  9  41:41    5  5 13  27:54    68:95  -27   50
23. Southport                     46   8  3 12  29:40    3  3 17  23:48    52:88  -36   39
24. Crewe Alexandra               46   6  5 12  29:41    2  2 19  18:52    47:93  -46   31
~~~

(Source: `3a-division3n.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Brighton & Hove Albion        46  13  6  4  52:30   11  6  6  36:34    88:64  +24   84
 2. Plymouth Argyle               46  17  4  2  43:17    8  4 11  24:31    67:48  +19   83
 3. Brentford                     46  15  5  3  52:24    9  5  9  30:32    82:56  +26   82
 4. Swindon Town                  46  14  7  2  47:16    7  8  8  32:34    79:50  +29   78
 5. Southampton                   46  16  3  4  78:31    6  7 10  34:41   112:72  +40   76
 6. Reading                       46  14  5  4  52:23    7  8  8  27:28    79:51  +28   76
 7. Southend United               46  14  5  4  56:26    7  7  9  34:32    90:58  +32   75
 8. AFC Bournemouth               46  16  5  2  54:24    5  4 14  27:50    81:74   +7   72
 9. Norwich City                  46  11  9  3  41:28    8  6  9  34:42    75:70   +5   72
10. Queens Park Rangers           46  15  6  2  40:14    3  8 12  24:51    64:65   -1   68
11. Newport County                46  12  6  5  40:24    5  8 10  33:43    73:67   +6   65
12. Colchester United             46  13  5  5  45:27    4  8 11  32:52    77:79   -2   64
13. Northampton Town              46  13  1  9  60:33    6  5 12  27:46    87:79   +8   63
14. Port Vale                     46  12  6  5  49:24    4  4 15  18:34    67:58   +9   58
15. Crystal Palace                46  12  5  6  46:30    3  8 12  24:42    70:72   -2   58
16. Watford                       46   9  8  6  34:27    4  8 11  25:50    59:77  -18   55
17. Shrewsbury Town               46  10  6  7  29:25    5  4 14  20:46    49:71  -22   55
18. Coventry City                 46  10  9  4  41:24    3  4 16  20:57    61:81  -20   52
19. Aldershot                     46   7  9  7  31:34    5  7 11  28:55    59:89  -30   52
20. Walsall                       46  10  7  6  37:24    4  2 17  24:51    61:75  -14   51
21. Gillingham                    46  12  5  6  33:24    1  4 18  19:57    52:81  -29   48
22. Torquay United                46   9  7  7  33:34    2  6 15  16:40    49:74  -25   46
23. Millwall                      46   6  6 11  37:36    5  3 15  26:55    63:91  -28   42
24. Exeter City                   46  10  4  9  37:35    1  5 17  20:64    57:99  -42   42
~~~

(Source: `3b-division3s.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

