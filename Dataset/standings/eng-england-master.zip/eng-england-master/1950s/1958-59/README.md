

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Wolverhampton Wanderers       42  15  3  3  68:19   13  2  6  42:30   110:49  +61   89
 2. Manchester United             42  14  4  3  58:27   10  3  8  45:39   103:66  +37   79
 3. Arsenal                       42  14  3  4  53:29    7  5  9  35:39    88:68  +20   71
 4. Bolton Wanderers              42  14  3  4  56:30    6  7  8  23:36    79:66  +13   70
 5. West Ham United               42  15  3  3  59:29    6  3 12  26:41    85:70  +15   69
 6. West Bromwich Albion          42   8  7  6  41:33   10  6  5  47:35    88:68  +20   67
 7. Burnley                       42  11  4  6  41:29    8  6  7  40:41    81:70  +11   67
 8. Birmingham City               42  14  1  6  54:35    6  5 10  30:33    84:68  +16   66
 9. Blackpool                     42  12  7  2  39:13    6  4 11  27:36    66:49  +17   65
10. Blackburn Rovers              42  12  3  6  48:28    5  7  9  28:42    76:70   +6   61
11. Newcastle United              42  11  3  7  40:29    6  4 11  40:51    80:80        58
12. Preston North End             42   9  3  9  40:39    8  4  9  30:38    70:77   -7   58
13. Chelsea                       42  13  2  6  52:37    5  2 14  25:61    77:98  -21   58
14. Nottingham Forest             42   9  4  8  37:32    8  2 11  34:42    71:74   -3   57
15. Everton                       42  11  3  7  39:38    6  1 14  32:49    71:87  -16   55
16. Leeds United                  42   8  7  6  28:27    7  2 12  29:47    57:74  -17   54
17. Luton Town                    42  11  6  4  50:26    1  7 13  18:45    68:71   -3   49
18. Tottenham Hotspur             42  10  3  8  56:42    3  7 11  29:53    85:95  -10   49
19. Leicester City                42   7  6  8  34:36    4  4 13  33:62    67:98  -31   43
20. Manchester City               42   8  7  6  40:32    3  2 16  24:63    64:95  -31   42
21. Aston Villa                   42   8  5  8  31:33    3  3 15  27:54    58:87  -29   41
22. Portsmouth                    42   5  4 12  38:47    1  5 15  26:65    64:112 -48   27
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Sheffield Wednesday           42  18  2  1  68:13   10  4  7  38:35   106:48  +58   90
 2. Fulham                        42  18  1  2  65:26    9  5  7  31:35    96:61  +35   87
 3. Liverpool                     42  15  3  3  57:25    9  2 10  30:37    87:62  +25   77
 4. Sheffield United              42  16  2  3  54:15    7  5  9  28:33    82:48  +34   76
 5. Stoke City                    42  16  2  3  48:19    5  5 11  24:39    72:58  +14   70
 6. Derby County                  42  15  1  5  46:29    5  7  9  28:42    74:71   +3   68
 7. Bristol Rovers                42  13  5  3  46:23    5  7  9  34:41    80:64  +16   66
 8. Charlton Athletic             42  13  3  5  53:33    5  4 12  39:57    92:90   +2   61
 9. Cardiff City                  42  12  2  7  37:26    6  5 10  28:39    65:65        61
10. Bristol City                  42  11  3  7  43:27    6  4 11  31:43    74:70   +4   58
11. Swansea City                  42  12  5  4  52:30    4  4 13  27:51    79:81   -2   57
12. Ipswich Town                  42  12  4  5  37:27    5  2 14  25:50    62:77  -15   57
13. Huddersfield Town             42  12  3  6  39:20    4  5 12  23:35    62:55   +7   56
14. Sunderland                    42  13  4  4  42:23    3  4 14  22:52    64:75  -11   56
15. Brighton & Hove Albion        42  10  9  2  46:28    5  2 14  28:61    74:89  -15   56
16. Middlesbrough                 42   9  7  5  51:26    6  3 12  36:45    87:71  +16   55
17. Leyton Orient                 42   9  4  8  43:30    5  4 12  28:48    71:78   -7   50
18. Scunthorpe United             42   7  6  8  32:37    5  3 13  22:47    54:84  -30   45
19. Lincoln City                  42  10  5  6  45:37    1  2 18  18:56    63:93  -30   40
20. Rotherham United              42   9  5  7  32:28    1  4 16  10:54    42:82  -40   39
21. Grimsby Town                  42   7  7  7  41:36    2  3 16  21:54    62:90  -28   37
22. Barnsley                      42   8  4  9  34:34    2  3 16  21:57    55:91  -36   37
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Hull City                     46  19  3  1  65:21    7  6 10  25:34    90:55  +35   87
 2. Plymouth Argyle               46  14  7  2  55:27    9  9  5  34:32    89:59  +30   85
 3. Norwich City                  46  13  6  4  51:29    9  7  7  38:33    89:62  +27   79
 4. Brentford                     46  15  5  3  49:22    6 10  7  27:27    76:49  +27   78
 5. Colchester United             46  15  2  6  46:31    6  8  9  25:36    71:67   +4   73
 6. Tranmere Rovers               46  15  3  5  53:22    6  5 12  29:45    82:67  +15   71
 7. Reading                       46  16  4  3  51:21    5  4 14  27:42    78:63  +15   71
 8. Southend United               46  14  6  3  52:26    7  2 14  33:54    85:80   +5   71
 9. Halifax Town                  46  14  5  4  48:25    7  3 13  32:52    80:77   +3   71
10. Bury                          46  12  9  2  51:24    5  5 13  18:34    69:58  +11   65
11. Bradford City                 46  13  4  6  47:25    5  7 11  37:51    84:76   +8   65
12. Queens Park Rangers           46  14  6  3  49:28    5  2 16  25:49    74:77   -3   65
13. AFC Bournemouth               46  12  9  2  40:18    5  3 15  29:51    69:69        63
14. Southampton                   46  12  7  4  57:33    5  4 14  31:47    88:80   +8   62
15. Chesterfield                  46  12  5  6  40:26    5  5 13  27:38    67:64   +3   61
16. Swindon Town                  46  13  4  6  39:25    3  9 11  20:32    59:57   +2   61
17. Newport County                46  15  2  6  43:24    2  7 14  26:44    69:68   +1   60
18. Accrington Stanley            46  10  8  5  42:31    5  4 14  29:56    71:87  -16   57
19. Wrexham                       46  12  6  5  40:30    2  8 13  23:47    63:77  -14   56
20. Mansfield Town                46  11  5  7  38:42    3  8 12  35:56    73:98  -25   55
21. Stockport County              46   9  7  7  33:23    4  3 16  32:55    65:78  -13   49
22. Doncaster Rovers              46  13  2  8  40:32    1  3 19  10:58    50:90  -40   47
23. Notts County                  46   5  9  9  33:39    3  4 16  22:57    55:96  -41   37
24. Rochdale                      46   8  7  8  21:26    0  5 18  16:53    37:79  -42   36
~~~

(Source: `3-division3.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Port Vale                     46  14  6  3  62:30   12  6  5  48:28   110:58  +52   90
 2. Coventry City                 46  18  4  1  50:11    6  8  9  34:36    84:47  +37   84
 3. Shrewsbury Town               46  15  5  3  59:24    9  5  9  42:39   101:63  +38   82
 4. York City                     46  12 10  1  37:17    9  8  6  36:35    73:52  +21   81
 5. Exeter City                   46  16  4  3  55:24    7  7  9  32:37    87:61  +26   80
 6. Walsall                       46  13  5  5  56:25    8  5 10  39:39    95:64  +31   73
 7. Crystal Palace                46  12  8  3  54:27    8  4 11  36:44    90:71  +19   72
 8. Northampton Town              46  14  5  4  48:25    7  4 12  37:53    85:78   +7   72
 9. Millwall                      46  13  6  4  46:23    7  4 12  30:46    76:69   +7   70
10. Gillingham                    46  14  6  3  53:27    6  3 14  29:50    82:77   +5   69
11. Carlisle United               46  11  6  6  37:30    8  6  9  25:35    62:65   -3   69
12. Bradford Park Avenue          46  15  1  7  51:29    3  6 14  24:48    75:77   -2   61
13. Torquay United                46  11  5  7  45:32    5  7 11  33:45    78:77   +1   60
14. Chester                       46  10  5  8  39:33    6  7 10  33:51    72:84  -12   60
15. Watford                       46  10  6  7  46:36    6  4 13  35:43    81:79   +2   58
16. Gateshead                     46  11  3  9  33:30    5  5 13  23:55    56:85  -29   56
17. Darlington                    46   7  8  8  37:36    6  8  9  29:32    66:68   -2   55
18. Crewe Alexandra               46  11  5  7  52:32    4  5 14  18:50    70:82  -12   55
19. Hartlepool United             46  11  4  8  50:41    4  6 13  24:47    74:88  -14   55
20. Workington                    46   9 10  4  40:32    3  7 13  23:46    63:78  -15   53
21. Oldham Athletic               46  15  0  8  39:29    1  4 18  20:55    59:84  -25   52
22. Aldershot                     46   8  4 11  37:45    6  3 14  26:52    63:97  -34   49
23. Barrow                        46   6  6 11  34:45    3  4 16  17:59    51:104 -53   37
24. Southport                     46   7  8  8  26:25    0  4 19  15:61    41:86  -45   33
~~~

(Source: `4-division4.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

