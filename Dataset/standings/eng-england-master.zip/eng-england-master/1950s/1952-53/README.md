

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Arsenal                       42  15  3  3  60:30    6  9  6  37:34    97:64  +33   75
 2. Preston North End             42  15  3  3  46:25    6  9  6  39:35    85:60  +25   75
 3. West Bromwich Albion          42  13  3  5  35:19    8  5  8  31:41    66:60   +6   71
 4. Wolverhampton Wanderers       42  13  5  3  54:27    6  8  7  32:36    86:63  +23   70
 5. Charlton Athletic             42  12  8  1  47:22    7  3 11  30:41    77:63  +14   68
 6. Burnley                       42  11  6  4  36:20    7  6  8  31:32    67:52  +15   66
 7. Blackpool                     42  13  5  3  45:22    6  4 11  26:48    71:70   +1   66
 8. Manchester United             42  11  5  5  35:30    7  5  9  34:42    69:72   -3   64
 9. Sunderland                    42  11  9  1  42:27    4  4 13  26:55    68:82  -14   58
10. Tottenham Hotspur             42  11  6  4  55:37    4  5 12  23:32    78:69   +9   56
11. Aston Villa                   42   9  7  5  36:23    5  6 10  27:38    63:61   +2   55
12. Cardiff City                  42   7  8  6  32:17    7  4 10  22:29    54:46   +8   54
13. Bolton Wanderers              42   9  4  8  39:35    6  5 10  22:34    61:69   -8   54
14. Middlesbrough                 42  12  5  4  46:27    2  6 13  24:50    70:77   -7   53
15. Portsmouth                    42  10  6  5  44:34    4  4 13  30:49    74:83   -9   52
16. Newcastle United              42   9  5  7  34:33    5  4 12  25:37    59:70  -11   51
17. Liverpool                     42  10  6  5  36:28    4  2 15  25:54    61:82  -21   50
18. Manchester City               42  12  2  7  45:28    2  5 14  27:59    72:87  -15   49
19. Sheffield Wednesday           42   8  6  7  35:32    4  5 12  27:40    62:72  -10   47
20. Chelsea                       42  10  4  7  35:24    2  7 12  21:42    56:66  -10   47
21. Stoke City                    42  10  4  7  35:26    2  6 13  18:40    53:66  -13   46
22. Derby County                  42   9  6  6  41:29    2  4 15  18:45    59:74  -15   43
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Sheffield United              42  15  3  3  60:27   10  7  4  37:28    97:55  +42   85
 2. Huddersfield Town             42  14  4  3  51:14   10  6  5  33:19    84:33  +51   82
 3. Luton Town                    42  15  1  5  53:17    7  7  7  31:32    84:49  +35   74
 4. Plymouth Argyle               42  12  5  4  37:24    8  4  9  28:36    65:60   +5   69
 5. Birmingham City               42  11  3  7  44:38    8  7  6  27:28    71:66   +5   67
 6. Leicester City                42  13  6  2  55:29    5  6 10  34:45    89:74  +15   66
 7. Nottingham Forest             42  11  5  5  46:32    7  3 11  31:35    77:67  +10   62
 8. Blackburn Rovers              42  12  4  5  40:20    6  4 11  28:45    68:65   +3   62
 9. Fulham                        42  14  1  6  52:28    3  9  9  29:43    81:71  +10   61
10. Leeds United                  42  13  4  4  42:24    1 11  9  29:39    71:63   +8   57
11. Rotherham United              42   9  7  5  41:30    7  2 12  34:44    75:74   +1   57
12. Swansea City                  42  10  9  2  45:26    5  3 13  33:55    78:81   -3   57
13. West Ham United               42   9  5  7  38:28    4  8  9  20:32    58:60   -2   52
14. Doncaster Rovers              42   9  9  3  26:17    3  7 11  32:47    58:64   -6   52
15. Everton                       42   9  8  4  38:23    3  6 12  33:52    71:75   -4   50
16. Lincoln City                  42   9  9  3  41:26    2  8 11  23:45    64:71   -7   50
17. Hull City                     42  11  6  4  36:19    3  2 16  21:50    57:69  -12   50
18. Brentford                     42   8  8  5  38:29    5  3 13  21:47    59:76  -17   50
19. Notts County                  42  11  5  5  41:31    3  3 15  19:57    60:88  -28   50
20. Bury                          42  10  6  5  33:30    3  3 15  20:51    53:81  -28   48
21. Southampton                   42   5  7  9  45:44    5  6 10  23:41    68:85  -17   43
22. Barnsley                      42   4  4 13  31:46    1  4 16  16:62    47:108 -61   23
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Oldham Athletic               46  15  4  4  48:21    7 11  5  29:24    77:45  +32   81
 2. Wrexham                       46  18  3  2  59:24    6  5 12  27:42    86:66  +20   80
 3. Port Vale                     46  13  9  1  41:10    7  9  7  26:25    67:35  +32   78
 4. Grimsby Town                  46  15  5  3  47:19    6  5 12  28:40    75:59  +16   73
 5. York City                     46  14  5  4  35:16    6  8  9  26:30    61:46  +15   73
 6. Southport                     46  16  4  3  43:19    4  7 12  21:42    64:61   +3   71
 7. Bradford Park Avenue          46  10  8  5  37:23    9  4 10  38:38    75:61  +14   69
 8. Crewe Alexandra               46  13  5  5  46:28    7  3 13  24:40    70:68   +2   68
 9. Tranmere Rovers               46  16  4  3  45:16    5  1 17  20:47    65:63   +2   68
10. Carlisle United               46  13  7  3  57:24    5  6 12  25:44    82:68  +14   67
11. Gateshead                     46  13  6  4  51:24    4  9 10  25:36    76:60  +16   66
12. Chesterfield                  46  13  6  4  40:23    5  5 13  25:40    65:63   +2   65
13. Stockport County              46  13  8  2  61:26    4  5 14  21:43    82:69  +13   64
14. Halifax Town                  46  13  5  5  47:31    3 10 10  21:37    68:68        63
15. Scunthorpe United             46  10  6  7  38:21    6  8  9  24:35    62:56   +6   62
16. Hartlepool United             46  14  6  3  39:16    2  8 13  18:45    57:61   -4   62
17. Mansfield Town                46  11  9  3  34:25    5  5 13  21:37    55:62   -7   62
18. Bradford City                 46  14  7  2  54:29    0 11 12  21:51    75:80   -5   60
19. Barrow                        46  15  6  2  48:20    1  6 16  18:51    66:71   -5   60
20. Chester                       46  10  7  6  39:27    1  8 14  25:58    64:85  -21   48
21. Darlington                    46  13  4  6  33:27    1  2 20  25:69    58:96  -38   48
22. Rochdale                      46  12  5  6  41:27    2  0 21  21:56    62:83  -21   47
23. Workington                    46   9  5  9  40:33    2  5 16  15:58    55:91  -36   43
24. Accrington Stanley            46   7  9  7  25:29    1  2 20  14:60    39:89  -50   35
~~~

(Source: `3a-division3n.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Bristol Rovers                46  17  4  2  55:19    9  8  6  37:27    92:46  +46   90
 2. Northampton Town              46  18  4  1  75:30    8  6  9  34:40   109:70  +39   88
 3. Millwall                      46  14  7  2  46:16   10  7  6  36:28    82:44  +38   86
 4. Norwich City                  46  16  6  1  56:17    9  4 10  43:38    99:55  +44   85
 5. Bristol City                  46  13  8  2  62:28    9  7  7  33:33    95:61  +34   81
 6. Coventry City                 46  15  5  3  52:22    4  7 12  25:40    77:62  +15   69
 7. Brighton & Hove Albion        46  12  6  5  48:30    7  6 10  33:45    81:75   +6   69
 8. Southend United               46  15  5  3  41:21    3  8 12  28:53    69:74   -5   67
 9. AFC Bournemouth               46  15  3  5  49:23    4  6 13  25:46    74:69   +5   66
10. Reading                       46  17  3  3  53:18    2  5 16  16:46    69:64   +5   65
11. Torquay United                46  15  4  4  61:28    3  5 15  26:60    87:88   -1   63
12. Watford                       46  12  8  3  39:21    3  9 11  23:42    62:63   -1   62
13. Leyton Orient                 46  12  7  4  52:28    4  3 16  16:45    68:73   -5   58
14. Newport County                46  12  4  7  43:34    4  6 13  27:48    70:82  -12   58
15. Crystal Palace                46  12  7  4  40:26    3  6 14  26:56    66:82  -16   58
16. Ipswich Town                  46  10  7  6  34:28    3  8 12  26:41    60:69   -9   54
17. Swindon Town                  46   9  5  9  38:33    5  7 11  26:46    64:79  -15   54
18. Exeter City                   46  11  8  4  40:24    2  6 15  21:47    61:71  -10   53
19. Aldershot                     46   8  8  7  36:29    4  7 12  25:48    61:77  -16   51
20. Gillingham                    46  10  7  6  30:26    2  8 13  25:48    55:74  -19   51
21. Queens Park Rangers           46   9  9  5  37:34    3  6 14  24:48    61:82  -21   51
22. Colchester United             46   9  9  5  40:29    3  5 15  19:47    59:76  -17   50
23. Shrewsbury Town               46  11  5  7  38:35    1  7 15  30:56    68:91  -23   48
24. Walsall                       46   5  9  9  35:46    2  1 20  21:72    56:118 -62   31
~~~

(Source: `3b-division3s.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

