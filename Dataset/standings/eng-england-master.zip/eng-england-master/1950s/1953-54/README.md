

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Wolverhampton Wanderers       42  16  1  4  61:25    9  6  6  35:31    96:56  +40   82
 2. West Bromwich Albion          42  13  5  3  51:24    9  4  8  35:39    86:63  +23   75
 3. Huddersfield Town             42  13  6  2  45:24    7  5  9  33:37    78:61  +17   71
 4. Blackpool                     42  13  6  2  43:19    6  4 11  37:50    80:69  +11   67
 5. Burnley                       42  16  2  3  51:23    5  2 14  27:44    78:67  +11   67
 6. Bolton Wanderers              42  14  6  1  45:20    4  6 11  30:40    75:60  +15   66
 7. Manchester United             42  11  6  4  41:27    7  6  8  32:31    73:58  +15   66
 8. Charlton Athletic             42  14  4  3  51:26    5  2 14  24:51    75:77   -2   63
 9. Preston North End             42  12  2  7  43:24    7  3 11  44:34    87:58  +29   62
10. Cardiff City                  42  12  4  5  32:27    6  4 11  19:44    51:71  -20   62
11. Chelsea                       42  12  3  6  45:26    4  9  8  29:42    74:68   +6   60
12. Arsenal                       42   8  8  5  42:37    7  5  9  33:36    75:73   +2   58
13. Aston Villa                   42  12  5  4  50:28    4  4 13  20:40    70:68   +2   57
14. Portsmouth                    42  13  5  3  53:31    1  6 14  28:58    81:89   -8   53
15. Tottenham Hotspur             42  11  3  7  38:33    5  2 14  27:43    65:76  -11   53
16. Newcastle United              42   9  2 10  43:40    5  8  8  29:37    72:77   -5   52
17. Manchester City               42  10  4  7  35:31    4  5 12  27:46    62:77  -15   51
18. Sheffield Wednesday           42  12  4  5  43:30    3  2 16  27:61    70:91  -21   51
19. Sunderland                    42  11  4  6  50:37    3  4 14  31:52    81:89   -8   50
20. Sheffield United              42   9  5  7  43:38    2  6 13  26:52    69:90  -21   44
21. Middlesbrough                 42   6  6  9  29:35    4  4 13  31:56    60:91  -31   40
22. Liverpool                     42   7  8  6  49:38    2  2 17  19:59    68:97  -29   37
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Leicester City                42  15  4  2  63:23    8  6  7  34:37    97:60  +37   79
 2. Blackburn Rovers              42  15  4  2  54:16    8  5  8  32:34    86:50  +36   78
 3. Everton                       42  13  6  2  55:27    7 10  4  37:31    92:58  +34   76
 4. Nottingham Forest             42  15  5  1  61:27    5  7  9  25:32    86:59  +27   72
 5. Rotherham United              42  13  4  4  51:26    8  3 10  29:41    80:67  +13   70
 6. Luton Town                    42  11  7  3  36:23    7  5  9  28:36    64:59   +5   66
 7. Birmingham City               42  12  6  3  49:18    6  5 10  29:40    78:58  +20   65
 8. Fulham                        42  12  3  6  62:39    5  7  9  36:46    98:85  +13   61
 9. Leeds United                  42  12  5  4  56:30    3  8 10  33:51    89:81   +8   58
10. Bristol Rovers                42  10  7  4  32:19    4  9  8  32:39    64:58   +6   58
11. Doncaster Rovers              42   9  5  7  32:28    7  4 10  27:35    59:63   -4   57
12. West Ham United               42  11  6  4  44:20    4  3 14  23:49    67:69   -2   54
13. Hull City                     42  14  1  6  47:22    2  5 14  17:44    64:66   -2   54
14. Stoke City                    42   8  8  5  43:28    4  9  8  28:32    71:60  +11   53
15. Notts County                  42   8  6  7  26:29    5  7  9  28:45    54:74  -20   52
16. Lincoln City                  42  11  6  4  46:23    3  3 15  19:60    65:83  -18   51
17. Derby County                  42   9  5  7  38:35    3  6 12  26:47    64:82  -18   47
18. Bury                          42   9  7  5  39:32    2  7 12  15:40    54:72  -18   47
19. Swansea City                  42  11  5  5  34:25    2  3 16  24:57    58:82  -24   47
20. Plymouth Argyle               42   6 12  3  38:31    3  4 14  27:51    65:82  -17   43
21. Brentford                     42   9  5  7  25:26    1  6 14  15:52    40:78  -38   41
22. Oldham Athletic               42   6  7  8  26:31    2  2 17  14:58    40:89  -49   33
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Port Vale                     46  16  7  0  48:5    10 10  3  26:16    74:21  +53   95
 2. Barnsley                      46  16  3  4  54:24    8  7  8  23:33    77:57  +20   82
 3. Scunthorpe United             46  14  7  2  49:24    7  8  8  28:32    77:56  +21   78
 4. Gateshead                     46  15  4  4  49:22    6  9  8  25:33    74:55  +19   76
 5. Bradford City                 46  15  6  2  40:14    7  3 13  20:41    60:55   +5   75
 6. Wrexham                       46  16  4  3  59:19    5  5 13  22:49    81:68  +13   72
 7. Mansfield Town                46  15  5  3  59:22    5  6 12  29:45    88:67  +21   71
 8. Chesterfield                  46  13  6  4  41:19    6  8  9  35:45    76:64  +12   71
 9. Bradford Park Avenue          46  13  6  4  57:31    5  8 10  20:37    77:68   +9   68
10. Stockport County              46  14  6  3  57:20    4  5 14  20:47    77:67  +10   65
11. Southport                     46  12  5  6  41:26    5  7 11  22:34    63:60   +3   63
12. Tranmere Rovers               46  11  4  8  40:34    7  3 13  19:36    59:70  -11   61
13. Barrow                        46  12  7  4  46:26    4  5 14  26:45    72:71   +1   60
14. Accrington Stanley            46  12  7  4  41:22    4  3 16  25:52    66:74   -8   58
15. Carlisle United               46  10  8  5  53:27    4  7 12  30:44    83:71  +12   57
16. Grimsby Town                  46  14  5  4  31:15    2  4 17  20:62    51:77  -26   57
17. Rochdale                      46  12  5  6  40:20    3  5 15  19:57    59:77  -18   55
18. Crewe Alexandra               46   9  8  6  30:26    5  5 13  19:41    49:67  -18   55
19. Hartlepool United             46  10  8  5  40:21    3  6 14  19:44    59:65   -6   53
20. Workington                    46  10  9  4  36:22    3  5 15  23:58    59:80  -21   53
21. Darlington                    46  11  3  9  31:27    1 11 11  19:44    50:71  -21   50
22. York City                     46   8  7  8  39:32    4  6 13  25:54    64:86  -22   49
23. Halifax Town                  46   9  6  8  26:21    3  4 16  18:52    44:73  -29   46
24. Chester                       46  10  7  6  39:22    1  3 19   9:45    48:67  -19   43
~~~

(Source: `3a-division3n.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Ipswich Town                  46  15  5  3  47:19   12  5  6  35:32    82:51  +31   91
 2. Brighton & Hove Albion        46  17  3  3  57:31    9  6  8  29:30    86:61  +25   87
 3. Bristol City                  46  18  3  2  59:18    7  3 13  29:48    88:66  +22   81
 4. Watford                       46  16  3  4  52:23    5  7 11  33:46    85:69  +16   73
 5. Southampton                   46  17  5  1  51:22    5  2 16  25:41    76:63  +13   73
 6. Northampton Town              46  18  4  1  63:18    2  7 14  19:37    82:55  +27   71
 7. Norwich City                  46  13  5  5  43:28    7  6 10  30:38    73:66   +7   71
 8. Reading                       46  14  3  6  57:33    6  6 11  29:40    86:73  +13   69
 9. Exeter City                   46  12  2  9  39:22    8  6  9  29:36    68:58  +10   68
10. Gillingham                    46  14  3  6  37:22    5  7 11  24:44    61:66   -5   67
11. Millwall                      46  15  3  5  44:24    4  6 13  30:53    74:77   -3   66
12. Leyton Orient                 46  14  5  4  48:26    4  6 13  31:47    79:73   +6   65
13. Coventry City                 46  14  5  4  36:15    4  4 15  25:41    61:56   +5   63
14. Torquay United                46  10 10  3  48:33    7  2 14  33:55    81:88   -7   63
15. Newport County                46  14  4  5  42:28    5  2 16  19:53    61:81  -20   63
16. Southend United               46  15  2  6  46:22    3  5 15  23:49    69:71   -2   61
17. Aldershot                     46  11  5  7  45:31    6  4 13  29:55    74:86  -12   60
18. Queens Park Rangers           46  10  5  8  32:25    6  5 12  28:43    60:68   -8   58
19. AFC Bournemouth               46  12  5  6  47:27    4  3 16  20:43    67:70   -3   56
20. Swindon Town                  46  13  5  5  48:21    2  5 16  19:49    67:70   -3   55
21. Shrewsbury Town               46  12  8  3  48:34    2  4 17  17:42    65:76  -11   54
22. Crystal Palace                46  11  7  5  41:30    3  5 15  19:56    60:86  -26   54
23. Colchester United             46   7  7  9  35:29    3  3 17  15:49    50:78  -28   40
24. Walsall                       46   8  5 10  22:27    1  3 19  18:60    40:87  -47   35
~~~

(Source: `3b-division3s.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

