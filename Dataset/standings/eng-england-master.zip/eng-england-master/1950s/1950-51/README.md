

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Tottenham Hotspur             42  17  2  2  54:21    8  8  5  28:23    82:44  +38   85
 2. Manchester United             42  14  4  3  42:16   10  4  7  32:24    74:40  +34   80
 3. Blackpool                     42  12  6  3  43:19    8  4  9  36:34    79:53  +26   70
 4. Newcastle United              42  10  6  5  36:22    8  7  6  26:31    62:53   +9   67
 5. Arsenal                       42  11  5  5  47:28    8  4  9  26:28    73:56  +17   66
 6. Middlesbrough                 42  12  7  2  51:25    6  4 11  25:40    76:65  +11   65
 7. Bolton Wanderers              42  11  2  8  31:20    8  5  8  33:41    64:61   +3   64
 8. Portsmouth                    42   8 10  3  39:30    8  5  8  32:38    71:68   +3   63
 9. Liverpool                     42  11  5  5  28:25    5  6 10  25:34    53:59   -6   59
10. Derby County                  42  10  5  6  53:33    6  3 12  28:42    81:75   +6   56
11. Burnley                       42   9  7  5  27:16    5  7  9  21:27    48:43   +5   56
12. Wolverhampton Wanderers       42   9  3  9  44:30    6  5 10  30:31    74:61  +13   53
13. Stoke City                    42  10  5  6  28:19    3  9  9  22:40    50:59   -9   53
14. Sunderland                    42   8  9  4  30:21    4  7 10  33:52    63:73  -10   52
15. Charlton Athletic             42   9  4  8  35:31    5  5 11  28:49    63:80  -17   51
16. Huddersfield Town             42   8  4  9  40:40    7  2 12  24:52    64:92  -28   51
17. West Bromwich Albion          42   7  4 10  30:27    6  7  8  23:34    53:61   -8   50
18. Fulham                        42   8  5  8  35:37    5  6 10  17:31    52:68  -16   50
19. Aston Villa                   42   9  6  6  39:29    3  7 11  27:39    66:68   -2   49
20. Chelsea                       42   9  4  8  31:25    3  4 14  22:40    53:65  -12   44
21. Sheffield Wednesday           42   9  6  6  43:32    3  2 16  21:51    64:83  -19   44
22. Everton                       42   7  5  9  26:35    5  3 13  22:51    48:86  -38   44
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Preston North End             42  16  3  2  53:18   10  2  9  38:31    91:49  +42   83
 2. Manchester City               42  12  6  3  53:25    7  8  6  36:36    89:61  +28   71
 3. Birmingham City               42  12  6  3  37:19    8  3 10  27:33    64:52  +12   69
 4. Leeds United                  42  14  4  3  36:17    6  4 11  27:38    63:55   +8   68
 5. Cardiff City                  42  13  7  1  36:20    4  9  8  17:25    53:45   +8   67
 6. Blackburn Rovers              42  13  3  5  39:27    6  5 10  26:39    65:66   -1   65
 7. Coventry City                 42  15  3  3  51:25    4  4 13  24:34    75:59  +16   64
 8. Brentford                     42  13  3  5  44:25    5  5 11  31:49    75:74   +1   62
 9. Sheffield United              42  11  4  6  44:27    5  8  8  28:35    72:62  +10   60
10. Hull City                     42  12  5  4  47:28    4  6 11  27:42    74:70   +4   59
11. West Ham United               42  10  5  6  44:33    6  5 10  24:36    68:69   -1   58
12. Doncaster Rovers              42   9  6  6  37:32    6  7  8  27:36    64:68   -4   58
13. Southampton                   42  10  9  2  38:27    5  4 12  27:46    65:73   -8   58
14. Leicester City                42  10  4  7  42:28    5  7  9  26:30    68:58  +10   56
15. Barnsley                      42   9  5  7  42:22    6  5 10  32:46    74:68   +6   55
16. Queens Park Rangers           42  13  5  3  47:25    2  5 14  24:57    71:82  -11   55
17. Notts County                  42   7  7  7  37:34    6  6  9  24:26    61:60   +1   52
18. Swansea City                  42  14  1  6  34:25    2  3 16  20:52    54:77  -23   52
19. Bury                          42   9  4  8  33:27    3  4 14  27:59    60:86  -26   44
20. Luton Town                    42   7  9  5  34:23    2  5 14  23:47    57:70  -13   41
21. Chesterfield                  42   7  7  7  30:28    2  5 14  14:41    44:69  -25   39
22. Grimsby Town                  42   6  8  7  37:38    2  4 15  24:57    61:95  -34   36
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Rotherham United              46  16  3  4  55:16   15  6  2  48:25   103:41  +62  102
 2. Mansfield Town                46  17  6  0  54:19    9  6  8  24:29    78:48  +30   90
 3. Carlisle United               46  18  4  1  44:17    7  8  8  35:33    79:50  +29   87
 4. Lincoln City                  46  18  1  4  62:23    7  7  9  27:35    89:58  +31   83
 5. Tranmere Rovers               46  15  5  3  51:26    9  6  8  32:36    83:62  +21   83
 6. Bradford Park Avenue          46  15  3  5  46:23    8  5 10  44:49    90:72  +18   77
 7. Bradford City                 46  13  4  6  55:30    8  6  9  35:33    90:63  +27   73
 8. Gateshead                     46  17  1  5  60:21    4  7 12  24:41    84:62  +22   71
 9. Stockport County              46  15  3  5  45:26    5  5 13  18:37    63:63        68
10. Crewe Alexandra               46  11  5  7  38:26    8  5 10  23:34    61:60   +1   67
11. Rochdale                      46  11  6  6  38:18    6  5 12  31:44    69:62   +7   62
12. Chester                       46  11  6  6  42:30    6  3 14  20:34    62:64   -2   60
13. Scunthorpe United             46  10 12  1  32:9     3  6 14  26:48    58:57   +1   57
14. Wrexham                       46  12  6  5  37:28    3  6 14  18:43    55:71  -16   57
15. Oldham Athletic               46  10  5  8  47:36    6  3 14  26:37    73:73        56
16. Hartlepool United             46  14  5  4  55:26    2  2 19   9:40    64:66   -2   55
17. Barrow                        46  12  3  8  38:27    4  3 16  13:49    51:76  -25   54
18. Darlington                    46  10  8  5  35:29    3  5 15  24:48    59:77  -18   52
19. Shrewsbury Town               46  11  3  9  28:30    4  4 15  15:44    43:74  -31   52
20. York City                     46   7 12  4  37:24    5  3 15  29:53    66:77  -11   51
21. Southport                     46   9  4 10  29:25    4  6 13  27:47    56:72  -16   49
22. Halifax Town                  46  11  6  6  36:24    0  6 17  14:45    50:69  -19   45
23. Accrington Stanley            46  10  4  9  28:29    1  6 16  14:72    42:101 -59   43
24. New Brighton                  46   7  6 10  22:32    4  2 17  18:58    40:90  -50   41
~~~

(Source: `3a-division3n.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Nottingham Forest             46  16  6  1  57:17   14  4  5  53:23   110:40  +70  100
 2. Norwich City                  46  16  6  1  42:14    9  8  6  40:31    82:45  +37   89
 3. Plymouth Argyle               46  16  5  2  54:19    8  4 11  30:36    84:55  +29   81
 4. Millwall                      46  15  6  2  52:23    8  4 11  28:34    80:57  +23   79
 5. Reading                       46  15  6  2  57:17    6  9  8  31:36    88:53  +35   78
 6. Bristol Rovers                46  15  7  1  46:18    5  8 10  18:24    64:42  +22   75
 7. Ipswich Town                  46  15  4  4  48:24    8  2 13  21:34    69:58  +11   75
 8. Southend United               46  15  4  4  64:27    6  6 11  28:42    92:69  +23   73
 9. AFC Bournemouth               46  17  5  1  49:16    5  2 16  16:41    65:57   +8   73
10. Bristol City                  46  15  4  4  41:25    5  7 11  23:34    64:59   +5   71
11. Newport County                46  13  4  6  48:25    6  5 12  29:45    77:70   +7   66
12. Port Vale                     46  13  6  4  35:23    3  7 13  25:41    60:64   -4   61
13. Exeter City                   46  11  4  8  33:30    7  2 14  29:55    62:85  -23   60
14. Swindon Town                  46  15  4  4  38:17    3  0 20  17:50    55:67  -12   58
15. Brighton & Hove Albion        46  11  8  4  51:31    2  9 12  20:48    71:79   -8   56
16. Walsall                       46  12  4  7  32:20    3  6 14  20:42    52:62  -10   55
17. Aldershot                     46  11  8  4  37:20    4  2 17  19:68    56:88  -32   55
18. Colchester United             46  12  5  6  43:25    2  7 14  20:51    63:76  -13   54
19. Leyton Orient                 46  13  2  8  36:28    2  6 15  17:47    53:75  -22   53
20. Torquay United                46  13  2  8  47:39    1  7 15  17:42    64:81  -17   51
21. Gillingham                    46  10  7  6  41:30    3  2 18  28:71    69:101 -32   48
22. Northampton Town              46   8  9  6  39:30    2  7 14  16:37    55:67  -12   46
23. Watford                       46   8  5 10  29:28    1  6 16  25:60    54:88  -34   38
24. Crystal Palace                46   6  5 12  18:39    2  6 15  15:45    33:84  -51   35
~~~

(Source: `3b-division3s.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

