

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Sunderland                    30  13  2  0  58:17    9  2  4  42:19   100:36  +64   70
 2. Preston North End             30  11  2  2  34:10    6  1  8  23:29    57:39  +18   54
 3. Everton                       30   9  3  3  44:17    7  1  7  30:34    74:51  +23   52
 4. Aston Villa                   30  12  1  2  50:24    4  2  9  23:38    73:62  +11   51
 5. Bolton Wanderers              30  12  1  2  43:21    1  5  9  13:34    56:55   +1   45
 6. Burnley                       30  10  2  3  37:15    3  2 10  14:29    51:44   +7   43
 7. Stoke City                    30   8  2  5  33:16    4  3  8  25:32    58:48  +10   41
 8. West Bromwich Albion          30   9  2  4  35:17    3  3  9  23:52    58:69  -11   41
 9. Wolverhampton Wanderers       30  11  2  2  32:17    1  2 12  15:51    47:68  -21   40
10. Sheffield Wednesday           30   8  2  5  34:28    4  1 10  21:37    55:65  -10   39
11. Nottingham Forest             30   7  2  6  30:27    3  6  6  18:25    48:52   -4   38
12. Blackburn Rovers              30   5  8  2  29:24    3  5  7  18:32    47:56   -9   37
13. Derby County                  30   5  6  4  30:28    4  3  8  22:36    52:64  -12   36
14. Notts County                  30   8  3  4  34:15    2  1 12  19:46    53:61   -8   34
15. Accrington F.C.               30   5  5  5  29:34    1  6  8  28:47    57:81  -24   29
16. Manchester United             30   6  3  6  39:35    0  3 12  11:50    50:85  -35   24
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Birmingham City               22  10  1  0  60:16    7  1  3  33:19    93:35  +58   53
 2. Sheffield United              22  10  1  0  35:8     6  2  3  27:11    62:19  +43   51
 3. Darwen                        22  10  0  1  43:15    4  2  5  17:24    60:39  +21   44
 4. Grimsby Town                  22   8  1  2  25:7     3  0  8  17:34    42:41   +1   34
 5. Manchester City               22   6  3  2  27:14    3  0  8  18:26    45:40   +5   30
 6. Burton Swifts                 22   7  1  3  30:18    2  1  8  17:29    47:47        29
 7. Northwich Victoria            22   7  0  4  25:26    2  2  7  17:32    42:58  -16   29
 8. Bootle                        22   8  1  2  35:20    0  2  9  14:43    49:63  -14   27
 9. Lincoln City                  22   6  2  3  30:18    1  1  9  15:33    45:51   -6   24
10. Crewe Alexandra               22   6  1  4  30:24    0  2  9  12:45    42:69  -27   21
11. Port Vale                     22   4  1  6  16:23    2  2  7  14:34    30:57  -27   21
12. Walsall                       22   4  3  4  25:24    1  0 10  12:51    37:75  -38   18
~~~

(Source: `2-division2.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

