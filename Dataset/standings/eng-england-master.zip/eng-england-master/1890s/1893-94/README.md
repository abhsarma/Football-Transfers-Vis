

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Aston Villa                   30  12  2  1  49:13    7  4  4  35:29    84:42  +42   63
 2. Sunderland                    30  11  3  1  46:14    6  1  8  26:30    72:44  +28   55
 3. Derby County                  30   9  2  4  47:32    7  2  6  26:30    73:62  +11   52
 4. Blackburn Rovers              30  13  0  2  48:15    3  2 10  21:38    69:53  +16   50
 5. Burnley                       30  13  0  2  43:17    2  4  9  18:34    61:51  +10   49
 6. Everton                       30  11  1  3  63:23    4  2  9  27:34    90:57  +33   48
 7. Nottingham Forest             30  10  2  3  38:16    4  2  9  19:32    57:48   +9   46
 8. West Bromwich Albion          30   8  4  3  35:23    6  0  9  31:36    66:59   +7   46
 9. Wolverhampton Wanderers       30  11  1  3  34:24    3  2 10  18:39    52:63  -11   45
10. Sheffield United              30   8  3  4  26:22    5  2  8  21:39    47:61  -14   44
11. Stoke City                    30  13  1  1  45:17    0  2 13  20:62    65:79  -14   42
12. Sheffield Wednesday           30   7  3  5  32:21    2  5  8  16:36    48:57   -9   35
13. Bolton Wanderers              30   7  3  5  18:14    3  1 11  20:38    38:52  -14   34
14. Preston North End             30   7  1  7  25:24    3  2 10  19:32    44:56  -12   33
15. Darwen                        30   6  4  5  25:28    1  1 13  12:55    37:83  -46   26
16. Manchester United             30   5  2  8  29:33    1  0 14   7:39    36:72  -36   20
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Liverpool                     28  14  0  0  46:6     8  6  0  31:12    77:18  +59   72
 2. Birmingham City               28  12  0  2  68:19    9  0  5  35:25   103:44  +59   63
 3. Notts County                  28  12  1  1  55:14    6  2  6  15:17    70:31  +39   57
 4. Newcastle United              28  12  1  1  44:10    3  5  6  22:29    66:39  +27   51
 5. Grimsby Town                  28  11  1  2  47:16    4  1  9  24:42    71:58  +13   47
 6. Burton Swifts                 28   9  1  4  52:26    5  2  7  27:35    79:61  +18   45
 7. Port Vale                     28  10  2  2  43:20    3  2  9  23:44    66:64   +2   43
 8. Arsenal                       28   9  1  4  33:19    3  3  8  19:36    52:55   -3   40
 9. Lincoln City                  28   5  4  5  31:22    6  2  6  28:36    59:58   +1   39
10. Walsall                       28   8  1  5  36:23    2  2 10  15:38    51:61  -10   33
11. Middlesbrough Ironopolis      28   7  4  3  27:20    1  0 13  10:52    37:72  -35   28
12. Manchester City               28   6  1  7  32:20    2  1 11  15:51    47:71  -24   26
13. Crewe Alexandra               28   3  7  4  22:22    3  0 11  20:51    42:73  -31   25
14. Rotherham Town                28   5  1  8  28:42    1  2 11  16:49    44:91  -47   21
15. Northwich Victoria            28   3  3  8  17:34    0  0 14  13:64    30:98  -68   12
~~~

(Source: `2-division2.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

