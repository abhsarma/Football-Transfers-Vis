

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Aston Villa                   30  14  1  0  47:17    6  4  5  31:28    78:45  +33   65
 2. Derby County                  30  12  2  1  42:13    5  5  5  26:22    68:35  +33   58
 3. Everton                       30  10  4  1  40:17    6  3  6  26:26    66:43  +23   55
 4. Bolton Wanderers              30  12  2  1  34:14    4  3  8  15:23    49:37  +12   53
 5. Sunderland                    30  10  5  0  36:14    5  2  8  16:27    52:41  +11   52
 6. Stoke City                    30  12  0  3  43:11    3  0 12  13:36    56:47   +9   45
 7. Sheffield Wednesday           30  10  2  3  31:18    2  3 10  13:35    44:53   -9   41
 8. Blackburn Rovers              30  10  1  4  26:18    2  4  9  14:32    40:50  -10   41
 9. Bury                          30   7  1  7  32:24    5  2  8  18:30    50:54   -4   39
10. Preston North End             30   8  5  2  31:18    3  1 11  13:30    44:48   -4   39
11. Burnley                       30   8  5  2  33:11    2  2 11  15:33    48:44   +4   37
12. Sheffield United              30   9  4  2  28:12    1  2 12  12:38    40:50  -10   36
13. Nottingham Forest             30  11  1  3  34:16    0  2 13   8:41    42:57  -15   36
14. Wolverhampton Wanderers       30  10  0  5  43:18    0  1 14  18:47    61:65   -4   31
15. Birmingham City               30   7  2  6  22:24    1  2 12  17:55    39:79  -40   28
16. West Bromwich Albion          30   5  4  6  18:22    1  3 11  12:37    30:59  -29   25
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Liverpool                     30  14  1  0  65:11    8  1  6  41:21   106:32  +74   68
 2. Manchester City               30  12  3  0  37:9     9  1  5  26:29    63:38  +25   67
 3. Grimsby Town                  30  14  1  0  51:9     6  1  8  31:29    82:38  +44   62
 4. Burton Wanderers              30  12  1  2  43:15    7  3  5  26:25    69:40  +29   61
 5. Newcastle United              30  14  0  1  57:14    2  2 11  16:36    73:50  +23   50
 6. Manchester United             30  12  2  1  48:15    3  1 11  18:42    66:57   +9   48
 7. Arsenal                       30  11  1  3  43:11    3  3  9  16:31    59:42  +17   46
 8. Leicester City                30  10  0  5  40:16    4  4  7  17:28    57:44  +13   46
 9. Darwen                        30   9  4  2  55:22    3  2 10  17:45    72:67   +5   42
10. Notts County                  30   8  1  6  41:22    4  1 10  16:32    57:54   +3   38
11. Burton Swifts                 30   7  2  6  24:26    3  2 10  15:43    39:69  -30   34
12. Loughborough                  30   7  3  5  32:25    2  2 11   8:42    40:67  -27   32
13. Lincoln City                  30   7  1  7  36:24    2  3 10  17:51    53:75  -22   31
14. Port Vale                     30   6  4  5  25:24    1  0 14  18:54    43:78  -35   25
15. Rotherham Town                30   7  2  6  27:26    0  1 14   7:71    34:97  -63   24
16. Crewe Alexandra               30   5  2  8  22:28    0  1 14   8:67    30:95  -65   18
~~~

(Source: `2-division2.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

