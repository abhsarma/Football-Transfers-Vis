

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Everton                       22   9  0  2  39:12    5  1  5  24:17    63:29  +34   43
 2. Preston North End             22   7  3  1  30:5     5  0  6  14:18    44:23  +21   39
 3. Wolverhampton Wanderers       22   8  1  2  23:8     4  1  6  16:42    39:50  -11   38
 4. Notts County                  22   9  1  1  33:11    2  3  6  19:24    52:35  +17   37
 5. Bolton Wanderers              22   9  0  2  36:14    3  1  7  11:20    47:34  +13   37
 6. Sunderland                    22   7  2  2  31:13    3  3  5  20:18    51:31  +20   35
 7. Blackburn Rovers              22   7  1  3  29:19    4  1  6  23:24    52:43   +9   35
 8. Burnley                       22   7  1  3  33:24    2  2  7  19:39    52:63  -11   30
 9. Aston Villa                   22   5  4  2  29:18    2  0  9  16:40    45:58  -13   25
10. Accrington F.C.               22   5  1  5  19:19    1  3  7   9:31    28:50  -22   22
11. Derby County                  22   6  1  4  38:28    1  0 10   9:53    47:81  -34   22
12. West Bromwich Albion          22   3  1  7  17:26    2  1  8  17:31    34:57  -23   17
~~~

(Source: `1-division1.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

