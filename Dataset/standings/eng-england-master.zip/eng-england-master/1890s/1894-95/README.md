

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Sunderland                    30  13  2  0  51:14    8  3  4  29:23    80:37  +43   68
 2. Everton                       30  12  2  1  47:18    6  4  5  35:32    82:50  +32   60
 3. Aston Villa                   30  12  2  1  51:12    5  3  7  31:31    82:43  +39   56
 4. Preston North End             30   9  3  3  32:14    6  2  7  30:32    62:46  +16   50
 5. Sheffield United              30  10  2  3  33:17    4  2  9  24:38    57:55   +2   46
 6. Nottingham Forest             30  10  1  4  33:22    3  4  8  17:34    50:56   -6   44
 7. Blackburn Rovers              30   9  5  1  40:15    2  5  8  19:34    59:49  +10   43
 8. Sheffield Wednesday           30  10  2  3  36:19    2  2 11  14:36    50:55   -5   40
 9. Burnley                       30   8  2  5  28:24    3  2 10  16:32    44:56  -12   37
10. Bolton Wanderers              30   8  3  4  45:23    1  4 10  16:39    61:62   -1   34
11. West Bromwich Albion          30   9  2  4  38:21    1  2 12  13:45    51:66  -15   34
12. Wolverhampton Wanderers       30   7  4  4  24:25    2  3 10  19:38    43:63  -20   34
13. Birmingham City               30   6  6  3  35:28    3  1 11  15:46    50:74  -24   34
14. Stoke City                    30   7  3  5  35:25    2  3 10  15:42    50:67  -17   33
15. Derby County                  30   4  5  6  23:23    3  4  8  22:45    45:68  -23   30
16. Liverpool                     30   6  4  5  38:28    1  4 10  13:42    51:70  -19   29
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Bury                          30  15  0  0  48:11    8  2  5  30:22    78:33  +45   71
 2. Notts County                  30  12  2  1  50:15    5  3  7  25:30    75:45  +30   56
 3. Grimsby Town                  30  14  0  1  51:16    4  1 10  28:36    79:52  +27   55
 4. Manchester United             30   9  6  0  52:18    6  2  7  26:26    78:44  +34   53
 5. Leicester City                30  11  2  2  45:20    4  6  5  27:33    72:53  +19   53
 6. Darwen                        30  13  1  1  53:10    3  3  9  21:33    74:43  +31   52
 7. Burton Wanderers              30  10  3  2  49:9     4  4  7  18:30    67:39  +28   49
 8. Arsenal                       30  11  3  1  54:20    3  3  9  21:38    75:58  +17   48
 9. Manchester City               30   9  3  3  56:28    5  0 10  26:44    82:72  +10   45
10. Newcastle United              30  11  1  3  51:28    1  2 12  21:56    72:84  -12   39
11. Burton Swifts                 30   9  2  4  34:20    2  1 12  18:54    52:74  -22   36
12. Rotherham Town                30  10  0  5  37:22    1  2 12  18:40    55:62   -7   35
13. Lincoln City                  30   8  0  7  32:27    2  0 13  20:65    52:92  -40   30
14. Walsall                       30   8  0  7  35:25    2  0 13  12:67    47:92  -45   30
15. Port Vale                     30   6  3  6  30:23    1  1 13   9:54    39:77  -38   25
16. Crewe Alexandra               30   3  4  8  20:34    0  0 15   6:69    26:103 -77   13
~~~

(Source: `2-division2.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

